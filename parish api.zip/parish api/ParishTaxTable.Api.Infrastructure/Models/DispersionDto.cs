﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ParishTaxTable.Api.Infrastructure.Models
{
    public class DispersionDto
    {
        [Key]
        public int Id { get; set; }
        [Column(TypeName = "decimal(7, 5)")]
        public decimal DistributionRate { get; set; }
        [Column(TypeName = "decimal(7, 5)")]
        public decimal VendorComp { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? TermDate { get; set; }
        public string Comments { get; set; }
        public bool IsInvalidDispersion { get; set; }

        public int DomicileId { get; set; }
        public int JurisdictionId { get; set; }
        public DomicileDto Domicile { get; set; }
        public JurisdictionDto Jurisdiction { get; set; }

    }
}
