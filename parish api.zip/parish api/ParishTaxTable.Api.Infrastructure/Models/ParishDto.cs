﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ParishTaxTable.Api.Infrastructure.Models
{
    public class ParishDto
    {
        [Key]
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public IEnumerable<DomicileDto> Domiciles { get; set; }
        public IEnumerable<ContactDto> Contacts { get; set; }
        public IEnumerable<JurisdictionDto> Jurisdictions { get; set; }
    }
}
