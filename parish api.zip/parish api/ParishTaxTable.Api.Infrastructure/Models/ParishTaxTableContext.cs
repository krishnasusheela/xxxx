﻿using System;
using Microsoft.EntityFrameworkCore;

namespace ParishTaxTable.Api.Infrastructure.Models
{
    /// <summary>
    /// Parish Tax Table Context
    /// ***There is a Global Filter to show only Current Results***
    /// </summary>
    public class ParishTaxTableContext : DbContext
    {
        public ParishTaxTableContext(DbContextOptions<ParishTaxTableContext> options) : base(options)
        {
        }
        public DbSet<ParishDto> Parishes { get; set; }
        public DbSet<DomicileDto> Domiciles { get; set; }
        public DbSet<DispersionDto> Dispersions { get; set; }
        public DbSet<JurisdictionDto> Jurisdictions { get; set; }
        public DbSet<JurisdictionTypeDto> JurisdictionTypes { get; set; }
        public DbSet<ContactDto> Contacts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Filtered to show Current and Future Domiciles & Dispersions. Historical ones filtered out.
            modelBuilder.Entity<DomicileDto>().HasQueryFilter(y =>  y.TermDate == null || y.TermDate >= DateTime.Now);
            modelBuilder.Entity<DispersionDto>().HasQueryFilter(y => y.TermDate == null || y.TermDate >= DateTime.Now);

        }
    }
}
