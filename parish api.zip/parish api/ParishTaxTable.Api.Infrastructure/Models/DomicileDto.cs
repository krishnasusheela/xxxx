﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ParishTaxTable.Api.Infrastructure.Models
{
    public class DomicileDto
    {
        [Key]
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? TermDate { get; set; }
        public bool? InCityLimits { get; set; }
        public IEnumerable<DispersionDto> Dispersions { get; set; }

        public int ParishId { get; set; }
        public ParishDto Parish { get; set; }

        [NotMapped]
        public DateTimeOffset? SearchDate { get; set; } = DateTimeOffset.Now;
    }
}
