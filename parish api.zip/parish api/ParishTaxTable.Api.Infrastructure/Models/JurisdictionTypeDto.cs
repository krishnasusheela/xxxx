﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ParishTaxTable.Api.Infrastructure.Models
{
    public class JurisdictionTypeDto
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public IEnumerable<JurisdictionDto> Jurisdictions { get; set; }
    }
}
