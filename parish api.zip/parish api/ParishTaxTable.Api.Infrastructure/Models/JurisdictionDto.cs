﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ParishTaxTable.Api.Infrastructure.Models
{
    public class JurisdictionDto
    {
        [Key]
        public int Id { get; set; }
        public int ParishId { get; set; }
        public string Name { get; set; }
        public int JurisdictionTypeId { get; set; }
        public DateTimeOffset CreateDate { get; set; }
        public DateTimeOffset? RetireDate { get; set; }


        public JurisdictionTypeDto JurisdictionType { get; set; }
        public ParishDto Parish { get; set; }
    }
}
