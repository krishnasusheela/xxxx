﻿using System;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Domiciles
{
    public class UpdatedDomicileMustHaveTermDateThatIsAfterEffectiveDateOrNull
        : IUpdateDomicileRule
    {
        private const string ExceptionMessage =
            "Domiciles cannot have an expiration date before the effective date.";

        public void Test(DomicileDto domicileToUpdate, Domicile domicileWithUpdates)
        {
            if (domicileWithUpdates.TermDate != null &&
                domicileWithUpdates.TermDate <= domicileWithUpdates.EffectiveDate)
            {
                throw new InvalidOperationException(
                    ExceptionMessage);
            }
        }
    }
}
