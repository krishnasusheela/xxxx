﻿using System;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Domiciles
{
    public class CreatedDomicileMustHaveFutureEffectiveDate
        : ICreateDomicileRule
    {
        private const string ExceptionMessage =
            "New domiciles cannot be created as immediately current. Create one with an effective date in the future.";

        public void Test(DomicileDto domicile)
        {
            if (domicile.EffectiveDate <= DateTimeOffset.Now)
            {
                throw new InvalidOperationException(ExceptionMessage);
            }
        }
    }
}