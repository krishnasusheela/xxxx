﻿using System;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Domiciles
{
    public class UpdatedDomicileCannotBeModifiedIfDomicileIsExpired
        : IUpdateDomicileRule
    {
        private const string ExceptionMessage =
            "Unable to modify domicile after Expiration Date has passed.";

        public void Test(DomicileDto domicileToUpdate, Domicile domicileWithUpdates)
        {
            if (domicileToUpdate.TermDate != null
                && domicileToUpdate.TermDate <= DateTimeOffset.Now
            )
            {
                throw new InvalidOperationException(ExceptionMessage);
            }
        }
    }
}