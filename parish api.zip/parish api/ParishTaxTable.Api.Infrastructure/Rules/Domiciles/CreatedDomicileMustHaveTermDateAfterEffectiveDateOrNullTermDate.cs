﻿using System;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Domiciles
{
    public class CreatedDomicileMustHaveTermDateAfterEffectiveDateOrNullTermDate
        : ICreateDomicileRule
    {
        private const string ExceptionMessage =
            "New domiciles cannot have an expiration date that is before their effective date.";

        public void Test(DomicileDto domicile)
        {
            if (domicile.TermDate != null && 
                domicile.TermDate <= domicile.EffectiveDate)
            {
                throw new InvalidOperationException(ExceptionMessage);
            }
        }
    }
}
