﻿using System.Collections.Generic;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Domiciles
{
    public class DomicileUpdateRules
        : IDomicileUpdateRules
    {
        private readonly IEnumerable<IUpdateDomicileRule> rules;

        public DomicileUpdateRules(
            IEnumerable<IUpdateDomicileRule> rules)
        {
            this.rules = rules;
        }

        public void Test(DomicileDto domicileToUpdate, Domicile domicileWithUpdates)
        {
            foreach (var rule in rules)
            {
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates);
            }
        }
    }
}