﻿using System.Collections.Generic;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Domiciles
{
    public class DomicileCreateRules
        : IDomicileCreateRules
    {
        private readonly IEnumerable<ICreateDomicileRule> rules;

        public DomicileCreateRules(
            IEnumerable<ICreateDomicileRule> rules)
        {
            this.rules = rules;
        }

        public void Test(DomicileDto domicile)
        {
            foreach (var rule in rules)
            {
                rule.Test(
                    domicile);
            }
        }
    }
}
