﻿using System;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Domiciles
{
    public class CreatedDomicileCannotHaveSameCodeAsOtherDomiciles
        : ICreateDomicileRule
    {
        private const string ExceptionMessage =
            "Created Domicile's Code is already in use.";
        private readonly IDomicileRepository repository;

        public CreatedDomicileCannotHaveSameCodeAsOtherDomiciles(
            IDomicileRepository repository)
        {
            this.repository = repository;
        }

        public void Test(DomicileDto domicile)
        {
            var matchingDomicile = repository.GetByCode(domicile.ParishId, domicile.Code).GetAwaiter().GetResult();

            if (matchingDomicile != null)
            {
                throw new InvalidOperationException(
                    ExceptionMessage);
            }

        }
    }
}
