﻿using System;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Domiciles
{
    public class UpdatedDomicileCannotChangeTermDateToPastDate
        : IUpdateDomicileRule
    {
        private const string ExceptionMessage =
            "Domicile Expiration Date must be in the future.";

        public void Test(DomicileDto domicileToUpdate, Domicile domicileWithUpdates)
        {
            if (domicileWithUpdates.TermDate != null
                && domicileWithUpdates.TermDate != domicileToUpdate.TermDate
                && domicileWithUpdates.TermDate <= DateTimeOffset.Now
            )
            {
                throw new InvalidOperationException(ExceptionMessage);
            }
        }
    }
}
