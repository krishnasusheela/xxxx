﻿using System.Collections.Generic;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Jurisdictions
{
    public class JurisdictionUpdateRules
        : IJurisdictionUpdateRules
    {
        private readonly IEnumerable<IUpdateJurisdictionRule> rules;

        public JurisdictionUpdateRules(
            IEnumerable<IUpdateJurisdictionRule> rules)
        {
            this.rules = rules;
        }

        public void Test(JurisdictionDto jurisdictionToUpdate, Jurisdiction jurisdictionWithUpdates)
        {
            foreach(var rule in rules)
            {
                rule.Test(
                    jurisdictionToUpdate,
                    jurisdictionWithUpdates);
            }
        }
    }
}
