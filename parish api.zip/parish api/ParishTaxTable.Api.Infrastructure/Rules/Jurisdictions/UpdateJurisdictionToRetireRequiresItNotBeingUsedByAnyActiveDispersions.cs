﻿using System;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Jurisdictions
{
    public class UpdateJurisdictionToRetireRequiresItNotBeingUsedByAnyActiveDispersions
        : IUpdateJurisdictionRule
    {
        private IDispersionRepository repository;
        private const string ExceptionMessage =
            "This jurisdiction has at least one affiliated in-use dispersion. Please invalidate this dispersion, or wait for its expiration, before retiring this jurisdiction.";

        public UpdateJurisdictionToRetireRequiresItNotBeingUsedByAnyActiveDispersions(IDispersionRepository repository)
        {
            this.repository = repository;
        }
         public void Test(
            JurisdictionDto jurisdictionToUpdate , Jurisdiction jurisdictionWithUpdates)
         {          
            var dispersions = Task.Run(() => repository
            .GetByJurisdictionId(jurisdictionToUpdate.Id)).Result;

            if (dispersions != null 
                && jurisdictionToUpdate.RetireDate == null
                && jurisdictionWithUpdates.RetireDate.HasValue)
            {
                foreach (var dispersion in dispersions)
                {
                    if (dispersion.IsEffectiveDispersion(DateTimeOffset.Now))
                    {
                        throw new InvalidOperationException(ExceptionMessage);
                    }
                }
            }
         }        
    }
}
