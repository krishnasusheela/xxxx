﻿using System;
using System.Linq;
using System.Threading.Tasks;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Contacts
{
    public class LastContactCannotBeRetiredRule
        : IDeleteContactRule
    {
        private IParishRepository repository;
        private const string ExceptionMessage =
            "This parish has one contact remaining. You may not remove that contact until another contact has been added.";

        public LastContactCannotBeRetiredRule(IParishRepository repository)
        {
            this.repository = repository;
        }

        public void Test(
            ContactDto contactToUpdate)
        {
            var parish = Task.Run(() => repository.GetWithContactsById(contactToUpdate.ParishId)).Result;
            if (parish.Contacts.Count() == 1)
            {
                throw new InvalidOperationException(ExceptionMessage);
            }
        }
    }
}
