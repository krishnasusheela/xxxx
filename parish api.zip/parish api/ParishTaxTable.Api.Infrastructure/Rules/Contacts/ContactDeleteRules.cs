﻿using System.Collections.Generic;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Contacts
{
    public class ContactDeleteRules
        : IContactDeleteRules
    {
        private readonly IEnumerable<IDeleteContactRule> rules;

        public ContactDeleteRules(
            IEnumerable<IDeleteContactRule> rules)
        {
            this.rules = rules;
        }

        public void Test(ContactDto contactToUpdate)
        {
            foreach (var rule in rules)
            {
                rule.Test(
                    contactToUpdate);
            }
        }
    }
}
