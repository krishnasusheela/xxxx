﻿using System;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Dispersions
{
    public class HistoricalDispersionsCanOnlyBeInvalidatedRule
        : IUpdateDispersionRule
    {
        private const string ExceptionMessage =
            "Historical dispersions cannot be edited, instead they can be invalidated.";
        public void Test(
            Dispersion dispersionWithUpdates,
            DispersionDto dispersionToUpdate)
        {
            if (dispersionToUpdate.TermDate < DateTimeOffset.Now.Date
                && (dispersionToUpdate.EffectiveDate != dispersionWithUpdates.EffectiveDate ||
                    dispersionToUpdate.TermDate != dispersionWithUpdates.TermDate ||
                    dispersionToUpdate.DistributionRate != dispersionWithUpdates.DistributionRate ||
                    dispersionToUpdate.VendorComp != dispersionWithUpdates.VendorCompensation))
            {
                throw new InvalidOperationException(ExceptionMessage);
            }
        }
    }
}
