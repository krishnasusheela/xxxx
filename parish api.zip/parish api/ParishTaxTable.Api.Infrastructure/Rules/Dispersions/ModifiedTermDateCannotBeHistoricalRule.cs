﻿using System;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Dispersions
{
    public class ModifiedTermDateCannotBeHistoricalRule
        : IUpdateDispersionRule
    {
        private const string ExceptionMessage =
            "Dispersions cannot be edited to have a past expiration date.";

        public void Test(
            Dispersion dispersionWithUpdates, 
            DispersionDto dispersionToUpdate)
        {
            if (dispersionToUpdate.TermDate?.Date != dispersionWithUpdates.TermDate?.Date &&
                dispersionWithUpdates.TermDate.EndOfDay() <= DateTimeOffset.Now &&
                (dispersionToUpdate.TermDate >= DateTimeOffset.Now ||
                 dispersionToUpdate.TermDate == null))
            {
                throw new InvalidOperationException(
                    ExceptionMessage);
            }
        }
    }    
}
