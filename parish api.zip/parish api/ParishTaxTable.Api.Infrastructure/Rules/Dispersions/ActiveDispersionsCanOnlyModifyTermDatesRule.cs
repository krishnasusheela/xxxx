﻿using System;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Dispersions
{
    public class ActiveDispersionsCanOnlyModifyTermDatesRule
        : IUpdateDispersionRule
    {
        private const string ExceptionMessage =
            "Only the expiration date can be modified on In-Use Dispersions.";

        public void Test(
            Dispersion dispersionWithUpdates, 
            DispersionDto dispersionToUpdate)
        {
            if (dispersionToUpdate.IsEffectiveDispersion(DateTimeOffset.Now.Date)
                && (dispersionToUpdate.EffectiveDate != dispersionWithUpdates.EffectiveDate ||
                    dispersionToUpdate.DistributionRate != dispersionWithUpdates.DistributionRate ||
                    dispersionToUpdate.VendorComp != dispersionWithUpdates.VendorCompensation ))
            {
                throw new InvalidOperationException(ExceptionMessage);
            }
        }
    }
}
