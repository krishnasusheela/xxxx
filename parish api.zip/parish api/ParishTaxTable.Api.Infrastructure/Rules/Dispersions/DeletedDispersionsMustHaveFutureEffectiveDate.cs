﻿using System;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Dispersions
{
    public class DeletedDispersionsMustHaveFutureEffectiveDate
        : IDeleteDispersionRule
    {
        private const string ExceptionMessage =
            "You cannot delete a dispersion that has already gone into effect. You can only invalidate it.";

        public void Test(
            DispersionDto dispersion)
        {
            if (dispersion.EffectiveDate <= DateTimeOffset.Now)
            {
                throw new InvalidOperationException(
                    ExceptionMessage);
            }
        }
    }
}
