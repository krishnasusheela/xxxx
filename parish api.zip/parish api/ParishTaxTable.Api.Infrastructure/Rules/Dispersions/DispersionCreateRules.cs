﻿using System.Collections.Generic;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Dispersions
{
    public class DispersionCreateRules
        : IDispersionCreateRules
    {
        private readonly IEnumerable<ICreateDispersionRule> rules;

        public DispersionCreateRules(
            IEnumerable<ICreateDispersionRule> rules)
        {
            this.rules = rules;
        }

        public void Test(DispersionDto dispersionToCreate)
        {
            foreach (var rule in rules)
            {
                rule.Test(
                    dispersionToCreate);
            }
        }
    }
}
