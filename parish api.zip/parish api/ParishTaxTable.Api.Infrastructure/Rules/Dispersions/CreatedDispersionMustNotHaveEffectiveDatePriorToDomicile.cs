﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Repositories;

namespace ParishTaxTable.Api.Infrastructure.Rules.Dispersions
{
    public class CreatedDispersionMustNotHaveEffectiveDatePriorToDomicile
        : ICreateDispersionRule
        , IReplaceDispersionRule
    {
        IDomicileRepository domicileRepository;

        private const string ExceptionMessage =
            "Dispersion cannot have an effective date prior to the effective date of the Domicile that it is in.";

        public CreatedDispersionMustNotHaveEffectiveDatePriorToDomicile (IDomicileRepository domicileRepository)
        {
            this.domicileRepository = domicileRepository;
        }

        public void Test(DispersionDto dispersion)
        {
            var domicile = Task.Run(() => domicileRepository.GetById(dispersion.DomicileId)).Result;

            if (dispersion.EffectiveDate < domicile.EffectiveDate)
            {
                throw new InvalidOperationException(
                    ExceptionMessage);
            }
        }
    }
}
