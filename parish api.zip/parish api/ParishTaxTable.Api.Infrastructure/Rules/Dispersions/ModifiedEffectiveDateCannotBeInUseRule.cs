﻿using System;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Dispersions
{
    public class ModifiedEffectiveDateCannotBeInUseRule
        : IUpdateDispersionRule
    {
        private const string ExceptionMessage =
            "Effective Date cannot be edited to a current or previous date.";

        public void Test(
            Dispersion dispersionWithUpdates,
            DispersionDto dispersionToUpdate)
        {
            if (dispersionToUpdate.EffectiveDate != dispersionWithUpdates.EffectiveDate &&
                dispersionWithUpdates.EffectiveDate <= DateTimeOffset.Now &&
                dispersionToUpdate.EffectiveDate >= DateTimeOffset.Now)
            {
                throw new InvalidOperationException(
                    ExceptionMessage);
            }
        }
    }
}
