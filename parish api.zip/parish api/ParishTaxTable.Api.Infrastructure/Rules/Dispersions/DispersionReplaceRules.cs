﻿using System.Collections.Generic;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Dispersions
{
    public class DispersionReplaceRules
        : IDispersionReplaceRules
    {
        private readonly IEnumerable<IReplaceDispersionRule> rules;

        public DispersionReplaceRules(
            IEnumerable<IReplaceDispersionRule> rules)
        {
            this.rules = rules;
        }

        public void Test(DispersionDto dispersion)
        {
            foreach (var rule in rules)
            {
                rule.Test(
                    dispersion);
            }
        }
    }
}