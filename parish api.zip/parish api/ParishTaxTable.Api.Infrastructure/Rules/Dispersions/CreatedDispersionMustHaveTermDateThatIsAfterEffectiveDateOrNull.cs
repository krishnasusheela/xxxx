﻿using System;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Dispersions
{
    public class CreatedDispersionMustHaveTermDateThatIsAfterEffectiveDateOrNull
        : ICreateDispersionRule
        , IReplaceDispersionRule
    {
        private const string ExceptionMessage =
            "New dispersions cannot have an expiration date before the effective date.";

        public void Test(DispersionDto dispersion)
        {
            if (dispersion.TermDate != null &&
                dispersion.TermDate <= dispersion.EffectiveDate)
            {
                throw new InvalidOperationException(
                    ExceptionMessage);
            }
        }
    }
}
