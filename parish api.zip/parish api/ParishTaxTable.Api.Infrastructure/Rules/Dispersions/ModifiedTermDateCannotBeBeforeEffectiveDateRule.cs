﻿using System;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Rules.Dispersions
{
    public class ModifiedTermDateCannotBeBeforeEffectiveDateRule
        : IUpdateDispersionRule
    {
        private const string ExceptionMessage =
            "Dispersions cannot have an expiration date before the effective date.";

        public void Test(
            Dispersion dispersionWithUpdates,
            DispersionDto dispersionToUpdate)
        {
            if (dispersionWithUpdates.TermDate != null
                && dispersionWithUpdates.TermDate <= dispersionWithUpdates.EffectiveDate)
            {
                throw new InvalidOperationException(
                    ExceptionMessage);
            }
        }
    }
}
