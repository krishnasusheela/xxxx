﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Repositories
{
    public class DispersionRepository
        : IDispersionRepository
    {
        private readonly ParishTaxTableContext context;

        public DispersionRepository(
            ParishTaxTableContext context)
        {
            this.context = context;
        }

        public async Task<DispersionDto> GetById(
            int id)
        {
            return await context
                .Dispersions
                .IgnoreQueryFilters()
                .SingleOrDefaultAsync(t => t.Id == id);
        }

        public async Task<IEnumerable<DispersionDto>> GetByJurisdictionId(
            int id)
        {
            return await context
                .Dispersions
                .IgnoreQueryFilters()
                .Where(x => x.JurisdictionId == id)
                .ToListAsync();
        }

        public async Task<DispersionDto> Create(
            DispersionDto dispersion)
        {
            context.Dispersions.Add(
                dispersion);

            await context.SaveChangesAsync();

            return dispersion;
        }

        public async Task<DispersionDto> Update(
            DispersionDto dispersion)
        {
            context.Dispersions.Update(
                dispersion);
            await context.SaveChangesAsync();

            return dispersion;
        }

        public async Task Delete(
            int id)
        {
            var dispersion = await GetById(id);

            context.Dispersions.Remove(
                dispersion);
            await context.SaveChangesAsync();
        }
    }
}
