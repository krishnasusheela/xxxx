﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ParishTaxTable.Api.Infrastructure.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Repositories
{
    public class ParishRepository
        : IParishRepository
    {
        private readonly ParishTaxTableContext context;

        public ParishRepository(
            ParishTaxTableContext context)
        {
            this.context = context;
        }

        public async Task<ParishDto> GetById(int id)
        {
            return await context
                .Parishes
                .SingleOrDefaultAsync(p => p.Id == id);
        }

        public async Task<IEnumerable<ParishDto>> Get()
        {
            return await context
                .Parishes
                .ToListAsync();
        }

        public async Task<ParishDto> GetWithDomicilesById(int id)
        {
            return await context.Parishes
                .Include(p => p.Domiciles)
                .ThenInclude(p => p.Dispersions)
                .ThenInclude(p => p.Jurisdiction)
                .ThenInclude(p => p.JurisdictionType)
                .SingleOrDefaultAsync(t => t.Id == id);
        }

        public async Task<ParishDto> GetWithAllDomicilesById(int id)
        {
            return await context.Parishes
                .IgnoreQueryFilters()
                .Include(p => p.Domiciles)
                .SingleOrDefaultAsync(t => t.Id == id);
        }

        public async Task<IEnumerable<ParishDto>> GetWithDomiciles()
        {
            return await context.Parishes
                .Include(p => p.Domiciles)
                .ThenInclude(p => p.Dispersions)
                .ThenInclude(p => p.Jurisdiction)
                .ThenInclude(p => p.JurisdictionType)
                .ToListAsync();
        }

        public async Task<ParishDto> GetWithContactsById(int id)
        {
            return await context
                .Parishes
                .Where(p => p.Id == id)
                .Select(s => new ParishDto
                {
                    Id = s.Id,
                    Code = s.Code,
                    Name = s.Name,
                    Contacts = s.Contacts.Where(
                        y =>
                            y.CreateDate <= DateTimeOffset.Now
                            && (y.RetireDate == null 
                                || y.RetireDate >= DateTimeOffset.Now))
                })
                .SingleOrDefaultAsync();
        }

        public async Task<IEnumerable<ParishDto>> GetWithContacts()
        {
            return await context
                .Parishes
                .Select(s => new ParishDto
                {
                    Id = s.Id,
                    Code = s.Code,
                    Name = s.Name,
                    Contacts = s.Contacts.Where(
                        y =>
                            y.CreateDate <= DateTimeOffset.Now
                            && (y.RetireDate == null
                                || y.RetireDate >= DateTimeOffset.Now))
                })
                .ToListAsync();
        }

        public async Task<ParishDto> GetWithJurisdictionsById(int id)
        {
            return await context
                .Parishes
                .Where(p => p.Id == id)
                .Include(p => p.Jurisdictions)
                .ThenInclude(p => p.JurisdictionType)
                .SingleOrDefaultAsync();
        }

        public async Task<IEnumerable<ParishDto>> GetWithJurisdictions()
        {
            return await context
                .Parishes
                .Include(p => p.Jurisdictions)
                .ThenInclude(p => p.JurisdictionType)
                .ToListAsync();
        }
    }
}
