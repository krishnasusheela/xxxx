﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ParishTaxTable.Api.Infrastructure.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Repositories
{
    public class JurisdictionTypeRepository
        : IJurisdictionTypeRepository
    {
        private readonly ParishTaxTableContext context;

        public JurisdictionTypeRepository(
            ParishTaxTableContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<JurisdictionTypeDto>> Get()
        {
            return await context
                .JurisdictionTypes
                .ToListAsync();
        }
    }
}
