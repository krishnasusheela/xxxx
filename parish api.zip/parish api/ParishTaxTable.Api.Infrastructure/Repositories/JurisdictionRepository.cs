﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Repositories
{
    public class JurisdictionRepository
        : IJurisdictionRepository
    {
        private readonly ParishTaxTableContext context;

        public JurisdictionRepository(
            ParishTaxTableContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<JurisdictionDto>> Get()
        {
            return await context
                .Jurisdictions
                .Include(t => t.JurisdictionType)
                .ToListAsync();
        }

        public async Task<JurisdictionDto> GetById(int id)
        {
            return await context
                .Jurisdictions
                .Include(t => t.JurisdictionType)
                .SingleOrDefaultAsync(p => p.Id == id);
        }

        public async Task<JurisdictionDto> Create(JurisdictionDto jurisdiction)
        {
            return await Create(
                jurisdiction,
                DateTimeOffset.Now);
        }

        public async Task<JurisdictionDto> Create(
            JurisdictionDto jurisdiction, 
            DateTimeOffset createDate)
        {
            jurisdiction.CreateDate = createDate;

            context.Jurisdictions.Add(
                jurisdiction);

            await context.SaveChangesAsync();

            return jurisdiction;
        }

        public async Task<JurisdictionDto> Update(JurisdictionDto jurisdiction)
        {
            context.Jurisdictions.Update(jurisdiction);
            await context.SaveChangesAsync();

            return jurisdiction;
        }
    }
}
