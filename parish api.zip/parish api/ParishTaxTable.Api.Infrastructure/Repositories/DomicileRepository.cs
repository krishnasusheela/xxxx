﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Repositories
{
    public class DomicileRepository
        : IDomicileRepository
    {
        private readonly ParishTaxTableContext context;

        public DomicileRepository(
            ParishTaxTableContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<DomicileDto>> Get()
        {
            return await context.Domiciles
                .Include(x => x.Parish)
                .Include(p => p.Dispersions)
                .ThenInclude(p => p.Jurisdiction)
                .ThenInclude(p => p.JurisdictionType)
                .ToListAsync();
        }

        public async Task<DomicileDto> GetById(int id)
        {
            var result = await context.Domiciles
                .IgnoreQueryFilters()
                .Include(x => x.Parish)
                .SingleOrDefaultAsync(t => t.Id == id);

            context.Entry(result)
                .Collection(b => b.Dispersions)
                .Query()
                .IgnoreQueryFilters()
                .Where(p => p.IsEffectiveDispersion(DateTimeOffset.Now.Date)
                         || p.IsInFuture())
                .Include(p => p.Jurisdiction)
                .ThenInclude(p => p.JurisdictionType)
                .Load();

            return result;
        }

        public async Task<DomicileDto> GetByIdAndDate(int id, DateTimeOffset date)
        {
            var result = await context.Domiciles
                .IgnoreQueryFilters()
                .Include(x => x.Parish)
                .SingleOrDefaultAsync(t => t.IsEffectiveDomicile(date) && t.Id == id);

            if (result == null)
                return null;

            context.Entry(result)
                .Collection(b => b.Dispersions)
                .Query()
                .IgnoreQueryFilters()
                .Where(p => p.IsEffectiveDispersion(date))
                .Include(p => p.Jurisdiction)
                .ThenInclude(p => p.JurisdictionType)
                .Load();

            return result;
        }

        public async Task<DomicileDto> Create(DomicileDto domicile)
        {
            context.Domiciles.Add(domicile);
            await context.SaveChangesAsync();

            context.Entry(domicile)
                .Reference(p => p.Parish)
                .Load();

            return domicile;
        }

        public async Task<DomicileDto> Update(DomicileDto domicile)
        {
            context.Domiciles.Update(domicile);
            await context.SaveChangesAsync();

            return domicile;
        }

        public async Task<DomicileDto> GetByCode(int parishId, string domicileCode)
        {
            return await context.Domiciles
                .SingleOrDefaultAsync(t => t.ParishId == parishId && t.Code == domicileCode);
        }

        public async Task<DomicileDto> GetByCodes(string parishCode, string domicileCode)
        {

            return await context.Domiciles
                .Include(x => x.Parish)
                .Include(p => p.Dispersions)
                .ThenInclude(p => p.Jurisdiction)
                .ThenInclude(p => p.JurisdictionType)
                .SingleOrDefaultAsync(p => p.Parish.Code == parishCode && p.Code == domicileCode);
        }
    }
}
