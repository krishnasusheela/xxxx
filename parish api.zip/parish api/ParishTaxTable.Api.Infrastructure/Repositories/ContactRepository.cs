﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Repositories
{
    public class ContactRepository
        : IContactRepository
    {
        private readonly ParishTaxTableContext context;

        public ContactRepository(
            ParishTaxTableContext context)
        {
            this.context = context;
        }

        public async Task<ContactDto> GetById(
            int id)
        {
            return await context
                .Contacts
                .SingleOrDefaultAsync(
                    p => p.Id == id);
        }

        public async Task<ContactDto> InsertContact(
            ContactDto contact)
        {
            return await InsertContact(
                contact,
                DateTimeOffset.Now);
        }

        public async Task<ContactDto> InsertContact(
            ContactDto contact, 
            DateTimeOffset createDate)
        {
            contact.CreateDate = createDate;
            contact.RetireDate = null;

            context.Contacts.Add(contact);

            await context.SaveChangesAsync();

            return contact;
        }

        public async Task<ContactDto> RetireContact(
            int id)
        {
            return await RetireContact(
                id,
                DateTimeOffset.Now);
        }

        public async Task<ContactDto> RetireContact(
            int id, 
            DateTimeOffset retireDate)
        {
            var contact = await GetById(id);

            contact.RetireDate = retireDate;

            await context.SaveChangesAsync();

            return contact;
        }
    }
}
