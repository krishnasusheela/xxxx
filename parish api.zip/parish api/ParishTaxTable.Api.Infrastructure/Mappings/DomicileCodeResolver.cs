﻿using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Mappings
{
    public class DomicileCodeResolver
        : IValueResolver<DomicileDto, Domicile, string>
    {
        public string Resolve(
            DomicileDto source,
            Domicile destination,
            string destMember,
            ResolutionContext context)
        {
            return $"{source.Parish.Code}{source.Code}";
        }
    }
}
