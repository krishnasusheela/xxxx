﻿using System;
using System.Linq;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Mappings
{
    public class DomicileVendorCompensationRateResolver
        : IValueResolver<DomicileDto, Domicile, decimal>
    {
        public decimal Resolve(
            DomicileDto source, 
            Domicile destination, 
            decimal destMember, 
            ResolutionContext context)
        {
            const int decimalPlaces = 4;

            var collectionRate = source
                .Dispersions
                .GetCollectionRate();

            if (collectionRate == 0.0m)
            {
                return new decimal(0.0);
            }

            var compensation = source
                .Dispersions
                .GetCurrentDispersionDtos()
                .Sum(disp => DispersionDtoHelpers.GetVendorCompensationRate(disp, collectionRate));

            return Math.Round(
                compensation,
                decimalPlaces);
        }
    }
}
