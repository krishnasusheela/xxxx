﻿using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Mappings
{
    public class DomicileParishCollectionRateResolver : IValueResolver<DomicileDto, Domicile, decimal>
    {
        public decimal Resolve(
           DomicileDto source,
           Domicile destination,
           decimal destMember,
           ResolutionContext context)
        {
            return source
                .Dispersions
                .GetParishCollectionRate();
        }
    }
}
