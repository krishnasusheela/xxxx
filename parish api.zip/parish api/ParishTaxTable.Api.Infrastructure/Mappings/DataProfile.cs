﻿using System.Collections.Generic;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Mappings
{
    public class DataProfile
        : Profile
    {
        public DataProfile()
        {
            CreateMap<ParishDto, ParishDomicile>();
            CreateMap<ParishDto, ParishContact>();
            CreateMap<DomicileDto, Domicile>()
                .ForMember(
                    dest => dest.CombinedCode,
                    opt => opt.ResolveUsing<DomicileCodeResolver>())
                .ForMember(
                    dest => dest.CollectionRate,
                    opt => opt.ResolveUsing<DomicileCollectionRateResolver>())
                .ForMember(
                    dest => dest.VendorCompensation,
                    opt => opt.ResolveUsing<DomicileVendorCompensationRateResolver>())
                .ForMember(
                    dest => dest.ParishCollectionRate,
                    opt => opt.ResolveUsing<DomicileParishCollectionRateResolver>())
                .ForMember(
                    dest => dest.MunicipalityCollectionRate,
                    opt => opt.ResolveUsing<DomicileMunicipalityCollectionRateResolver>())
                .ForMember(
                    dest => dest.DomicileCode,
                    opt => opt.MapFrom(src => src.Code));
            CreateMap<DomicileDto, DomicileWithoutDisperions>()
                .ForMember(
                    dest => dest.CombinedCode,
                    opt => opt.ResolveUsing<DomicileCodeResolver>())
                .ForMember(
                    dest => dest.CollectionRate,
                    opt => opt.ResolveUsing<DomicileCollectionRateResolver>())             
                .ForMember(
                    dest => dest.VendorCompensation,
                    opt => opt.ResolveUsing<DomicileVendorCompensationRateResolver>())
                .ForMember(
                    dest => dest.ParishCollectionRate,
                    opt => opt.ResolveUsing<DomicileParishCollectionRateResolver>())
                .ForMember(
                    dest => dest.MunicipalityCollectionRate,
                    opt => opt.ResolveUsing<DomicileMunicipalityCollectionRateResolver>())
                .ForMember(
                    dest => dest.DomicileCode,
                    opt => opt.MapFrom(src => src.Code))
                .ForMember(
                    dest => dest.Dispersions,
                    opt => opt.Ignore());

            CreateMap<DispersionDto, Dispersion>()
                .ForMember(
                    dest => dest.VendorCompensation,
                    opt => opt.MapFrom(src => src.VendorComp));
            CreateMap<Dispersion, DispersionDto>()
                .ForMember(
                    dest => dest.VendorComp,
                    opt => opt.MapFrom(src => src.VendorCompensation))
                .ForMember(
                    dest => dest.Jurisdiction,
                    opt => opt.Ignore())
                .ForMember(
                    dest => dest.Comments, 
                    opt => opt.MapFrom(src => string.Empty));


            CreateMap<JurisdictionDto, Jurisdiction>();
            CreateMap<Jurisdiction, JurisdictionDto>()
                .ForMember(
                    dest => dest.JurisdictionTypeId,
                    opt => opt.MapFrom(src => src.JurisdictionType.Id))
                .ForMember(
                    dest => dest.JurisdictionType,
                    opt => opt.Ignore())
                .ForMember(
                    dest => dest.CreateDate,
                    opt => opt.Ignore());
            CreateMap<Domicile, DomicileDto>()
                .ForMember(
                    dest => dest.Parish,
                    opt => opt.Ignore())
                .ForMember(
                    dest => dest.Code,
                    opt => opt.MapFrom(src => src.DomicileCode))
                .ForMember(
                    dest => dest.InCityLimits,
                    opt => opt.Ignore());
            CreateMap<ParishDto, Parish>();
            CreateMap<ContactDto, Contact>();
            CreateMap<Contact, ContactDto>();
        }
    }
}
