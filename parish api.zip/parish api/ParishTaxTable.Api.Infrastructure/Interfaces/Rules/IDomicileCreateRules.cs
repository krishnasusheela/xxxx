﻿using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Rules
{
    public interface IDomicileCreateRules
    {
        void Test(DomicileDto domicile);
    }
}
