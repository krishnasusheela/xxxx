﻿using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Rules
{
    public interface IJurisdictionUpdateRules
    {
        void Test(JurisdictionDto jurisdictionToUpdate, Jurisdiction jurisdictionWithUpdates);
    }
}
