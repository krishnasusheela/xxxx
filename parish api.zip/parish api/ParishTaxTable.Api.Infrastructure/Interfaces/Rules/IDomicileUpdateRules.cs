﻿using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Rules
{
    public interface IDomicileUpdateRules
    {
        void Test(DomicileDto domicileToUpdate, Domicile domicileWithUpdates);
    }
}
