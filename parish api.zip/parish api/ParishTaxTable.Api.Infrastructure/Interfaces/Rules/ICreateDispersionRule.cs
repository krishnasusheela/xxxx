﻿using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Rules
{
    public interface ICreateDispersionRule
    {
        void Test(
            DispersionDto dispersion);
    }
}
