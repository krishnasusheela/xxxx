﻿using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Rules
{
    public interface IDeleteContactRule
    {
        void Test(ContactDto contactToUpdate);
    }
}
