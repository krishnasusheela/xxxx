﻿using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Rules
{
    public interface ICreateDomicileRule
    {
        void Test(DomicileDto domicile);
    }
}