﻿using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Rules
{
    public interface IDispersionReplaceRules
    {
        void Test(DispersionDto dispersionToCreate);
    }
}