﻿using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Rules
{
    public interface IContactDeleteRules
    {
        void Test(ContactDto contactToUpdate);
    }
}
