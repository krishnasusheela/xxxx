﻿using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Rules
{
    public interface IDispersionCreateRules
    {
        void Test(DispersionDto dispersionToCreate);
    }
}
