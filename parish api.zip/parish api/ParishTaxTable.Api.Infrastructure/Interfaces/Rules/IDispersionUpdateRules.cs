﻿using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Rules
{
    public interface IDispersionUpdateRules
    {
        void Test(
            Dispersion dispersionWithUpdates,
            DispersionDto dispersionToUpdate);
    }
}
