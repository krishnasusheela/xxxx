﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Repositories
{
    public interface IParishRepository
    {
        Task<ParishDto> GetById(int id);
        Task<IEnumerable<ParishDto>> Get();

        Task<ParishDto> GetWithDomicilesById(int id);
        Task<ParishDto> GetWithAllDomicilesById(int id);
        Task<IEnumerable<ParishDto>> GetWithDomiciles();

        Task<ParishDto> GetWithContactsById(int id);
        Task<IEnumerable<ParishDto>> GetWithContacts();

        Task<ParishDto> GetWithJurisdictionsById(int id);
        Task<IEnumerable<ParishDto>> GetWithJurisdictions();

    }
}
