﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Repositories
{
    public interface IJurisdictionTypeRepository
    {
        Task<IEnumerable<JurisdictionTypeDto>> Get();
    }
}
