﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Repositories
{
    public interface IDispersionRepository
    {
        Task<DispersionDto> GetById(int id);
        Task<IEnumerable<DispersionDto>> GetByJurisdictionId(int id);
        Task<DispersionDto> Create(DispersionDto dispersion);
        Task<DispersionDto> Update(DispersionDto dispersion);
        Task Delete(int id);
    }
}
