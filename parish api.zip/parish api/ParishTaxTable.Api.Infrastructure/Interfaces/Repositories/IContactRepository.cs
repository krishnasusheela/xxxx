﻿using System;
using System.Threading.Tasks;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Repositories
{
    public interface IContactRepository
    {
        Task<ContactDto> GetById(int id);
        Task<ContactDto> InsertContact(ContactDto contact);
        Task<ContactDto> InsertContact(ContactDto contact, DateTimeOffset createDate);
        Task<ContactDto> RetireContact(int id);
        Task<ContactDto> RetireContact(int id, DateTimeOffset retireDate);
    }
}
