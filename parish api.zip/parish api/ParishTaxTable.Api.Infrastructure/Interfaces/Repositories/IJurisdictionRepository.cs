﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Repositories
{
    public interface IJurisdictionRepository
    {
        Task<IEnumerable<JurisdictionDto>> Get();
        Task<JurisdictionDto> GetById(int id);
        Task<JurisdictionDto> Create(JurisdictionDto jurisdiction);
        Task<JurisdictionDto> Create(JurisdictionDto jurisdiction, DateTimeOffset createDate);
        Task<JurisdictionDto> Update(JurisdictionDto jurisdiction);
    }
}
