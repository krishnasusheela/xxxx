﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Interfaces.Repositories
{
    public interface IDomicileRepository
    {
        Task<IEnumerable<DomicileDto>> Get();
        Task<DomicileDto> GetById(int id);
        Task<DomicileDto> Create(DomicileDto domicile);
        Task<DomicileDto> Update(DomicileDto domicile);
        Task<DomicileDto> GetByCode(int parishId, string domicileCode);
        Task<DomicileDto> GetByIdAndDate(int id, DateTimeOffset date);
        Task<DomicileDto> GetByCodes(string parishCode, string domicileCode);
    }
}
