﻿using System;
using System.Threading.Tasks;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Services
{
    public class DispersionDataService
         : IDispersionDataService
    {
        private readonly IDispersionRepository repository;
        private readonly IDispersionUpdateRules updateRules;
        private readonly IDispersionCreateRules createRules;
        private readonly IDispersionDeleteRules deleteRules;
        private readonly IDispersionReplaceRules replaceRules;
        private readonly IMapper mapper;

        public DispersionDataService(
            IDispersionRepository repository,
            IDispersionUpdateRules updateRules,
            IDispersionCreateRules createRules,
            IDispersionDeleteRules deleteRules,
            IDispersionReplaceRules replaceRules,
            IMapper mapper)
        {
            this.repository = repository;
            this.updateRules = updateRules;
            this.createRules = createRules;
            this.deleteRules = deleteRules;
            this.replaceRules = replaceRules;
            this.mapper = mapper;
        }


        public async Task<Dispersion> GetDispersionById(int id)
        {
            var dto = await repository
                .GetById(id);

            return mapper
                .Map<Dispersion>(
                    dto);
        }

        public async Task<Dispersion> UpdateDispersion(Dispersion dispersion)
        {
            var dispersionToUpdate = await repository
                .GetById(dispersion.Id);

            updateRules
                .Test(
                    dispersion,
                    dispersionToUpdate);

            dispersionToUpdate.EffectiveDate = dispersion.EffectiveDate;
            dispersionToUpdate.TermDate = dispersion.TermDate.EndOfDay();
            dispersionToUpdate.DistributionRate = dispersion.DistributionRate;
            dispersionToUpdate.VendorComp = dispersion.VendorCompensation;
            dispersionToUpdate.IsInvalidDispersion = dispersion.IsInvalidDispersion;
            
            var updatedDispersion = await repository
                .Update(dispersionToUpdate);

            return mapper.Map<Dispersion>(
                updatedDispersion);
        }

        public async Task<Dispersion> CreateDispersion(Dispersion dispersion)
        {
            var dto = mapper.Map<DispersionDto>(dispersion);

            createRules
                .Test(dto);
            
            var createdDispersion = await repository
                .Create(dto);

            return mapper.Map<Dispersion>(createdDispersion); 
        }

        public async Task DeleteDispersion(int id)
        {
            var dispersionToDelete = await repository
                .GetById(id);        

            deleteRules
                .Test(dispersionToDelete);
            
            await repository.Delete(id);            
        }

        public async Task<Dispersion> ReplaceDispersion(Dispersion dispersion, int invalidatedId)
        {
            var invalidatedDispersion = await repository
                .GetById(invalidatedId);

            if (invalidatedDispersion == null || 
                !invalidatedDispersion.IsInvalidDispersion)
            {
                throw new InvalidOperationException(
                    "The Dispersion is not a correction for an invalidated dispersion.");
            }

            var dto = mapper.Map<DispersionDto>(dispersion);

            replaceRules
                .Test(dto);

            var createdDispersion = await repository
                .Create(dto);

            return mapper.Map<Dispersion>(
                createdDispersion);
        }        
    }
}
