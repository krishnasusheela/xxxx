﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Services
{
    public class JurisdictionDataService
        : IJurisdictionDataService
    {
        private readonly IJurisdictionUpdateRules updateRules;
        private readonly IJurisdictionRepository repository;
        private readonly IMapper mapper;

        public JurisdictionDataService(
            IJurisdictionUpdateRules updateRules,
            IJurisdictionRepository repository,
            IMapper mapper)
        {
            this.updateRules = updateRules;
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<Jurisdiction>> GetAllJurisdictions()
        {
            var jurisdictions = await repository
                .Get();

            return mapper.Map<IEnumerable<Jurisdiction>>(
                jurisdictions);
        }

        public async Task<Jurisdiction> GetJurisdictionById(int id)
        {
            var jurisdiction = await repository
                .GetById(id);

            return mapper.Map<Jurisdiction>(
                jurisdiction);
        }

        public async Task<Jurisdiction> CreateJurisdiction(Jurisdiction jurisdiction)
        {
            var dto = mapper
                .Map<JurisdictionDto>(jurisdiction);

            var createdJurisdiction = await repository
                .Create(dto);

            return mapper
                .Map<Jurisdiction>(
                    createdJurisdiction);
        }

        public async Task<Jurisdiction> UpdateJurisdiction(Jurisdiction jurisdiction)
        {
            var jurisdictionDto = await repository
                .GetById(jurisdiction.Id);

            if (jurisdictionDto is null)
                return null;

            updateRules.Test(jurisdictionDto, jurisdiction);

            var dto = mapper.Map(jurisdiction, jurisdictionDto);
                 
            var updatedJurisdiction = await repository
                .Update(dto);

            return mapper.Map<Jurisdiction>(
                updatedJurisdiction);
        }        
    }
}
