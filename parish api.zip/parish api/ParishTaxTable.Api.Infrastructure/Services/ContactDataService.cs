﻿using System;
using System.Threading.Tasks;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Services
{
    public class ContactDataService 
        : IContactDataService
    {
        private readonly IContactRepository contactRepository;
        private readonly IMapper mapper;
        private readonly IContactDeleteRules deleteRules;


        public ContactDataService(
            IContactRepository contactRepository,
            IMapper mapper,
            IContactDeleteRules deleteRules)
        {
            this.contactRepository = contactRepository;
            this.mapper = mapper;
            this.deleteRules = deleteRules;
        }

        public async Task<Contact> GetContactById(int id)
        {
            var contact = await contactRepository.GetById(id);
            var result = mapper.Map<Contact>(contact);

            return result;
        }

        public async Task<Contact> CreateContact(Contact contact)
        {
            var contactDto = mapper.Map<ContactDto>(contact);

            var result = await contactRepository
                .InsertContact(contactDto);

            return mapper.Map<Contact>(result);
        }

        public async Task<Contact> RetireContact(int id)
        {
            var contactToRetire = await contactRepository
                .GetById(id);

            deleteRules.Test(contactToRetire);

            var contact = await contactRepository
                .RetireContact(id);

            return mapper.Map<Contact>(
                contact);
        }

        public async Task<Contact> UpdateContact(Contact contact)
        {
            var lockedDateTime = DateTimeOffset.Now;
            var retiredId = contact.Id;
            contact.Id = 0;

            var dto = mapper.Map<ContactDto>(contact);

            var updatedContact = await contactRepository
                .InsertContact(dto, lockedDateTime);

            if (NewContactHasValidId(updatedContact.Id, retiredId))
            {
                await contactRepository.RetireContact(
                    retiredId, lockedDateTime);
            }

            return mapper.Map<Contact>(updatedContact);
        }

        private bool NewContactHasValidId(int newId, int oldId)
        {
            return newId != oldId && newId != 0;
        }
    }
}
