﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;

namespace ParishTaxTable.Api.Infrastructure.Services
{
    public class ParishJurisdictionDataService 
        : IParishJurisdictionDataService
    {
        private readonly IParishRepository repository;
        private readonly IMapper mapper;


        public ParishJurisdictionDataService(
            IParishRepository repository,
            IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<ParishJurisdiction>> GetAllParishJurisdictions()
        {
            var parishes = await repository
                .GetWithJurisdictions();

            return mapper.Map<IEnumerable<ParishJurisdiction>>(
                parishes);
        }

        public async Task<ParishJurisdiction> GetParishJurisdictionById(int id)
        {
            var parish = await repository
                .GetWithJurisdictionsById(id);

            return mapper.Map<ParishJurisdiction>(
                parish);
        }
    }
}
