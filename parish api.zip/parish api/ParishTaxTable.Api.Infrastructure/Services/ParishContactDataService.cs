﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;

namespace ParishTaxTable.Api.Infrastructure.Services
{
    public class ParishContactDataService 
        : IParishContactDataService
    {
        private readonly IParishRepository parishRepository;
        private readonly IMapper mapper;


        public ParishContactDataService(
            IParishRepository parishRepository,
            IMapper mapper)
        {
            this.parishRepository = parishRepository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<ParishContact>> GetAllParishContacts()
        {
            var parishes = await parishRepository
                .GetWithContacts();

            return mapper
                .Map<IEnumerable<ParishContact>>(
                    parishes);
        }

        public async Task<ParishContact> GetParishContactsById(int id)
        {
            var parish = await parishRepository
                .GetWithContactsById(id);

            return mapper
                .Map<ParishContact>(
                    parish);
        }
    }
}
