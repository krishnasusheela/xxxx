﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;

namespace ParishTaxTable.Api.Infrastructure.Services
{
    public class ParishDomicileDataService
        : IParishDomicileDataService
    {
        private readonly IParishRepository parishRepository;
        private readonly IMapper mapper;


        public ParishDomicileDataService(
            IParishRepository parishRepository,
            IMapper mapper)
        {
            this.parishRepository = parishRepository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<ParishDomicile>> GetAllParishDomiciles()
        {
            var parishes = await parishRepository
                .GetWithDomiciles();

            return mapper.Map<IEnumerable<ParishDomicile>>(
                parishes);
        }

        public async Task<ParishDomicile> GetDomicileParishById(int id)
        {
            var parish = await parishRepository
                .GetWithDomicilesById(id);

            return mapper.Map<ParishDomicile>(
                parish);
        }

        public async Task<ParishNextDomicileCode> GetNextParishDomicileCode(int id)
        {
            var parish = await parishRepository
                .GetWithAllDomicilesById(id);

            var initialDomicileCode = "00";
            var cannotParseDomicileCode = "";

            if (parish.Domiciles == null)
            {
                return new ParishNextDomicileCode { NextDomicileCode = initialDomicileCode };
            }
            else
            {
                var domicile = parish.Domiciles
                .OrderBy(p => p.Code)
                .LastOrDefault();

                if (Int32.TryParse(domicile.Code, out int code))
                {
                    var nextCode = (code + 1).ToString("00");
                    return new ParishNextDomicileCode { NextDomicileCode = nextCode };
                }
                return new ParishNextDomicileCode { NextDomicileCode = cannotParseDomicileCode };
            }

        }
    }
}
