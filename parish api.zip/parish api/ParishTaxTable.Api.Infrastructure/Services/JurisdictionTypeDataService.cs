﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;

namespace ParishTaxTable.Api.Infrastructure.Services
{
    public class JurisdictionTypeDataService
        : IJurisdictionTypeDataService
    {
        private readonly IJurisdictionTypeRepository repository;
        private readonly IMapper mapper;

        public JurisdictionTypeDataService(
            IJurisdictionTypeRepository repository,
            IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<JurisdictionType>> GetAllJurisdictionTypes()
        {
            var types = await repository
                .Get();

            return mapper.Map<IEnumerable<JurisdictionType>>(types);
        }
    }
}
