﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Services
{
    public class DomicileDataService
        : IDomicileDataService
    {
        private readonly IDomicileRepository repository;
        private readonly IDomicileCreateRules createRules;
        private readonly IDomicileUpdateRules updateRules;
        private readonly IMapper mapper;

        public DomicileDataService(
            IDomicileRepository repository,
            IDomicileCreateRules createRules,
            IDomicileUpdateRules updateRules,
            IMapper mapper)
        {
            this.repository = repository;
            this.createRules = createRules;
            this.updateRules = updateRules;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<Domicile>> GetAllDomiciles()
        {
            var domiciles = await repository.Get();

            return mapper.Map<IEnumerable<Domicile>>(
                domiciles);
        }

        public async Task<Domicile> GetDomicileById(int id)
        {
            var domicile = await repository.GetById(id);

            return mapper.Map<Domicile>(domicile);
        }

        public async Task<Domicile> GetDomicileByIdAndDate( int id , DateTimeOffset date)
        {
            var domicile = await repository.GetByIdAndDate( id , date);

            if (domicile == null)
                return null;

            domicile.SearchDate = date;

            var result = mapper.Map<Domicile>(domicile);

            return result;
        }

        public async Task<Domicile> CreateDomicile(Domicile domicile)
        {
            var dto = mapper.Map<DomicileDto>(domicile);

            createRules.Test(dto);

            var createdDomicile = await repository
                .Create(dto);

            return mapper.Map<Domicile>(createdDomicile);
        }

        public async Task<Domicile> UpdateDomicile(Domicile domicile)
        {
            var dto = await repository
                .GetById(domicile.Id);

            updateRules
                .Test(dto, domicile);

            dto.Name = domicile.Name;
            dto.TermDate = domicile.TermDate.EndOfDay();

            var updatedDomicile = await repository
                .Update(dto);

            return mapper
                .Map<Domicile>(
                    updatedDomicile);
        }

        public async Task<Domicile> GetDomicileCodeByCode(string code)
        {
            (var parishCode, var domicileCode) = code.GetParishCodeAndDomicileCode();

            var domicile = await repository.GetByCodes(parishCode, domicileCode);

            return mapper.Map<DomicileWithoutDisperions>(domicile); 
        }
    }
}
