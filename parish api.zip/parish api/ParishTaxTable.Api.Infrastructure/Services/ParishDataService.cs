﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;

namespace ParishTaxTable.Api.Infrastructure.Services
{
    public class ParishDataService
        : IParishDataService
    {
        private readonly IParishRepository parishRepository;
        private readonly IMapper mapper;

        public ParishDataService(
            IParishRepository parishRepository,
            IMapper mapper)
        {
            this.parishRepository = parishRepository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<Parish>> GetAllParishes()
        {
            var parishes = await parishRepository
                .Get();

            return mapper.Map<IEnumerable<Parish>>(parishes);
        }

        public async Task<Parish> GetParishById(int id)
        {
            var parish = await parishRepository
                .GetById(id);

            return mapper.Map<Parish>(parish);
        }
    }
}
