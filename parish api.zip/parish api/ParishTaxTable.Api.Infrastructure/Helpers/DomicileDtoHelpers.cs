﻿using System;
using System.Linq;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Helpers
{
    public static class DomicileDtoHelpers
    {
        public static (string, string) GetParishCodeAndDomicileCode(
            this string combinedCode)
        {
            var lengthOfParishCode = 2;

            return (
                new string((combinedCode ?? string.Empty).Take(lengthOfParishCode).ToArray()),
                new string((combinedCode ?? string.Empty).Skip(lengthOfParishCode).ToArray())
            );
        }

        public static bool IsEffectiveDomicile(
            this DomicileDto domicile,
            DateTimeOffset? date)
        {
            return domicile.EffectiveDate <= date &&
                   (domicile.TermDate >= date ||
                    domicile.TermDate == null);
        }
    }
}

