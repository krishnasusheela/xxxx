﻿using System;
using System.Linq;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Helpers
{
    public static class JurisdictionDtoHelpers
    {
        public static IQueryable<JurisdictionDto> GetCurrentJurisdictionDtos(
            this IQueryable<JurisdictionDto> jurisdictions)
        {
            return jurisdictions
                .Where(y =>
                    y.CreateDate <= DateTimeOffset.Now
                    && (y.RetireDate == null || y.RetireDate >= DateTimeOffset.Now));
        }
    }
}
