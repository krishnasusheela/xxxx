﻿using System;
using System.Collections.Generic;
using System.Linq;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Helpers
{
    public static class DispersionDtoHelpers
    {
       
        public static IEnumerable<DispersionDto> GetCurrentDispersionDtos(
            this IEnumerable<DispersionDto> dispersions)
        {
            return dispersions
                .Where(y =>
                    (y.EffectiveDate <= y.Domicile.SearchDate)
                    && (y.TermDate == null || y.TermDate >= y.Domicile.SearchDate)
                    && !y.IsInvalidDispersion);
        }

        public static bool IsEffectiveDispersion(
            this DispersionDto dispersion,
            DateTimeOffset date)
        {
            return dispersion.EffectiveDate <= date &&
                   (dispersion.TermDate >= date ||
                    dispersion.TermDate == null);
        }

        public static IEnumerable<DispersionDto> GetInvalidDispersionDtos(
            this IEnumerable<DispersionDto> dispersions)
        {
            return dispersions
                .Where(y =>
                    y.IsInvalidDispersion);

        }

        public static IEnumerable<DispersionDto> GetValidDispersionDtos(
            this IEnumerable<DispersionDto> dispersions)
        {
            return dispersions
                .Where(y =>
                    !y.IsInvalidDispersion);
        }

        public static decimal GetCollectionRate(
        this IEnumerable<DispersionDto> dispersions)
        {
            var currentDispersions =
                dispersions
                    .GetCurrentDispersionDtos();

            return currentDispersions
                .Sum(d => d.DistributionRate);
        }

        public static decimal GetParishCollectionRate(
        this IEnumerable<DispersionDto> dispersions)
        {
            var parishJurisdictionType = 1;
            var current =
                dispersions.GetCurrentDispersionDtos();

            return current
                .Where(t => t.Jurisdiction.JurisdictionTypeId == parishJurisdictionType)
                .Sum(d => d.DistributionRate);
        }

        public static decimal GetMunicipalityCollectionRate(
        this IEnumerable<DispersionDto> dispersions)
        {
            var municipalityJurisdictionType = 2;
            var current =
                dispersions.GetCurrentDispersionDtos();

            return current
                .Where(t => t.Jurisdiction.JurisdictionTypeId == municipalityJurisdictionType)
                .Sum(d => d.DistributionRate);
        }

        public static decimal GetVendorCompensationRate(
            this DispersionDto dispersion,
            decimal collectionRate)
        {
            if (dispersion.VendorComp == 0.0m ||
                dispersion.DistributionRate == 0.0m ||
                collectionRate == 0.0m)
            {
                return 0.0m;
            }

            return (dispersion.DistributionRate / collectionRate)
                   * dispersion.VendorComp;
        }


        public static bool IsInFuture(this DispersionDto dispersionDto)
        {
            return dispersionDto.EffectiveDate > DateTimeOffset.Now;
        }
    }
}
