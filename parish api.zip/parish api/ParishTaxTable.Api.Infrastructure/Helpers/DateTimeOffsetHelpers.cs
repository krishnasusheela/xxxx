﻿using System;

namespace ParishTaxTable.Api.Infrastructure.Helpers
{
    public static class DateTimeOffsetHelpers
    {
        public static DateTimeOffset? EndOfDay(this DateTimeOffset? dateTimeOffset)
        {
            return dateTimeOffset?.EndOfDay();
        }

        public static DateTimeOffset EndOfDay(this DateTimeOffset dateTimeOffset)
        {
            return (DateTimeOffset)dateTimeOffset.Date.AddTicks(-1).AddDays(1);
        }
    }
}
