﻿using System;
using System.Linq;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Infrastructure.Helpers
{
    public static class ContactDtoHelpers
    {
        public static IQueryable<ContactDto> GetCurrentContactDtos(
            this IQueryable<ContactDto> contacts)
        {
            return contacts
                .Where(y =>
                    y.CreateDate <= DateTimeOffset.Now
                    && (y.RetireDate == null || y.RetireDate >= DateTimeOffset.Now));
        }
    }
}
