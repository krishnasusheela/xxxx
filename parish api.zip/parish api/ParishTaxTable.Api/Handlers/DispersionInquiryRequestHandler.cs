﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class DispersionInquiryRequestHandler
            : IRequestHandler<DispersionInquiryRequest, Dispersion>
    {
        private readonly IDispersionDataService dispersionDataService;

        public DispersionInquiryRequestHandler(
            IDispersionDataService dispersionDataService)
        {
            this.dispersionDataService = dispersionDataService;
        }
        
        public async Task<Dispersion> Handle(
            DispersionInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await dispersionDataService.GetDispersionById(request.Id);
        }
    }
}
