﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class JurisdictionInquiryRequestHandler
            : IRequestHandler<JurisdictionInquiryRequest, Jurisdiction>
    {
        private readonly IJurisdictionDataService jurisdictionDataService;

        public JurisdictionInquiryRequestHandler(
            IJurisdictionDataService jurisdictionDataService)
        {
            this.jurisdictionDataService = jurisdictionDataService;
        }

        public async Task<Jurisdiction> Handle(
            JurisdictionInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await jurisdictionDataService.GetJurisdictionById(request.Id);
        }
    }
}
