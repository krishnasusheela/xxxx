﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class ContactRetireRequestHandler
            : IRequestHandler<ContactRetireRequest, Contact>
    {
        private readonly IContactDataService contactDataService;

        public ContactRetireRequestHandler(
            IContactDataService contactDataService)
        {
            this.contactDataService = contactDataService;
        }

        public async Task<Contact> Handle(
            ContactRetireRequest request, 
            CancellationToken cancellationToken)
        {
            return await contactDataService.RetireContact(request.Id);
        }
    }
}

