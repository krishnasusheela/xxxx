﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class DomicileInquiryRequestHandler
            : IRequestHandler<DomicileInquiryRequest, Domicile>
    {
        private readonly IDomicileDataService parishDataService;

        public DomicileInquiryRequestHandler(
            IDomicileDataService parishDataService)
        {
            this.parishDataService = parishDataService;
        }

        public async Task<Domicile> Handle(
            DomicileInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            if (request.Date.HasValue)
            {
              return await parishDataService.GetDomicileByIdAndDate(request.Id, request.Date.Value);
            }

            return await parishDataService.GetDomicileById(request.Id );
        }

       
    }
}
