﻿using MediatR;
using ParishTaxTable.Api.Requests;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;

namespace ParishTaxTable.Api.Handlers
{
    public class JurisdictionTypesInquiryRequestHandler
        : IRequestHandler<JurisdictionTypesInquiryRequest, IEnumerable<JurisdictionType>>
    {
        private readonly IJurisdictionTypeDataService jurisdictionTypeDataService;

        public JurisdictionTypesInquiryRequestHandler(
            IJurisdictionTypeDataService jurisdictionTypeDataService)
        {
            this.jurisdictionTypeDataService = jurisdictionTypeDataService;
        }

        public async Task<IEnumerable<JurisdictionType>> Handle(
            JurisdictionTypesInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await jurisdictionTypeDataService
                .GetAllJurisdictionTypes();
        }
    }
}
