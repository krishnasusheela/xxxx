﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class ContactInquiryRequestHandler
            : IRequestHandler<ContactInquiryRequest, Contact>
    {
        private readonly IContactDataService contactDataService;

        public ContactInquiryRequestHandler(
            IContactDataService contactDataService)
        {
            this.contactDataService = contactDataService;
        }

        public async Task<Contact> Handle(
            ContactInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await contactDataService.GetContactById(request.Id);
        }
    }
}

