﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class ParishesInquiryRequestHandler
        : IRequestHandler<ParishesInquiryRequest, IEnumerable<Parish>>
    {
        private readonly IParishDataService parishDataService;

        public ParishesInquiryRequestHandler(
            IParishDataService parishDataService)
        {
            this.parishDataService = parishDataService;
        }

        public async Task<IEnumerable<Parish>> Handle(
            ParishesInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await parishDataService
                .GetAllParishes();
        }
    }
}
