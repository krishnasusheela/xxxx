﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class ParishContactsInquiryRequestHandler
            : IRequestHandler<ParishContactsInquiryRequest, IEnumerable<ParishContact>>
    {
        private readonly IParishContactDataService parishContactDataService;

        public ParishContactsInquiryRequestHandler(
            IParishContactDataService parishContactDataService)
        {
            this.parishContactDataService = parishContactDataService;
        }

        public async Task<IEnumerable<ParishContact>> Handle(ParishContactsInquiryRequest request, CancellationToken cancellationToken)
        {
            return await parishContactDataService
                .GetAllParishContacts();
        }
    }
}
