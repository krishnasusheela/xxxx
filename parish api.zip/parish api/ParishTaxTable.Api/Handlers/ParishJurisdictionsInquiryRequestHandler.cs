﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class ParishJurisdictionsInquiryRequestHandler
            : IRequestHandler<ParishJurisdictionsInquiryRequest, IEnumerable<ParishJurisdiction>>
    {
        private readonly IParishJurisdictionDataService parishJurisdictionDataService;

        public ParishJurisdictionsInquiryRequestHandler(
            IParishJurisdictionDataService parishJurisdictionDataService)
        {
            this.parishJurisdictionDataService = parishJurisdictionDataService;
        }

        public async Task<IEnumerable<ParishJurisdiction>> Handle(
            ParishJurisdictionsInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await parishJurisdictionDataService
                .GetAllParishJurisdictions();
        }
    }
}
