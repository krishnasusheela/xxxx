﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class ParishDomicilesInquiryRequestHandler
            : IRequestHandler<ParishDomicilesInquiryRequest, IEnumerable<ParishDomicile>>
    {
        private readonly IParishDomicileDataService parishDomicileDataService;

        public ParishDomicilesInquiryRequestHandler(
            IParishDomicileDataService parishDomicileDataService)
        {
            this.parishDomicileDataService = parishDomicileDataService;
        }

        public async Task<IEnumerable<ParishDomicile>> Handle(
            ParishDomicilesInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await parishDomicileDataService
                .GetAllParishDomiciles();
        }
    }
}
