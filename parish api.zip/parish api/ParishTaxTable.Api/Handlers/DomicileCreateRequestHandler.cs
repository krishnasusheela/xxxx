﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class DomicileCreateRequestHandler 
        : IRequestHandler<DomicileCreateRequest, Domicile>
    {
        private readonly IDomicileDataService domicileDataService;

        public DomicileCreateRequestHandler(
            IDomicileDataService domicileDataService)
        {
            this.domicileDataService = domicileDataService;
        }

        public async Task<Domicile> Handle(
            DomicileCreateRequest request, 
            CancellationToken cancellationToken)
        {
            return await domicileDataService.CreateDomicile(request.Domicile);
        }
    }
}
