﻿using MediatR;
using ParishTaxTable.Api.Requests;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;

namespace ParishTaxTable.Api.Handlers
{
    public class JurisdictionsInquiryRequestHandler
        : IRequestHandler<JurisdictionsInquiryRequest, IEnumerable<Jurisdiction>>
    {
        private readonly IJurisdictionDataService jurisdictionDataService;

        public JurisdictionsInquiryRequestHandler(
            IJurisdictionDataService jurisdictionDataService)
        {
            this.jurisdictionDataService = jurisdictionDataService;
        }

        public async Task<IEnumerable<Jurisdiction>> Handle(
            JurisdictionsInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await jurisdictionDataService
                .GetAllJurisdictions();
        }
    }
}
