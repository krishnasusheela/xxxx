﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class DomicileCodeInquiryRequestHandler
        : IRequestHandler<DomicileCodeInquiryRequest, Domicile>
    {
        private readonly IDomicileDataService domicileDataService;

        public DomicileCodeInquiryRequestHandler(IDomicileDataService domicileDataService)
        {
            this.domicileDataService = domicileDataService;
        }
        public async Task<Domicile> Handle(
            DomicileCodeInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await domicileDataService.GetDomicileCodeByCode(request.Code);
        }
    }
}
