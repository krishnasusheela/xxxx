﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class ContactUpdateRequestHandler
            : IRequestHandler<ContactUpdateRequest, Contact>
    {
        private readonly IContactDataService contactDataService;

        public ContactUpdateRequestHandler(
            IContactDataService contactDataService)
        {
            this.contactDataService = contactDataService;
        }

        public async Task<Contact> Handle(
            ContactUpdateRequest request, 
            CancellationToken cancellationToken)
        {
            return await contactDataService.UpdateContact(request.Contact);
        }
    }
}
