﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class ParishInquiryRequestHandler
        : IRequestHandler<ParishInquiryRequest, Parish>
    {
        private readonly IParishDataService parishDataService;

        public ParishInquiryRequestHandler(
            IParishDataService parishDataService)
        {
            this.parishDataService = parishDataService;
        }

        public async Task<Parish> Handle(
            ParishInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await parishDataService
                .GetParishById(request.Id);
        }
    }
}
