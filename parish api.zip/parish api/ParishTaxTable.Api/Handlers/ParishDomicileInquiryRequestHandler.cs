﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class ParishDomicileInquiryRequestHandler
            : IRequestHandler<ParishDomicileInquiryRequest, ParishDomicile>
    {
        private readonly IParishDomicileDataService parishDomicileDataService;

        public ParishDomicileInquiryRequestHandler(
            IParishDomicileDataService parishDomicileDataService)
        {
            this.parishDomicileDataService = parishDomicileDataService;
        }
        
        public async Task<ParishDomicile> Handle(
            ParishDomicileInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await parishDomicileDataService
                .GetDomicileParishById(request.Id);
        }
    }
}
