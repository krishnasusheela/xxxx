﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class JurisdictionUpdateRequestHandler
        : IRequestHandler<JurisdictionUpdateRequest, Jurisdiction>
    {
        private readonly IJurisdictionDataService jurisdictionDataService;

        public JurisdictionUpdateRequestHandler(
            IJurisdictionDataService jurisdictionDataService)
        {
            this.jurisdictionDataService = jurisdictionDataService;
        }

        public async Task<Jurisdiction> Handle(
            JurisdictionUpdateRequest request, 
            CancellationToken cancellationToken)
        {
            return await jurisdictionDataService.UpdateJurisdiction(request.Jurisdiction);
        }
    }
}
