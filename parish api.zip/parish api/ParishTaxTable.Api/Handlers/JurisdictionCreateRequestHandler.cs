﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class JurisdictionCreateRequestHandler
        : IRequestHandler<JurisdictionCreateRequest, Jurisdiction>
    {
        private readonly IJurisdictionDataService jurisdictionDataService;

        public JurisdictionCreateRequestHandler(
            IJurisdictionDataService jurisdictionDataService)
        {
            this.jurisdictionDataService = jurisdictionDataService;
        }
        
        public async Task<Jurisdiction> Handle(
            JurisdictionCreateRequest request, 
            CancellationToken cancellationToken)
        {
            return await jurisdictionDataService
                .CreateJurisdiction(request.Jurisdiction);
        }
    }
}
