﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class DispersionDeleteRequestHandler
        : IRequestHandler<DispersionDeleteRequest>
    {
        private readonly IDispersionDataService dispersionDataService;

        public DispersionDeleteRequestHandler(
            IDispersionDataService dispersionDataService)
        {
            this.dispersionDataService = dispersionDataService;
        }

        public async Task<Unit> Handle(
            DispersionDeleteRequest request, 
            CancellationToken cancellationToken)
        {
            await dispersionDataService.DeleteDispersion(request.Id);
            return Unit.Value;
        }
    }
}
