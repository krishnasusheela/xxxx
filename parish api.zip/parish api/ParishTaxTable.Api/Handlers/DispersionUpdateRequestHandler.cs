﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class DispersionUpdateRequestHandler
            : IRequestHandler<DispersionUpdateRequest, Dispersion>
    {
        private readonly IDispersionDataService dispersionDataService;

        public DispersionUpdateRequestHandler(
            IDispersionDataService dispersionDataService)
        {
            this.dispersionDataService = dispersionDataService;
        }

        public async Task<Dispersion> Handle(
            DispersionUpdateRequest request, 
            CancellationToken cancellationToken)
        {
            return await dispersionDataService.UpdateDispersion(request.Dispersion);
        }
    }
}
