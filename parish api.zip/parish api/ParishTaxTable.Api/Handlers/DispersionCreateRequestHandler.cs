﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class DispersionCreateRequestHandler
        : IRequestHandler<DispersionCreateRequest, Dispersion>
    {
        private readonly IDispersionDataService dispersionDataService;

        public DispersionCreateRequestHandler(
            IDispersionDataService dispersionDataService)
        {
            this.dispersionDataService = dispersionDataService;
        }

        public async Task<Dispersion> Handle(
            DispersionCreateRequest request,
            CancellationToken cancellationToken)
        {
            if (request.InvalidatedId.HasValue)
                return await dispersionDataService.ReplaceDispersion(request.Dispersion, request.InvalidatedId.Value);

            return await dispersionDataService.CreateDispersion(request.Dispersion);
        }
    }
}
