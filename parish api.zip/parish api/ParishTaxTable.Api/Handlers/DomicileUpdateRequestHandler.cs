﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class DomicileUpdateRequestHandler
            : IRequestHandler<DomicileUpdateRequest, Domicile>
    {
        private readonly IDomicileDataService parishDataService;

        public DomicileUpdateRequestHandler(
            IDomicileDataService parishDataService)
        {
            this.parishDataService = parishDataService;
        }

        public async Task<Domicile> Handle(
            DomicileUpdateRequest request, 
            CancellationToken cancellationToken)
        {
            return await parishDataService.UpdateDomicile(request.Domicile);
        }
    }
}
