﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Handlers
{
    public class ParishContactInquiryRequestHandler
            : IRequestHandler<ParishContactInquiryRequest, ParishContact>
    {
        private readonly IParishContactDataService parishContactDataService;

        public ParishContactInquiryRequestHandler(
            IParishContactDataService parishContactDataService)
        {
            this.parishContactDataService = parishContactDataService;
        }

        public async Task<ParishContact> Handle(
            ParishContactInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await parishContactDataService
                .GetParishContactsById(request.Id);
        }
    }
}
