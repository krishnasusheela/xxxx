﻿using System.Reflection;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Repositories;
using ParishTaxTable.Api.Infrastructure.Rules.Contacts;
using ParishTaxTable.Api.Infrastructure.Rules.Dispersions;
using ParishTaxTable.Api.Infrastructure.Rules.Domiciles;
using ParishTaxTable.Api.Infrastructure.Rules.Jurisdictions;
using ParishTaxTable.Api.Infrastructure.Services;

namespace ParishTaxTable.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMediatR(
                typeof(Startup)
                .GetTypeInfo()
                .Assembly);

            services.AddDbContext<ParishTaxTableContext>(
                opt => opt.UseSqlServer(
                    Configuration.GetConnectionString("DatabaseConnection")));

            services.AddScoped<IContactRepository, ContactRepository>();
            services.AddScoped<IParishRepository, ParishRepository>();
            services.AddScoped<IJurisdictionRepository, JurisdictionRepository>();
            services.AddScoped<IJurisdictionTypeRepository, JurisdictionTypeRepository>();
            services.AddScoped<IDispersionRepository, DispersionRepository>();
            services.AddScoped<IDomicileRepository, DomicileRepository>();
            
            services.AddTransient<IParishDataService, ParishDataService>();
            services.AddTransient<IDomicileDataService, DomicileDataService>();
            services.AddTransient<IJurisdictionDataService, JurisdictionDataService>();
            services.AddTransient<IJurisdictionTypeDataService, JurisdictionTypeDataService>();
            services.AddTransient<IParishDomicileDataService, ParishDomicileDataService>();
            services.AddTransient<IDispersionDataService, DispersionDataService>();
            services.AddTransient<IParishContactDataService, ParishContactDataService>();
            services.AddTransient<IParishJurisdictionDataService, ParishJurisdictionDataService>();
            services.AddTransient<IContactDataService, ContactDataService>();

            services.AddTransient<IContactDeleteRules, ContactDeleteRules>();
            services.AddTransient<IDispersionUpdateRules, DispersionUpdateRules>();
            services.AddTransient<IDispersionCreateRules, DispersionCreateRules>();
            services.AddTransient<IDispersionDeleteRules, DispersionDeleteRules>();
            services.AddTransient<IDispersionReplaceRules, DispersionReplaceRules>();
            services.AddTransient<IDomicileCreateRules, DomicileCreateRules>();
            services.AddTransient<IDomicileUpdateRules, DomicileUpdateRules>();
            services.AddTransient<IJurisdictionUpdateRules, JurisdictionUpdateRules>();

            services.AddTransient<IDeleteContactRule, LastContactCannotBeRetiredRule>();
            services.AddTransient<IUpdateDispersionRule, ActiveDispersionsCanOnlyModifyTermDatesRule>();
            services.AddTransient<IUpdateDispersionRule, ModifiedEffectiveDateCannotBeInUseRule>();
            services.AddTransient<IUpdateDispersionRule, ModifiedTermDateCannotBeHistoricalRule>();
            services.AddTransient<IUpdateDispersionRule, ModifiedTermDateCannotBeBeforeEffectiveDateRule>();
            services.AddTransient<IUpdateDispersionRule, HistoricalDispersionsCanOnlyBeInvalidatedRule>();
            services.AddTransient<IDeleteDispersionRule, DeletedDispersionsMustHaveFutureEffectiveDate>();
            services.AddTransient<ICreateDispersionRule, CreatedDispersionMustHaveTermDateThatIsAfterEffectiveDateOrNull>();
            services.AddTransient<ICreateDispersionRule, CreatedDispersionMustNotHaveEffectiveDatePriorToDomicile>();
            services.AddTransient<IReplaceDispersionRule, CreatedDispersionMustNotHaveEffectiveDatePriorToDomicile>();
            services.AddTransient<ICreateDispersionRule, CreatedDispersionsMustHaveFutureEffectiveDate>();
            services.AddTransient<IReplaceDispersionRule, CreatedDispersionMustHaveTermDateThatIsAfterEffectiveDateOrNull>();
            services.AddTransient<IUpdateDomicileRule, UpdatedDomicileCannotChangeTermDateToPastDate>();
            services.AddTransient<IUpdateDomicileRule, UpdatedDomicileCannotBeModifiedIfDomicileIsExpired>();
            services.AddTransient<IUpdateDomicileRule, UpdatedDomicileMustHaveTermDateThatIsAfterEffectiveDateOrNull>();
            services.AddTransient<ICreateDomicileRule, CreatedDomicileMustHaveFutureEffectiveDate>();
            services.AddTransient<ICreateDomicileRule, CreatedDomicileMustHaveTermDateAfterEffectiveDateOrNullTermDate>();
            services.AddTransient<ICreateDomicileRule, CreatedDomicileCannotHaveSameCodeAsOtherDomiciles>();
            services.AddTransient<IUpdateJurisdictionRule, UpdateJurisdictionToRetireRequiresItNotBeingUsedByAnyActiveDispersions>();
            
            services.AddAutoMapper();
            services.AddMvc();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseMvc();
        }
    }
}
