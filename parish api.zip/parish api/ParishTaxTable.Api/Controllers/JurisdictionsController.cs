﻿using System;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Controllers
{
    [Route("api/[controller]")]
    public class JurisdictionsController : Controller
    {
        private readonly IMediator mediator;

        public JurisdictionsController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }


        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var result = await mediator.Send(new JurisdictionsInquiryRequest());

                if (result == null || !result.Any())
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var result = await mediator.Send(new JurisdictionInquiryRequest() { Id = id });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Jurisdiction jurisdiction)
        {
            try
            {
                int defaultIdValueForInsert = 0;

                if (jurisdiction.Id != defaultIdValueForInsert)
                    return BadRequest();

                var result = await mediator.Send(new JurisdictionCreateRequest() { Jurisdiction = jurisdiction });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (InvalidOperationException errorMessage)
            {
                return BadRequest(errorMessage.Message);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Jurisdiction jurisdiction)
        {
            try
            {
                if (id != jurisdiction.Id)
                    return BadRequest();

                var result = await mediator.Send(new JurisdictionUpdateRequest() { Jurisdiction = jurisdiction });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (InvalidOperationException errorMessage)
            {
                return BadRequest(errorMessage.Message);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
