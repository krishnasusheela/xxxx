﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Controllers
{
    [Route("api/[controller]")]
    public class DomicileCodesController
        : Controller
    {
        private readonly IMediator mediator;

        public DomicileCodesController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet("{code}")]
        public async Task<IActionResult> Get(string code)
        {
            try
            {
                var result = await mediator.Send(new DomicileCodeInquiryRequest() { Code = code });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
    
}
