﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using ParishTaxTable.Api.Requests;
using System.Linq;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Controllers
{
    [Route("api/[controller]")]
    public class DomicilesController
        : Controller
    {
        private readonly IMediator mediator;

        public DomicilesController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        // GET api/domiciles
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var result = await mediator.Send(new DomicilesInquiryRequest());

                if (result == null || !result.Any())
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // GET api/domiciles/17
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id , [FromQuery] DateTimeOffset? date)
        {
            try
            {
                var result = await mediator.Send(new DomicileInquiryRequest() { Id = id , Date = date });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Domicile domicile)
        {
            try
            {
                if (id != domicile.Id)
                    return BadRequest();

                var result = await mediator.Send(new DomicileUpdateRequest() { Domicile = domicile });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (InvalidOperationException errorMessage)
            {
                return BadRequest(errorMessage.Message);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Domicile domicile)
        {
            try
            {
                int defaultIdValueForInsert = 0;

                if (domicile.Id != defaultIdValueForInsert)
                    return BadRequest();
                var result = await mediator.Send(new DomicileCreateRequest() { Domicile = domicile });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (InvalidOperationException errorMessage)
            {
                return BadRequest(errorMessage.Message);
            }
            catch (Exception)
            {
                return BadRequest();
            }

        }
    }
}
