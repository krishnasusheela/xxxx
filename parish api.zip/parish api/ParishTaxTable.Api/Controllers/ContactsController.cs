﻿using System;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Controllers
{
    [Route("api/[controller]")]
    public class ContactsController
        : Controller
    {
        private readonly IMediator mediator;

        public ContactsController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var result = await mediator.Send(new ContactInquiryRequest() { Id = id });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Contact contact)
        {
            try
            {
                int defaultIdValueForInsert = 0;

                if (contact.Id != defaultIdValueForInsert)
                    return BadRequest();

                var result = await mediator.Send(new ContactCreateRequest() { Contact = contact });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (InvalidOperationException errorMessage)
            {
                return BadRequest(errorMessage.Message);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Retire(int id)
        {
            try
            {
                var result = await mediator.Send(new ContactRetireRequest() { Id = id });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Contact contact)
        {
            try
            {
                if (id != contact.Id)
                    return BadRequest();

                var result = await mediator.Send(new ContactUpdateRequest() { Contact = contact });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (InvalidOperationException errorMessage)
            {
                return BadRequest(errorMessage.Message);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
