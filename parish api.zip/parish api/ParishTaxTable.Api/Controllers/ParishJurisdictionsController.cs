﻿using System;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Api.Requests;

namespace ParishTaxTable.Api.Controllers
{
    [Route("api/[controller]")]
    public class ParishJurisdictionsController
     : Controller
    {
        private readonly IMediator mediator;

        public ParishJurisdictionsController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var result = await mediator.Send(new ParishJurisdictionsInquiryRequest());

                if (result == null || !result.Any())
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var result = await mediator.Send(new ParishJurisdictionInquiryRequest() { Id = id });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
