﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Api.Requests;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ParishTaxTable.Api.Controllers
{
    [Route("api/[controller]")]
    public class ParishDomicilesController
        : Controller
    {
        private readonly IMediator mediator;

        public ParishDomicilesController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        // GET api/parishdomiciles
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var result = await mediator.Send(new ParishDomicilesInquiryRequest());

                if (result == null || !result.Any())
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // GET api/parishdomiciles/17
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var result = await mediator.Send(new ParishDomicileInquiryRequest() { Id = id });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
