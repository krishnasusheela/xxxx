﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Api.Requests;
using System;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Controllers
{
    [Route("api/[controller]")]
    public class DispersionsController
    : Controller
    {
        private readonly IMediator mediator;

        public DispersionsController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var result = await mediator.Send(new DispersionInquiryRequest() { Id = id });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Dispersion dispersion)
        {
            try
            {
                if (id != dispersion.Id)
                    return BadRequest();

                var result = await mediator.Send(new DispersionUpdateRequest() { Dispersion = dispersion });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (InvalidOperationException errorMessage)
            {
                return BadRequest(errorMessage.Message);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Dispersion dispersion, [FromQuery] int? invalidatedId )
        {
            try
            {
                var defaultIdValueForInsert = 0;

                if (dispersion.Id != defaultIdValueForInsert)
                    return BadRequest();

                var result = await mediator.Send(new DispersionCreateRequest() { Dispersion = dispersion, InvalidatedId = invalidatedId });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (InvalidOperationException errorMessage)
            {
                return BadRequest(errorMessage.Message);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await mediator.Send(new DispersionDeleteRequest() { Id = id });

                return Ok();
            }
            catch (InvalidOperationException errorMessage)
            {
                return BadRequest(errorMessage.Message);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

    }
}
