﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Api.Requests;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ParishTaxTable.Api.Controllers
{
    [Route("api/[controller]")]
    public class ParishesController
        : Controller
    {
        private readonly IMediator mediator;

        public ParishesController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        // GET api/parishes
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var result = await mediator.Send(new ParishesInquiryRequest());

                if (result == null || !result.Any())
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }            
        }

        // GET api/parishes/17
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var result = await mediator.Send(new ParishInquiryRequest() { Id = id });

                if (result == null) 
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }            
        }

        // GET api/parishes/17/NextDomicileCode
        [HttpGet("{id}/NextDomicileCode")]
        public async Task<IActionResult> GetNextDomicileCode(int id)
        {
            try
            {
                var result = await mediator.Send(new ParishNextDomicileCodeInquiryRequest() { Id = id });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
