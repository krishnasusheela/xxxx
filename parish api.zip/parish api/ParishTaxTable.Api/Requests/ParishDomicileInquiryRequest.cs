﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class ParishDomicileInquiryRequest : IRequest<ParishDomicile>
    {
        public int Id { get; set; }
    }
}
