﻿using System.Collections.Generic;
using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class ParishJurisdictionsInquiryRequest : IRequest<IEnumerable<ParishJurisdiction>>
    {
    }
}
