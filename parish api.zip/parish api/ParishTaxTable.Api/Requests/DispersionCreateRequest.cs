﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class DispersionCreateRequest
    : IRequest<Dispersion>
    {
        public Dispersion Dispersion { get; set; }
        public int? InvalidatedId { get; set; }
    }
}
