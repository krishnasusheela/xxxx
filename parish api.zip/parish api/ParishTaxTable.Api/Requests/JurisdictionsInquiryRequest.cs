﻿using MediatR;
using System.Collections.Generic;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class JurisdictionsInquiryRequest
         : IRequest<IEnumerable<Jurisdiction>>
    {
    }
}
