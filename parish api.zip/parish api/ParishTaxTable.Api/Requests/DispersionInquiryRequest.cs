﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class DispersionInquiryRequest : IRequest<Dispersion>
    {
        public int Id { get; set; }
    }
}
