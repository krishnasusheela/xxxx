﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class JurisdictionCreateRequest
        : IRequest<Jurisdiction>
    {
        public Jurisdiction Jurisdiction { get; set; }
    }
}
