﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class JurisdictionUpdateRequest : IRequest<Jurisdiction>
    {
        public Jurisdiction Jurisdiction { get; set; }
    }
}
