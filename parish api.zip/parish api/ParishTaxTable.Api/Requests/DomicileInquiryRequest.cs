﻿using System;
using MediatR;
using ParishTaxTable.Api.Core.Entities;


namespace ParishTaxTable.Api.Requests
{
    public class DomicileInquiryRequest : IRequest<Domicile>
    {
        public int Id { get; set; }
        public DateTimeOffset? Date { get;  set; }
    }
}
