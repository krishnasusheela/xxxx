﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class DomicileCodeInquiryRequest : IRequest<Domicile>
    {
        public string Code { get; set; }    
    }
}
