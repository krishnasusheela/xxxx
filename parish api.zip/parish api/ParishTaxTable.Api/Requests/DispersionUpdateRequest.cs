﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class DispersionUpdateRequest : IRequest<Dispersion>
    {
        public Dispersion Dispersion { get; set; }
    }
}
