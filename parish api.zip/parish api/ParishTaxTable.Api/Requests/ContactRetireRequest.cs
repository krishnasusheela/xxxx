﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class ContactRetireRequest : IRequest<Contact>
    {
        public int Id { get; set; }
    }
}
