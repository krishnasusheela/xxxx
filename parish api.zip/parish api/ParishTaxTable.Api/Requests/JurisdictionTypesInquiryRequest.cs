﻿using System.Collections.Generic;
using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class JurisdictionTypesInquiryRequest
        : IRequest<IEnumerable<JurisdictionType>>
    {
    }
}
