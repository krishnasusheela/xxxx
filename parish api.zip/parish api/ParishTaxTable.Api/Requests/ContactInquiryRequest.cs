﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class ContactInquiryRequest : IRequest<Contact>
    {
        public int Id { get; set; }
    }
}
