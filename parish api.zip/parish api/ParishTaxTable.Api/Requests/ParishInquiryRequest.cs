﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class ParishInquiryRequest : IRequest<Parish>
    {
        public int Id { get; set; }
    }
}
