﻿using MediatR;
using System.Collections.Generic;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class ParishDomicilesInquiryRequest : IRequest<IEnumerable<ParishDomicile>>
    {
    }
}
