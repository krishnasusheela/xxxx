﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class DomicileCreateRequest 
        : IRequest<Domicile>
    {
        public Domicile Domicile { get; set; }
    }
}
