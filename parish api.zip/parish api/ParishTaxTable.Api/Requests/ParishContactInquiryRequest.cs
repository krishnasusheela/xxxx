﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class ParishContactInquiryRequest : IRequest<ParishContact>
    {
        public int Id { get; set; }
    }
}
