﻿using MediatR;

namespace ParishTaxTable.Api.Requests
{
    public class DispersionDeleteRequest : IRequest
    {
        public int Id { get; set; }
    }
}
