﻿using MediatR;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Requests
{
    public class ContactUpdateRequest : IRequest<Contact>
    {
        public Contact Contact { get; set; }
    }
}
