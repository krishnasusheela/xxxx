﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class ParishContactsInquiryRequestHandlerTests
       : IDisposable

    {
        private ParishContactsInquiryRequestHandler handler;
        private Mock<IParishContactDataService> dataServiceMock;
        private Fixture fixture;

        public ParishContactsInquiryRequestHandlerTests()
        {
            fixture = new Fixture();

            dataServiceMock =
                new Mock<IParishContactDataService>();

            handler = new ParishContactsInquiryRequestHandler(
                dataServiceMock.Object);
        }

        public void Dispose()
        {
            dataServiceMock = null;
            handler = null;
            fixture = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(
                handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var request =
                fixture.Create<ParishContactsInquiryRequest>();

            dataServiceMock
                .Setup(m => m.GetAllParishContacts())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var request =
                fixture.Create<ParishContactsInquiryRequest>();

            var expected =
                fixture.Create<List<ParishContact>>();

            dataServiceMock
                .Setup(m => m.GetAllParishContacts())
                .ReturnsAsync(expected);

            var actual =
                await handler.Handle(
                    request,
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                actual);
        }
    }
}
