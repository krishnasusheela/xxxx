﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class JurisdictionCreateRequestHandlerTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<IJurisdictionDataService> serviceMock;
        private JurisdictionCreateRequestHandler handler;

        public JurisdictionCreateRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IJurisdictionDataService>();

            handler = new JurisdictionCreateRequestHandler(
                serviceMock.Object);
        }
        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(
                handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var request = fixture
                .Create<JurisdictionCreateRequest>();

            serviceMock
                .Setup(m => m.CreateJurisdiction(request.Jurisdiction))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var request = fixture
                .Create<JurisdictionCreateRequest>();

            var expected = fixture
                .Create<Jurisdiction>();

            serviceMock
                .Setup(m => m.CreateJurisdiction(request.Jurisdiction))
                .ReturnsAsync(expected);

            var actual = await handler
                .Handle(request, default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                actual);
        }
    }
}
