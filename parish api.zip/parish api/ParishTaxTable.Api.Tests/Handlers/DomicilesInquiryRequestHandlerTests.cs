﻿using AutoFixture;
using Moq;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using System;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;


namespace ParishTaxTable.Api.Tests.Handlers
{
    public class DomicilesInquiryRequestHandlerTests
        : IDisposable
    {
        private DomicilesInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IDomicileDataService> mockDomicileDataService;

        public DomicilesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockDomicileDataService = new Mock<IDomicileDataService>();

            handler = new DomicilesInquiryRequestHandler(
                mockDomicileDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockDomicileDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            mockDomicileDataService
                .Setup(m => m.GetAllDomiciles())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new DomicilesInquiryRequest(),
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.CreateMany<Domicile>();

            mockDomicileDataService
                .Setup(m => m.GetAllDomiciles())
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new DomicilesInquiryRequest(),
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
