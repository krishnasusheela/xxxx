﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class DispersionCreateRequestHandlerTests
        : IDisposable

    {
        private DispersionCreateRequestHandler handler;
        private Mock<IDispersionDataService> dataServiceMock;
        private Fixture fixture;

        public DispersionCreateRequestHandlerTests()
        {
            fixture = new Fixture();

            dataServiceMock =
                new Mock<IDispersionDataService>();

            handler = new DispersionCreateRequestHandler(
                dataServiceMock.Object);
        }

        public void Dispose()
        {
            dataServiceMock = null;
            handler = null;
            fixture = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(
                handler);
        }

        [Fact]
        public async Task HandlerWithoutInvalidatedIdThrowsExceptionWhenDataServiceThrowsException()
        {
            var request = fixture
                    .Build<DispersionCreateRequest>()
                    .Without(x => x.InvalidatedId)
                    .Create();

            dataServiceMock
                .Setup(m => m.CreateDispersion(request.Dispersion))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerWithoutInvalidatedIdReturnsExpected()
        {
            var request = fixture
                .Build<DispersionCreateRequest>()
                .Without(x => x.InvalidatedId)
                .Create();

            dataServiceMock
                .Setup(m => m.CreateDispersion(request.Dispersion))
                .ReturnsAsync(request.Dispersion);

            var actual =
                await handler.Handle(
                    request,
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                request.Dispersion,
                actual);
        }

        [Fact]
        public async Task HandlerWithInvalidatedIdThrowsExceptionWhenDataServiceThrowsException()
        {
            var requestInvalidatedId = fixture.Create<int>();

            var request = fixture
                .Build<DispersionCreateRequest>()
                .With(x => x.InvalidatedId, requestInvalidatedId)
                .Create();

            dataServiceMock
                .Setup(m => m.ReplaceDispersion(request.Dispersion,request.InvalidatedId.Value))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerWithInvalidatedIdReturnsExpected()
        {
            var requestInvalidatedId = fixture.Create<int>();

            var request = fixture
                .Build<DispersionCreateRequest>()
                .With(x => x.InvalidatedId, requestInvalidatedId)
                .Create();

            dataServiceMock
                .Setup(m => m.ReplaceDispersion(request.Dispersion, request.InvalidatedId.Value))
                .ReturnsAsync(request.Dispersion);

            var actual =
                await handler.Handle(
                    request,
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                request.Dispersion,
                actual);
        }

    }
}
