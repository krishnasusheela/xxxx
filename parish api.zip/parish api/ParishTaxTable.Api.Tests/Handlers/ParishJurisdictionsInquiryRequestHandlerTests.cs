﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class ParishJurisdictionsInquiryRequestHandlerTests
       : IDisposable

    {
        private ParishJurisdictionsInquiryRequestHandler handler;
        private Mock<IParishJurisdictionDataService> dataServiceMock;
        private Fixture fixture;

        public ParishJurisdictionsInquiryRequestHandlerTests()
        {
            fixture = new Fixture();

            dataServiceMock =
                new Mock<IParishJurisdictionDataService>();

            handler = new ParishJurisdictionsInquiryRequestHandler(
                dataServiceMock.Object);
        }

        public void Dispose()
        {
            dataServiceMock = null;
            handler = null;
            fixture = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(
                handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var request =
                fixture.Create<ParishJurisdictionsInquiryRequest>();

            dataServiceMock
                .Setup(m => m.GetAllParishJurisdictions())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var request =
                fixture.Create<ParishJurisdictionsInquiryRequest>();

            var expected =
                fixture.Create<List<ParishJurisdiction>>();

            dataServiceMock
                .Setup(m => m.GetAllParishJurisdictions())
                .ReturnsAsync(expected);

            var actual =
                await handler.Handle(
                    request,
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                actual);
        }
    }
}
