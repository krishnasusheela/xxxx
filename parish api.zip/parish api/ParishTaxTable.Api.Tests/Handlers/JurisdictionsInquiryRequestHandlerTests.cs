﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class JurisdictionsInquiryRequestHandlerTests
        : IDisposable

    {
        private JurisdictionsInquiryRequestHandler handler;
        private Mock<IJurisdictionDataService> dataServiceMock;
        private Fixture fixture;

        public JurisdictionsInquiryRequestHandlerTests()
        {
            fixture = new Fixture();

            dataServiceMock =
                new Mock<IJurisdictionDataService>();

            handler = new JurisdictionsInquiryRequestHandler(
                dataServiceMock.Object);
        }

        public void Dispose()
        {
            dataServiceMock = null;
            handler = null;
            fixture = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(
                handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var request =
                fixture.Create<JurisdictionsInquiryRequest>();

            dataServiceMock
                .Setup(m => m.GetAllJurisdictions())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var request =
                fixture.Create<JurisdictionsInquiryRequest>();

            var expected =
                fixture.Create<List<Jurisdiction>>();

            dataServiceMock
                .Setup(m => m.GetAllJurisdictions())
                .ReturnsAsync(expected);

            var actual =
                await handler.Handle(
                    request,
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                actual);
        }
    }
}
