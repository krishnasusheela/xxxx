﻿using AutoFixture;
using Moq;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using System;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class ParishInquiryRequestHandlerTests
        : IDisposable
    {
        private ParishInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IParishDataService> mockParishDataService;

        public ParishInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockParishDataService = new Mock<IParishDataService>();

            handler = new ParishInquiryRequestHandler(
                mockParishDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockParishDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var expected = fixture.Create<Parish>();

            mockParishDataService
                .Setup(m => m.GetParishById(expected.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new ParishInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Parish>();

            mockParishDataService
                .Setup(m => m.GetParishById(expected.Id))
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new ParishInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
