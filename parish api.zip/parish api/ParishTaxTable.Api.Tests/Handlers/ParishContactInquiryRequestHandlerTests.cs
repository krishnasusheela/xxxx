﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class ParishContactInquiryRequestHandlerTests
        : IDisposable
    {
        private ParishContactInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IParishContactDataService> mockParishDataService;

        public ParishContactInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockParishDataService = new Mock<IParishContactDataService>();

            handler = new ParishContactInquiryRequestHandler(
                mockParishDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockParishDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var expected = fixture.Create<ParishContact>();

            mockParishDataService
                .Setup(m => m.GetParishContactsById(expected.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new ParishContactInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<ParishContact>();

            mockParishDataService
                .Setup(m => m.GetParishContactsById(expected.Id))
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new ParishContactInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
