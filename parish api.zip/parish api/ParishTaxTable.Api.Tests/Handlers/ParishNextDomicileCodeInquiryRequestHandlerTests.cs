﻿using AutoFixture;
using Moq;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using System;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class ParishNextDomicileCodeInquiryRequestHandlerTests
        : IDisposable
    {
        private ParishNextDomicileCodeInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IParishDomicileDataService> mockParishDataService;

        public ParishNextDomicileCodeInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockParishDataService = new Mock<IParishDomicileDataService>();

            handler = new ParishNextDomicileCodeInquiryRequestHandler(
                mockParishDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockParishDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var expectedId =
                fixture.Create<int>();

            mockParishDataService
                .Setup(m => m.GetNextParishDomicileCode(expectedId))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new ParishNextDomicileCodeInquiryRequest() { Id = expectedId },
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<ParishNextDomicileCode>();

            var expectedId =
                fixture.Create<int>();

            mockParishDataService
                .Setup(m => m.GetNextParishDomicileCode(expectedId))
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new ParishNextDomicileCodeInquiryRequest() { Id = expectedId },
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
