﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class DomicileCreateRequestHandlerTests
        : IDisposable

    {
        private DomicileCreateRequestHandler handler;
        private Mock<IDomicileDataService> dataServiceMock;
        private Fixture fixture;

        public DomicileCreateRequestHandlerTests()
        {
            fixture = new Fixture();

            dataServiceMock =
                new Mock<IDomicileDataService>();

            handler = new DomicileCreateRequestHandler(
                dataServiceMock.Object);
        }

        public void Dispose()
        {
            dataServiceMock = null;
            handler = null;
            fixture = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(
                handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var request =
                fixture.Create<DomicileCreateRequest>();

            dataServiceMock
                .Setup(m => m.CreateDomicile(request.Domicile))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var request =
                fixture.Create<DomicileCreateRequest>();

            var expected =
                fixture.Create<Domicile>();

            dataServiceMock
                .Setup(m => m.CreateDomicile(request.Domicile))
                .ReturnsAsync(expected);

            var actual =
                await handler.Handle(
                    request,
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                actual);
        }
    }
}
