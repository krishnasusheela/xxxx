﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class ContactInquiryRequestHandlerTests
        : IDisposable
    {
        private ContactInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IContactDataService> mockParishDataService;

        public ContactInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockParishDataService = new Mock<IContactDataService>();

            handler = new ContactInquiryRequestHandler(
                mockParishDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockParishDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var expected = fixture.Create<Contact>();

            mockParishDataService
                .Setup(m => m.GetContactById(expected.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new ContactInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Contact>();

            mockParishDataService
                .Setup(m => m.GetContactById(expected.Id))
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new ContactInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
