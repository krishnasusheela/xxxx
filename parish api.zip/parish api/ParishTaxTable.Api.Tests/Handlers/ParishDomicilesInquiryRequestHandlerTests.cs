﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class ParishDomicilesInquiryRequestHandlerTests
        : IDisposable

    {
        private ParishDomicilesInquiryRequestHandler handler;
        private Mock<IParishDomicileDataService> dataServiceMock;
        private Fixture fixture;

        public ParishDomicilesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();

            dataServiceMock =
                new Mock<IParishDomicileDataService>();

            handler = new ParishDomicilesInquiryRequestHandler(
                dataServiceMock.Object);
        }

        public void Dispose()
        {
            dataServiceMock = null;
            handler = null;
            fixture = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(
                handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var request =
                fixture.Create<ParishDomicilesInquiryRequest>();

            dataServiceMock
                .Setup(m => m.GetAllParishDomiciles())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var request =
                fixture.Create<ParishDomicilesInquiryRequest>();

            var expected =
                fixture.Create<List<ParishDomicile>>();

            dataServiceMock
                .Setup(m => m.GetAllParishDomiciles())
                .ReturnsAsync(expected);

            var actual =
                await handler.Handle(
                    request,
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                actual);
        }
    }
}
