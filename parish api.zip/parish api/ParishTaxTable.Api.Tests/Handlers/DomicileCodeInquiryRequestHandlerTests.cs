﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class DomicileCodeInquiryRequestHandlerTests
    : IDisposable
    {

        private DomicileCodeInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IDomicileDataService> mockDomicileDataService;

        public DomicileCodeInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockDomicileDataService = new Mock<IDomicileDataService>();

            handler = new DomicileCodeInquiryRequestHandler(
                mockDomicileDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockDomicileDataService = null;
        }



        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var expected = fixture.Create<Domicile>();

            mockDomicileDataService
                .Setup(m => m.GetDomicileCodeByCode(expected.ParishCode + expected.DomicileCode))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new DomicileCodeInquiryRequest() { Code = expected.ParishCode+expected.DomicileCode },
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Domicile>();

            mockDomicileDataService
                .Setup(m => m.GetDomicileCodeByCode(expected.ParishCode + expected.DomicileCode))
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new DomicileCodeInquiryRequest() { Code = expected.ParishCode + expected.DomicileCode },
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
