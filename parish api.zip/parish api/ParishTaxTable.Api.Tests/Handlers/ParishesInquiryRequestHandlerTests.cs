﻿using AutoFixture;
using Moq;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using System;
using System.Linq;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class ParishesInquiryRequestHandlerTests
        : IDisposable
    {
        private ParishesInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IParishDataService> mockParishDataService;

        public ParishesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockParishDataService = new Mock<IParishDataService>();

            handler = new ParishesInquiryRequestHandler(
                mockParishDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockParishDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            mockParishDataService
                .Setup(m => m.GetAllParishes())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new ParishesInquiryRequest(),
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture
                .CreateMany<Parish>()
                .ToList();

            mockParishDataService
                .Setup(m => m.GetAllParishes())
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new ParishesInquiryRequest(),
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }        
    }
}
