﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class DispersionUpdateRequestHandlerTests
        : IDisposable

    {
        private DispersionUpdateRequestHandler handler;
        private Mock<IDispersionDataService> dataServiceMock;
        private Fixture fixture;

        public DispersionUpdateRequestHandlerTests()
        {
            fixture = new Fixture();

            dataServiceMock =
                new Mock<IDispersionDataService>();

            handler = new DispersionUpdateRequestHandler(
                dataServiceMock.Object);
        }

        public void Dispose()
        {
            dataServiceMock = null;
            handler = null;
            fixture = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(
                handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var request =
                fixture.Create<DispersionUpdateRequest>();

            dataServiceMock
                .Setup(m => m.UpdateDispersion(request.Dispersion))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var request =
                fixture.Create<DispersionUpdateRequest>();

            var expected =
                fixture.Create<Dispersion>();

            dataServiceMock
                .Setup(m => m.UpdateDispersion(request.Dispersion))
                .ReturnsAsync(expected);

            var actual =
                await handler.Handle(
                    request,
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                actual);
        }
    }
}
