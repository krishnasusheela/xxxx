﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class JurisdictionInquiryRequestHandlerTests
        : IDisposable

    {
        private JurisdictionInquiryRequestHandler handler;
        private Mock<IJurisdictionDataService> dataServiceMock;
        private Fixture fixture;

        public JurisdictionInquiryRequestHandlerTests()
        {
            fixture = new Fixture();

            dataServiceMock = 
                new Mock<IJurisdictionDataService>();

            handler = new JurisdictionInquiryRequestHandler(
                dataServiceMock.Object);
        }

        public void Dispose()
        {
            dataServiceMock = null;
            handler = null;
            fixture = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(
                handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var request =
                fixture.Create<JurisdictionInquiryRequest>();

            dataServiceMock
                .Setup(m => m.GetJurisdictionById(request.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var request =
                fixture.Create<JurisdictionInquiryRequest>();

            var expected =
                fixture.Create<Jurisdiction>();

            dataServiceMock
                .Setup(m => m.GetJurisdictionById(request.Id))
                .ReturnsAsync(expected);

            var actual = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                actual);
        }
    }
}
