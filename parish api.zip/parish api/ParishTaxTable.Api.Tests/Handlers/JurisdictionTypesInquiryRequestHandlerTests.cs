﻿using AutoFixture;
using Moq;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using System;
using System.Linq;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;


namespace ParishTaxTable.Api.Tests.Handlers
{
    public class JurisdictionTypesInquiryRequestHandlerTests
        : IDisposable
    {
        private JurisdictionTypesInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IJurisdictionTypeDataService> mockJurisdictionTypeDataService;

        public JurisdictionTypesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockJurisdictionTypeDataService = new Mock<IJurisdictionTypeDataService>();

            handler = new JurisdictionTypesInquiryRequestHandler(
                mockJurisdictionTypeDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockJurisdictionTypeDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            mockJurisdictionTypeDataService
                .Setup(m => m.GetAllJurisdictionTypes())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new JurisdictionTypesInquiryRequest(),
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture
                .CreateMany<JurisdictionType>()
                .ToList();

            mockJurisdictionTypeDataService
                .Setup(m => m.GetAllJurisdictionTypes())
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new JurisdictionTypesInquiryRequest(),
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
