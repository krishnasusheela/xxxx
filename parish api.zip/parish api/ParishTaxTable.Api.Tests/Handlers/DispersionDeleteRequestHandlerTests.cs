﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using MediatR;
using Moq;
using ParishTaxTable.Api.Core.Interfaces;
using ParishTaxTable.Api.Handlers;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Handlers
{
    public class DispersionDeleteRequestHandlerTests
        : IDisposable

    {
        private DispersionDeleteRequestHandler handler;
        private Mock<IDispersionDataService> dataServiceMock;
        private Fixture fixture;

        public DispersionDeleteRequestHandlerTests()
        {
            fixture = new Fixture();

            dataServiceMock =
                new Mock<IDispersionDataService>();

            handler = new DispersionDeleteRequestHandler(
                dataServiceMock.Object);
        }

        public void Dispose()
        {
            dataServiceMock = null;
            handler = null;
            fixture = null;
        }

        [Fact]
        public void ConstructorDeletesSuccessfully()
        {
            Assert.NotNull(
                handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var request =
                fixture.Create<DispersionDeleteRequest>();

            dataServiceMock
                .Setup(m => m.DeleteDispersion(request.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var request =
                fixture.Create<DispersionDeleteRequest>();

            var actual =
                await handler.Handle(
                    request,
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                Unit.Value,
                actual);
        }
    }
}
