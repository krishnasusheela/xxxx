﻿using System;

namespace ParishTaxTable.Api.Tests.TestHelpers
{
    public class TestException
        : Exception
    {
    }
}
