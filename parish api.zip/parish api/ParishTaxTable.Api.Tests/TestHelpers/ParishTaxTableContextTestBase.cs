﻿using System;
using System.Collections.Generic;
using AutoFixture;
using Microsoft.EntityFrameworkCore;
using ParishTaxTable.Api.Infrastructure.Models;

namespace ParishTaxTable.Api.Tests.TestHelpers
{
    public abstract class ParishTaxTableContextTestBase
        : IDisposable
    {
        protected readonly Fixture TestFixture;
        protected readonly ParishTaxTableContext TableContext;

        protected ParishTaxTableContextTestBase()
        {
            TestFixture = new Fixture();

            TableContext = new ParishTaxTableContext(
                new DbContextOptionsBuilder<ParishTaxTableContext>()
                    .UseInMemoryDatabase(Guid.NewGuid().ToString())
                    .EnableSensitiveDataLogging()
                    .Options);

            TableContext.Database.EnsureCreated();
        }

        ~ParishTaxTableContextTestBase()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            TableContext.Database.EnsureDeleted();
            TableContext.Dispose();

            Dispose(true);
            GC.SuppressFinalize(this);            
        }

        protected abstract void Dispose(bool disposing);

        protected void Seed(ParishTaxTableContext dataContext)
        {
            var parishes = new List<ParishDto>();
            for (var i = 1; i < 5; i++)
            {
                parishes.Add(CreateParish(i));
            }

            dataContext.Parishes.AddRange(parishes);
            dataContext.SaveChanges();
        }

        protected JurisdictionDto CreateJurisdiction(int id)
        {
            var jurisdiction = TestFixture
                .Build<JurisdictionDto>()
                .With(p => p.Id, id)
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var jurisdictionType = TestFixture
                .Build<JurisdictionTypeDto>()
                .Without(p => p.Jurisdictions)
                .Create();

            jurisdiction.JurisdictionTypeId =
                jurisdictionType.Id;
            jurisdiction.JurisdictionType =
                jurisdictionType;

            return jurisdiction;
        }

        protected DispersionDto CreateDispersion(int id)
        {
            var dispersion = TestFixture
                .Build<DispersionDto>()
                .With(p => p.Id, id)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            return dispersion;
        }

        protected ParishDto CreateParish(int id)
        {
            var parish = TestFixture
                .Build<ParishDto>()
                .With(p => p.Id, id)
                .With(p => p.Code, id.ToString("00"))
                .Without(p => p.Domiciles)
                .Without(p => p.Contacts)
                .Without(p => p.Jurisdictions)
                .Create();

            var domiciles = new List<DomicileDto>();
            for (var i = 0; i < 10; i++)
            {
                domiciles.Add(CreateDomicile(parish));
            }
            parish.Domiciles = domiciles;

            var contacts = new List<ContactDto>();
            for (var i = 0; i < 10; i++)
            {
                contacts.Add(CreateContact(parish));
            }

            parish.Contacts = contacts;

            return parish;
        }

        private ContactDto CreateContact(ParishDto parish)
        {
            var contact = TestFixture
                .Build<ContactDto>()
                .With(p => p.ParishId, parish.Id)
                .Without(p => p.Parish)
                .Create();

            return contact;
        }

        private DomicileDto CreateDomicile(ParishDto parish)
        {
            var domicileCode = TestFixture.Create<string>().Substring(0, 2);

            var domicile = TestFixture
                .Build<DomicileDto>()
                .With(p => p.ParishId, parish.Id)
                .With(p => p.Code, domicileCode)
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var dispersions = new List<DispersionDto>();
            for (var i = 0; i < 5; i++)
            {
                dispersions.Add(
                    CreateDispersion(domicile, parish));
            }

            domicile.Dispersions = dispersions;

            return domicile;
        }

        protected DomicileDto CreateDomicile(int id)
        {
            var parish = TestFixture
                .Build<ParishDto>()
                .With(p => p.Id, id)
                .Without(p => p.Domiciles)
                .Without(p => p.Contacts)
                .Without(p => p.Jurisdictions)
                .Create();

            var domicile = TestFixture
                .Build<DomicileDto>()
                .With(p => p.Id, id)
                .With(p => p.ParishId, parish.Id)
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var dispersions = new List<DispersionDto>();
            for (var i = 0; i < 5; i++)
            {
                dispersions.Add(
                    CreateDispersion(domicile, parish));
            }

            domicile.Dispersions = dispersions;

            return domicile;
        }

        protected DomicileDto CreateDomicileWithRelatedData(int id)
        {
            var parish = TestFixture
                .Build<ParishDto>()
                .With(p => p.Id, id)
                .With(p => p.Code, id.ToString("00"))
                .Without(p => p.Domiciles)
                .Without(p => p.Contacts)
                .Without(p => p.Jurisdictions)
                .Create();

            var domicileCode = TestFixture.Create<string>().Substring(0, 2);

            var domicile = TestFixture
                .Build<DomicileDto>()
                .With(p => p.Id, id)
                .With(p => p.Code, domicileCode)
                .With(p => p.ParishId, parish.Id)
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var dispersions = new List<DispersionDto>();
            for (var i = 0; i < 5; i++)
            {
                dispersions.Add(
                    CreateDispersion(domicile, parish));
            }

            domicile.Dispersions = dispersions;
            domicile.Parish = parish;

            return domicile;
        }

        protected DomicileDto CreateDomicileWithRelatedDataByDate(int id, DateTimeOffset date)
        {
            var parish = TestFixture
               .Build<ParishDto>()
               .With(p => p.Id, id)
               .Without(p => p.Domiciles)
               .Without(p => p.Contacts)
               .Without(p => p.Jurisdictions)
               .Create();

            var domicile = TestFixture
                .Build<DomicileDto>()
                .With(p => p.Id, id)
                .With(p => p.ParishId, parish.Id)
                .With(p => p.EffectiveDate, date.AddDays(-1))
                .With(p => p.TermDate, date.AddDays(1))
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var dispersions = new List<DispersionDto>();
            for (var i = 0; i < 5; i++)
            {
                dispersions.Add(
                    CreateDispersion(domicile, parish));
            }

            domicile.Dispersions = dispersions;
            domicile.Parish = parish;

            return domicile;

        }
        protected DispersionDto CreateDispersion(
            DomicileDto domicile, 
            ParishDto parish)
        {
            var dispersion = TestFixture
                .Build<DispersionDto>()
                .With(p => p.DomicileId, domicile.Id)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var jurisdictionType = TestFixture
                .Build<JurisdictionTypeDto>()
                .Without(p => p.Jurisdictions)
                .Create();

            dispersion.Jurisdiction =
                CreateJurisdiction(
                    jurisdictionType,
                    parish);

            return dispersion;
        }

        private JurisdictionDto CreateJurisdiction(
            JurisdictionTypeDto jurisdictionType,
            ParishDto parish)
        {
            var jurisdiction = TestFixture
                .Build<JurisdictionDto>()
                .Without(p => p.Parish)
                .Without(p => p.JurisdictionType)
                .Create();

            jurisdiction.JurisdictionTypeId = 
                jurisdictionType.Id;
            jurisdiction.ParishId =
                parish.Id;
            jurisdiction.JurisdictionType =
                jurisdictionType;

            return jurisdiction;
        }
    }
}
