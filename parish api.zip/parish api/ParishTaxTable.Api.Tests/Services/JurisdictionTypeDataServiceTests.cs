﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using AutoMapper;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Services;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Services
{
    public class JurisdictionTypeDataServiceTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<IJurisdictionTypeRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private JurisdictionTypeDataService service;

        public JurisdictionTypeDataServiceTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IJurisdictionTypeRepository>();
            mapperMock = new Mock<IMapper>();

            service = new JurisdictionTypeDataService(
                repositoryMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllJurisdictionTypesThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllJurisdictionTypes());
        }

        [Fact]
        public async Task GetAllJurisdictionTypesThrowsExceptionWhenMapperThrowsException()
        {
            var types = fixture
                .Build<JurisdictionTypeDto>()
                .Without(p => p.Jurisdictions)
                .CreateMany();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(types);

            mapperMock
                .Setup(m => m.Map<IEnumerable<JurisdictionType>>(types))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllJurisdictionTypes());
        }

        [Fact]
        public async Task GetAllJurisdictionTypesReturnsExpected()
        {
            var expected = fixture
                .CreateMany<JurisdictionType>()
                .ToList();

            var types = fixture
                .Build<JurisdictionTypeDto>()
                .Without(p => p.Jurisdictions)
                .CreateMany();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(types);

            mapperMock
                .Setup(m => m.Map<IEnumerable<JurisdictionType>>(types))
                .Returns(expected);

            var actual = await service
                .GetAllJurisdictionTypes();

            Assert.Equal(
                expected,
                actual);
        }
    }
}
