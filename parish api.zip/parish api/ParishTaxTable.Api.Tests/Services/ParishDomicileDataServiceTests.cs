﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using AutoMapper;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Services;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Services
{
    public class ParishDomicileDataServiceTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<IParishRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private ParishDomicileDataService service;

        public ParishDomicileDataServiceTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IParishRepository>();
            mapperMock = new Mock<IMapper>();

            service = new ParishDomicileDataService(
                repositoryMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllParishDomicilesThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.GetWithDomiciles())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllParishDomiciles());
        }

        [Fact]
        public async Task GetAllParishDomicilesThrowsExceptionWhenMapperThrowsException()
        {
            var parishes = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .CreateMany();

            repositoryMock
                .Setup(m => m.GetWithDomiciles())
                .ReturnsAsync(parishes);

            mapperMock
                .Setup(m => m.Map<IEnumerable<ParishDomicile>>(parishes))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllParishDomiciles());
        }

        [Fact]
        public async Task GetAllParishDomicilesReturnsExpected()
        {
            var parishes = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .CreateMany();

            var expected = fixture
                .CreateMany<ParishDomicile>()
                .ToList();

            repositoryMock
                .Setup(m => m.GetWithDomiciles())
                .ReturnsAsync(parishes);

            mapperMock
                .Setup(m => m.Map<IEnumerable<ParishDomicile>>(parishes))
                .Returns(expected);

            var actual = await service
                .GetAllParishDomiciles();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetDomicileParishByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var parishId = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetWithDomicilesById(parishId))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetDomicileParishById(parishId));
        }

        [Fact]
        public async Task GetDomicileParishByIdThrowsExceptionWhenMapperThrowsException()
        {
            var parishId = fixture.Create<int>();

            var parish = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            repositoryMock
                .Setup(m => m.GetWithDomicilesById(parishId))
                .ReturnsAsync(parish);

            mapperMock
                .Setup(m => m.Map<ParishDomicile>(parish))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetDomicileParishById(parishId));
        }

        [Fact]
        public async Task GetDomicileParishByIdReturnsExpected()
        {
            var parishId = fixture.Create<int>();

            var parish = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            var expected = fixture.Create<ParishDomicile>();

            repositoryMock
                .Setup(m => m.GetWithDomicilesById(parishId))
                .ReturnsAsync(parish);

            mapperMock
                .Setup(m => m.Map<ParishDomicile>(parish))
                .Returns(expected);

            var actual = await service
                .GetDomicileParishById(parishId);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetNextParishDomicileCodeThrowsExceptionWhenRepositoryThrowsException()
        {
            var parishId = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetWithDomicilesById(parishId))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetNextParishDomicileCode(parishId));
        }

        [Fact]
        public async Task GetNextParishDomicileCodeReturns00WhenNoDomiciles()
        {

            var expectedCode = "00";

            var parish = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            repositoryMock
                .Setup(m => m.GetWithDomicilesById(parish.Id))
                .ReturnsAsync(parish);

            var actual = await service
                .GetNextParishDomicileCode(parish.Id);

            Assert.Equal(
                expectedCode,
                actual.NextDomicileCode);
        }

        [Fact]
        public async Task GetNextParishDomicileCodeReturnsEmptyStringWhenDomicileCodeIsNaN()
        {
            var domicile = fixture
                .Build<DomicileDto>()
                .With(p => p.Code, "test")
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var parish = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .With(p => p.Domiciles, new List<DomicileDto> { domicile })
                .Without(p => p.Jurisdictions)
                .Create();

            repositoryMock
                .Setup(m => m.GetWithDomicilesById(parish.Id))
                .ReturnsAsync(parish);

            var actual = await service
                .GetNextParishDomicileCode(parish.Id);

            Assert.Equal(
                String.Empty,
                actual.NextDomicileCode);
        }

        [Fact]
        public async Task GetNextParishDomicileCodeReturnsExpected()
        {

            var initialCode = "00";
            var expectedCode = "01";


            var domicile = fixture
                .Build<DomicileDto>()
                .With(p => p.Code, initialCode)
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var parish = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .With(p => p.Domiciles, new List<DomicileDto> { domicile } )
                .Without(p => p.Jurisdictions)
                .Create();

            repositoryMock
                .Setup(m => m.GetWithDomicilesById(parish.Id))
                .ReturnsAsync(parish);

            var actual = await service
                .GetNextParishDomicileCode(parish.Id);

            Assert.Equal(
                expectedCode,
                actual.NextDomicileCode);
        }




    }
}
