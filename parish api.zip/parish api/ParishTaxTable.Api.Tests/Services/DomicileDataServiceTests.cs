﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using AutoMapper;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Services;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Services
{
    public class DomicileDataServiceTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<IDomicileRepository> repositoryMock;
        private Mock<IDomicileCreateRules> createRulesMock;
        private Mock<IDomicileUpdateRules> updateRulesMock;
        private Mock<IMapper> mapperMock;
        private DomicileDataService service;

        public DomicileDataServiceTests()
        {
            fixture = new Fixture();

            repositoryMock = new Mock<IDomicileRepository>();
            createRulesMock = new Mock<IDomicileCreateRules>();
            updateRulesMock = new Mock<IDomicileUpdateRules>();
            mapperMock = new Mock<IMapper>();

            service = new DomicileDataService(
                repositoryMock.Object,
                createRulesMock.Object,
                updateRulesMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            createRulesMock = null;
            updateRulesMock = null;
            mapperMock = null;

            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllDomicilesThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllDomiciles());
        }

        [Fact]
        public async Task GetAllDomicilesThrowsExceptionWhenMapperThrowsException()
        {
            var domicileDtos = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .CreateMany()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(domicileDtos);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Domicile>>(domicileDtos))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllDomiciles());
        }

        [Fact]
        public async Task GetAllDomicilesReturnsExpected()
        {
            var domicileDtos = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .CreateMany()
                .ToList();

            var expected = fixture
                .CreateMany<Domicile>()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(domicileDtos);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Domicile>>(domicileDtos))
                .Returns(expected);

            var actual = await service.GetAllDomiciles();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetDomicileByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var id = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetDomicileById(id));
        }

        [Fact]
        public async Task GetDomicileByIdThrowsExceptionWhenMapperThrowsException()
        {
            var id = fixture.Create<int>();

            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(domicileDto);

            mapperMock
                .Setup(m => m.Map<Domicile>(domicileDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetDomicileById(id));
        }

        [Fact]
        public async Task GetDomicileByIdReturnsExpected()
        {
            var id = fixture.Create<int>();

            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var expected = fixture.Create<Domicile>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(domicileDto);

            mapperMock
                .Setup(m => m.Map<Domicile>(domicileDto))
                .Returns(expected);

            var actual = await service.GetDomicileById(id);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetDomicileByIdAndDateThrowsExceptionWhenRepositoryThrowsException()
        {
            var id = fixture.Create<int>();
            var date = fixture.Create<DateTimeOffset>(); 
            repositoryMock
                .Setup(m => m.GetByIdAndDate(id,date))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetDomicileByIdAndDate(id,date));
        }

        [Fact]
        public async Task GetDomicileByIdAndDateThrowsExceptionWhenMapperThrowsException()
        {
            var id = fixture.Create<int>();
            var date = fixture.Create<DateTimeOffset>();

            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            repositoryMock
                .Setup(m => m.GetByIdAndDate(id,date))
                .ReturnsAsync(domicileDto);

            mapperMock
                .Setup(m => m.Map<Domicile>(domicileDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetDomicileByIdAndDate(id,date));
        }

        [Fact]
        public async Task GetDomicileByIdAndDateReturnsExpected()
        {
            var id = fixture.Create<int>();
            var date = fixture.Create<DateTimeOffset>();

            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var expected = fixture.Create<Domicile>();

            repositoryMock
                .Setup(m => m.GetByIdAndDate(id,date))
                .ReturnsAsync(domicileDto);

            mapperMock
                .Setup(m => m.Map<Domicile>(domicileDto))
                .Returns(expected);

            var actual = await service.GetDomicileByIdAndDate(id,date);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task CreateDomicileThrowsExceptionWhenDtoMapperThrowsException()
        {
            var domicile = fixture.Create<Domicile>();

            mapperMock
                .Setup(m => m.Map<DomicileDto>(domicile))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateDomicile(domicile));
        }

        [Fact]
        public async Task CreateDomicileThrowsExceptionWhenCreateRulesThrowsException()
        {
            var domicile = fixture.Create<Domicile>();

            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            mapperMock
                .Setup(m => m.Map<DomicileDto>(domicile))
                .Returns(domicileDto);

            createRulesMock
                .Setup(m => m.Test(domicileDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateDomicile(domicile));
        }

        [Fact]
        public async Task CreateDomicileThrowsExceptionWhenRepositoryThrowsException()
        {
            var domicile = fixture.Create<Domicile>();

            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            mapperMock
                .Setup(m => m.Map<DomicileDto>(domicile))
                .Returns(domicileDto);

            createRulesMock
                .Setup(m => m.Test(domicileDto));

            repositoryMock
                .Setup(m => m.Create(domicileDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateDomicile(domicile));
        }

        [Fact]
        public async Task CreateDomicileThrowsExceptionWhenDomicileMapperThrowsException()
        {
            var domicile = fixture.Create<Domicile>();

            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var createdDomicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            mapperMock
                .Setup(m => m.Map<DomicileDto>(domicile))
                .Returns(domicileDto);

            createRulesMock
                .Setup(m => m.Test(domicileDto));

            repositoryMock
                .Setup(m => m.Create(domicileDto))
                .ReturnsAsync(createdDomicileDto);

            mapperMock
                .Setup(m => m.Map<Domicile>(createdDomicileDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateDomicile(domicile));
        }

        [Fact]
        public async Task CreateDomicileReturnsExpected()
        {
            var domicile = fixture.Create<Domicile>();

            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var createdDomicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var expected = fixture.Create<Domicile>();

            mapperMock
                .Setup(m => m.Map<DomicileDto>(domicile))
                .Returns(domicileDto);

            createRulesMock
                .Setup(m => m.Test(domicileDto));

            repositoryMock
                .Setup(m => m.Create(domicileDto))
                .ReturnsAsync(createdDomicileDto);

            mapperMock
                .Setup(m => m.Map<Domicile>(createdDomicileDto))
                .Returns(expected);

            var actual = await service
                .CreateDomicile(
                    domicile);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task UpdateDomicileThrowsExceptionWhenRepositoryGetThrowsException()
        {
            var domicile = fixture.Create<Domicile>();

            repositoryMock
                .Setup(m => m.GetById(
                    domicile.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateDomicile(domicile));
        }

        [Fact]
        public async Task UpdateDomicileThrowsExceptionWhenUpdateRulesThrowsException()
        {
            var domicile = fixture.Create<Domicile>();
            
            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(
                    domicile.Id))
                .ReturnsAsync(domicileDto);

            updateRulesMock
                .Setup(m => m.Test(domicileDto, domicile))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateDomicile(domicile));
        }

        [Fact]
        public async Task UpdateDomicileThrowsExceptionWhenRepositoryUpdateThrowsException()
        {
            var domicile = fixture.Create<Domicile>();
            
            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(
                    domicile.Id))
                .ReturnsAsync(domicileDto);

            updateRulesMock
                .Setup(m => m.Test(domicileDto, domicile));

            repositoryMock
                .Setup(m => m.Update(domicileDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateDomicile(domicile));
        }

        [Fact]
        public async Task UpdateDomicileThrowsExceptionWhenMapperThrowsException()
        {
            var domicile = fixture.Create<Domicile>();
            
            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var updatedDomicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(
                    domicile.Id))
                .ReturnsAsync(domicileDto);

            updateRulesMock
                .Setup(m => m.Test(domicileDto, domicile));

            repositoryMock
                .Setup(m => m.Update(domicileDto))
                .ReturnsAsync(updatedDomicileDto);

            mapperMock
                .Setup(m => m.Map<Domicile>(updatedDomicileDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateDomicile(domicile));
        }

        [Fact]
        public async Task UpdateDomicileReturnsExpected()
        {
            var domicile = fixture.Create<Domicile>();
            
            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var updatedDomicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var expected = fixture.Create<Domicile>();

            repositoryMock
                .Setup(m => m.GetById(
                    domicile.Id))
                .ReturnsAsync(domicileDto);

            updateRulesMock
                .Setup(m => m.Test(domicileDto, domicile));

            repositoryMock
                .Setup(m => m.Update(domicileDto))
                .ReturnsAsync(updatedDomicileDto);

            mapperMock
                .Setup(m => m.Map<Domicile>(updatedDomicileDto))
                .Returns(expected);

            var actual = await service
                .UpdateDomicile(domicile);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task UpdateDomicileSetsName()
        {
            var domicile = fixture.Create<Domicile>();
            
            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var updatedDomicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var expected = fixture.Create<Domicile>();

            repositoryMock
                .Setup(m => m.GetById(
                    domicile.Id))
                .ReturnsAsync(domicileDto);

            updateRulesMock
                .Setup(m => m.Test(domicileDto, domicile));

            repositoryMock
                .Setup(m => m.Update(domicileDto))
                .ReturnsAsync(updatedDomicileDto);

            mapperMock
                .Setup(m => m.Map<Domicile>(updatedDomicileDto))
                .Returns(expected);

            await service
                .UpdateDomicile(domicile);

            Assert.Equal(
                domicile.Name,
                domicileDto.Name);
        }

        [Fact]
        public async Task UpdateDomicileSetsTermDateToEndOfDay()
        {
            var domicile = fixture.Create<Domicile>();
            
            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var updatedDomicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var expected = fixture.Create<Domicile>();

            repositoryMock
                .Setup(m => m.GetById(
                    domicile.Id))
                .ReturnsAsync(domicileDto);

            updateRulesMock
                .Setup(m => m.Test(domicileDto, domicile));

            repositoryMock
                .Setup(m => m.Update(domicileDto))
                .ReturnsAsync(updatedDomicileDto);

            mapperMock
                .Setup(m => m.Map<Domicile>(updatedDomicileDto))
                .Returns(expected);

            await service
                .UpdateDomicile(domicile);

            Assert.Equal(
                domicile.TermDate.EndOfDay(),
                domicileDto.TermDate);
        }

        [Fact]
        public async Task GetDomicileCodeByCodeThrowsExceptionWhenRepositoryThrowsException()
        {
            var parishCode = fixture.Create<string>().Substring(0,2);
            var domicileCode = fixture.Create<string>().Substring(0,2);

            repositoryMock
                .Setup(m => m.GetByCodes(parishCode, domicileCode))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetDomicileCodeByCode(parishCode+ domicileCode));
        }

        [Fact]
        public async Task GetDomicileCodeByCodeThrowsExceptionWhenMapperThrowsException()
        {
            var parishCode = fixture.Create<string>().Substring(0,2);
            var domicileCode = fixture.Create<string>().Substring(0,2);

            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            repositoryMock
                .Setup(m => m.GetByCodes(parishCode, domicileCode))
                .ReturnsAsync(domicileDto);

            mapperMock
                .Setup(m => m.Map<DomicileWithoutDisperions>(domicileDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetDomicileCodeByCode(parishCode+ domicileCode));
        }

        [Fact]
        public async Task GetDomicileCodeByCodeReturnsExpected()
        {

            var parishCode = fixture.Create<string>().Substring(0,2);
            var domicileCode = fixture.Create<string>().Substring(0, 2);

            var domicileDto = fixture
                .Build<DomicileDto>()
                .Without(p => p.Parish)
                .Without(p => p.Dispersions)
                .Create();

            var expected = fixture.Create<DomicileWithoutDisperions>();

            repositoryMock
                .Setup(m => m.GetByCodes(parishCode, domicileCode))
                .ReturnsAsync(domicileDto);

            mapperMock
                .Setup(m => m.Map<DomicileWithoutDisperions>(domicileDto))
                .Returns(expected);

            var actual = await service.GetDomicileCodeByCode(parishCode+ domicileCode);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
