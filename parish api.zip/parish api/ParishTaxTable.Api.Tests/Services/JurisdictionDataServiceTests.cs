﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using AutoMapper;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Services;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Services
{
    public class JurisdictionDataServiceTests
        : IDisposable
    {
        private JurisdictionDataService service;
        private Mock<IMapper> mapperMock;
        private Mock<IJurisdictionUpdateRules> updateRulesMock;
        private Mock<IJurisdictionRepository> repositoryMock;
        private Fixture fixture;
        
        public JurisdictionDataServiceTests()
        {
            fixture = new Fixture();

            mapperMock =
               new Mock<IMapper>();
            repositoryMock = 
                new Mock<IJurisdictionRepository>();
            updateRulesMock =
                new Mock<IJurisdictionUpdateRules>();

            service = new JurisdictionDataService(

                updateRulesMock.Object,
                repositoryMock.Object,
                mapperMock.Object
                );
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;
            updateRulesMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllJurisdictionsThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllJurisdictions());
        }

        [Fact]
        public async Task GetAllJurisdictionsThrowsExceptionWhenMapperThrowsException()
        {
            var jurisdictions = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .CreateMany();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(jurisdictions);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Jurisdiction>>(jurisdictions))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllJurisdictions());
        }

        [Fact]
        public async Task GetAllJurisdictionsReturnsExpected()
        {
            var jurisdictions = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .CreateMany();

            var expected = fixture
                .CreateMany<Jurisdiction>()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(jurisdictions);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Jurisdiction>>(jurisdictions))
                .Returns(expected);

            var actual = await service.GetAllJurisdictions();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetJurisdictionByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var jurisdictionId = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(jurisdictionId))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetJurisdictionById(jurisdictionId));
        }

        [Fact]
        public async Task GetJurisdictionByIdThrowsExceptionWhenMapperThrowsException()
        {
            var jurisdictionId = fixture.Create<int>();

            var dto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(jurisdictionId))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Jurisdiction>(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetJurisdictionById(jurisdictionId));
        }

        [Fact]
        public async Task GetJurisdictionByIdReturnsExpected()
        {
            var jurisdictionId = fixture.Create<int>();

            var dto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var expected = fixture.Create<Jurisdiction>();

            repositoryMock
                .Setup(m => m.GetById(jurisdictionId))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Jurisdiction>(dto))
                .Returns(expected);

            var actual = await service
                .GetJurisdictionById(jurisdictionId);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task CreateJurisdictionThrowsExceptionWhenDtoMapperThrowsException()
        {
            var jurisdiction = fixture.Create<Jurisdiction>();

            mapperMock
                .Setup(m => m.Map<JurisdictionDto>(jurisdiction))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateJurisdiction(jurisdiction));
        }

        [Fact]
        public async Task CreateJurisdictionThrowsExceptionWhenRepositoryThrowsException()
        {
            var jurisdiction = fixture.Create<Jurisdiction>();

            var dto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<JurisdictionDto>(jurisdiction))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.Create(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateJurisdiction(jurisdiction));
        }

        [Fact]
        public async Task CreateJurisdictionThrowsExceptionWhenMapperThrowsException()
        {
            var jurisdiction = fixture.Create<Jurisdiction>();

            var dto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var createdDto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<JurisdictionDto>(jurisdiction))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.Create(dto))
                .ReturnsAsync(createdDto);

            mapperMock
                .Setup(m => m.Map<Jurisdiction>(createdDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateJurisdiction(jurisdiction));
        }

        [Fact]
        public async Task CreateJurisdictionReturnsExpected()
        {
            var jurisdiction = fixture.Create<Jurisdiction>();

            var dto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var createdDto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var expected = fixture.Create<Jurisdiction>();

            mapperMock
                .Setup(m => m.Map<JurisdictionDto>(jurisdiction))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.Create(dto))
                .ReturnsAsync(createdDto);

            mapperMock
                .Setup(m => m.Map<Jurisdiction>(createdDto))
                .Returns(expected);

            var actual = await service
                .CreateJurisdiction(jurisdiction);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task UpdateJurisdictionThrowsExceptionWhenRepositoryGetByIdThrowsException()
        {
            var jurisdiction = fixture.Create<Jurisdiction>();

            repositoryMock
                .Setup(m => m.GetById(jurisdiction.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateJurisdiction(jurisdiction));
        }

        [Fact]
        public async Task UpdateJurisdictionReturnsNullWhenRepositoryGetByIdReturnsNull()
        {
            var jurisdiction = fixture.Create<Jurisdiction>();
            
            repositoryMock
                .Setup(m => m.GetById(jurisdiction.Id))
                .ReturnsAsync((JurisdictionDto)null);

            var actual = await service
                .UpdateJurisdiction(jurisdiction);

            Assert.Null(
                actual);
        }

        [Fact]
        public async Task UpdateJurisdictionThrowsExceptionWhenDtoMapperThrowsException()
        {
            var jurisdiction = fixture.Create<Jurisdiction>();

            var jurisdictionDto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(jurisdiction.Id))
                .ReturnsAsync(jurisdictionDto);

            mapperMock
                .Setup(m => m.Map(jurisdiction, jurisdictionDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateJurisdiction(jurisdiction));
        }

        [Fact]
        public async Task UpdateJurisdictionThrowsExceptionWhenRepositoryUpdateThrowsException()
        {
            var jurisdiction = fixture.Create<Jurisdiction>();

            var jurisdictionDto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var mappedDto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(jurisdiction.Id))
                .ReturnsAsync(jurisdictionDto);

            mapperMock
                .Setup(m => m.Map(jurisdiction, jurisdictionDto))
                .Returns(mappedDto);

            repositoryMock
                .Setup(m => m.Update(mappedDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateJurisdiction(jurisdiction));
        }

        [Fact]
        public async Task UpdateJurisdictionThrowsExceptionWhenMapperThrowsException()
        {
            var jurisdiction = fixture.Create<Jurisdiction>();

            var jurisdictionDto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var mappedDto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var dto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(jurisdiction.Id))
                .ReturnsAsync(jurisdictionDto);

            mapperMock
                .Setup(m => m.Map(jurisdiction, jurisdictionDto))
                .Returns(mappedDto);

            repositoryMock
                .Setup(m => m.Update(mappedDto))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Jurisdiction>(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateJurisdiction(jurisdiction));
        }

        [Fact]
        public async Task UpdateJurisdictionReturnsExpected()
        {
            var jurisdiction = fixture.Create<Jurisdiction>();

            var jurisdictionDto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var mappedDto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var dto = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var expected = fixture.Create<Jurisdiction>();

            repositoryMock
                .Setup(m => m.GetById(jurisdiction.Id))
                .ReturnsAsync(jurisdictionDto);

            mapperMock
                .Setup(m => m.Map(jurisdiction, jurisdictionDto))
                .Returns(mappedDto);

            repositoryMock
                .Setup(m => m.Update(mappedDto))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Jurisdiction>(dto))
                .Returns(expected);

            var actual = await service
                .UpdateJurisdiction(jurisdiction);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
