﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Services;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;
using AutoMapper;

namespace ParishTaxTable.Api.Tests.Services
{
    public class ParishContactDataServiceTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<IParishRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private ParishContactDataService service;

        public ParishContactDataServiceTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IParishRepository>();
            mapperMock = new Mock<IMapper>();

            service = new ParishContactDataService(
                repositoryMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllParishContactsThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.GetWithContacts())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllParishContacts());
        }

        [Fact]
        public async Task GetAllParishContactsThrowsExceptionWhenMapperThrowsException()
        {
            var parishes = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .CreateMany();

            repositoryMock
                .Setup(m => m.GetWithContacts())
                .ReturnsAsync(parishes);

            mapperMock
                .Setup(m => m.Map<IEnumerable<ParishContact>>(parishes))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllParishContacts());
        }

        [Fact]
        public async Task GetAllParishContactsReturnsExpected()
        {
            var parishes = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .CreateMany();

            var expected = fixture
                .CreateMany<ParishContact>()
                .ToList();

            repositoryMock
                .Setup(m => m.GetWithContacts())
                .ReturnsAsync(parishes);

            mapperMock
                .Setup(m => m.Map<IEnumerable<ParishContact>>(parishes))
                .Returns(expected);

            var actual = await service
                .GetAllParishContacts();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetParishContactsByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var parishId = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetWithContactsById(parishId))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetParishContactsById(parishId));
        }

        [Fact]
        public async Task GetParishContactsByIdThrowsExceptionWhenMapperThrowsException()
        {
            var parishId = fixture.Create<int>();

            var parish = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            repositoryMock
                .Setup(m => m.GetWithContactsById(parishId))
                .ReturnsAsync(parish);

            mapperMock
                .Setup(m => m.Map<ParishContact>(parish))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetParishContactsById(parishId));
        }

        [Fact]
        public async Task GetParishContactsByIdReturnsExpected()
        {
            var parishId = fixture.Create<int>();

            var parish = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            var expected = fixture
                .Create<ParishContact>();

            repositoryMock
                .Setup(m => m.GetWithContactsById(parishId))
                .ReturnsAsync(parish);

            mapperMock
                .Setup(m => m.Map<ParishContact>(parish))
                .Returns(expected);

            var actual = await service
                .GetParishContactsById(parishId);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
