﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using AutoMapper;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Services;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Services
{
    public class ContactDataServiceTests
        : IDisposable
    {
        private ContactDataService service;
        private Mock<IMapper> mapperMock;
        private Mock<IContactRepository> repositoryMock;
        private Mock<IContactDeleteRules> deleteRulesMock;
        private Fixture fixture;

        public ContactDataServiceTests()
        {
            fixture = new Fixture();

            mapperMock = new Mock<IMapper>();
            repositoryMock = new Mock<IContactRepository>();
            deleteRulesMock = new Mock<IContactDeleteRules>();
            
            service = new ContactDataService(
                repositoryMock.Object,
                mapperMock.Object,
                deleteRulesMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            mapperMock = null;
            repositoryMock = null;
            service = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetContactByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var id = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetContactById(id));
        }

        [Fact]
        public async Task GetContactByIdThrowsExceptionWhenMapperThrowsException()
        {
            var id = fixture.Create<int>();

            var contact = fixture
                .Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(contact);

            mapperMock
                .Setup(m => m.Map<Contact>(contact))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetContactById(id));
        }

        [Fact]
        public async Task CreateContactReturnsMapperResult()
        {
            var id = fixture.Create<int>();

            var contact = fixture
                .Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var expected = fixture
                .Create<Contact>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(contact);

            mapperMock
                .Setup(m => m.Map<Contact>(contact))
                .Returns(expected);

            var actual = await service
                .GetContactById(id);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task CreateContactThrowsExceptionWhenMapperThrowsException()
        {
            var contact = fixture.Create<Contact>();

            mapperMock
                .Setup(m => m.Map<ContactDto>(contact))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateContact(contact));
        }

        [Fact]
        public async Task CreateContactThrowsExceptionWhenRepositoryThrowsException()
        {
            var contact = fixture.Create<Contact>();
            var dto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<ContactDto>(contact))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.InsertContact(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateContact(contact));
        }

        [Fact]
        public async Task CreateContactThrowsExceptionWhenContactMapperThrowsException()
        {
            var contact = fixture.Create<Contact>();
            var dto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<ContactDto>(contact))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.InsertContact(dto))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Contact>(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateContact(contact));
        }

        [Fact]
        public async Task CreateContactReturnsExpected()
        {
            var contact = fixture.Create<Contact>();
            var dto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var expected = fixture.Create<Contact>();

            mapperMock
                .Setup(m => m.Map<ContactDto>(contact))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.InsertContact(dto))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Contact>(dto))
                .Returns(expected);

            var actual = await service
                .CreateContact(contact);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task RetireContactThrowsExceptionWhenRepositoryThrowsException()
        {
            var id = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.RetireContact(id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.RetireContact(id));
        }

        [Fact]
        public async Task RetireContactThrowsExceptionWhenDeleteRulesThrowsException()
        {
            var id = fixture.Create<int>();

            var dto = fixture
                 .Build<ContactDto>()
                 .Without(p => p.Parish)
                 .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(dto);

            deleteRulesMock
                .Setup(m => m.Test(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.RetireContact(id));
        }

        [Fact]
        public async Task RetireContactThrowsExceptionWhenMapperThrowsException()
        {
            var id = fixture.Create<int>();

            var dto = fixture
                .Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(dto);

            deleteRulesMock
                .Setup(m => m.Test(dto));

            repositoryMock
                .Setup(m => m.RetireContact(id))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Contact>(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.RetireContact(id));
        }

        [Fact]
        public async Task RetireContactReturnsExpected()
        {
            var id = fixture.Create<int>();

            var dto = fixture
                .Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var expected = fixture.Create<Contact>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(dto);

            deleteRulesMock
                .Setup(m => m.Test(dto));

            repositoryMock
                .Setup(m => m.RetireContact(id))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Contact>(dto))
                .Returns(expected);

            var actual = await service
                .RetireContact(id);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task UpdateContactThrowsExceptionWhenMapperThrowsException()
        {
            var contact = fixture.Create<Contact>();

            mapperMock
                .Setup(m => m.Map<ContactDto>(contact))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateContact(contact));
        }

        [Fact]
        public async Task UpdateContactThrowsExceptionWhenInsertContactThrowsException()
        {
            var contact = fixture.Create<Contact>();
            var dto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<ContactDto>(It.IsAny<Contact>()))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.InsertContact(dto, It.IsAny<DateTimeOffset>()))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateContact(contact));
        }

        [Fact]
        public async Task UpdateContactCallsInsertContact()
        {
            var contact = fixture.Create<Contact>();
            var dto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var insertedDto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<ContactDto>(It.IsAny<Contact>()))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.InsertContact(dto, It.IsAny<DateTimeOffset>()))
                .ReturnsAsync(insertedDto);
            
            await service.UpdateContact(contact);

            repositoryMock
                .Verify(m => m.InsertContact(
                        dto, It.IsAny<DateTimeOffset>()),
                    Times.Once);
        }

        [Fact]
        public async Task UpdateContactThrowsExceptionWhenRetireContactThrowsException()
        {
            var contact = fixture.Create<Contact>();
            var dto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var insertedDto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<ContactDto>(It.IsAny<Contact>()))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.InsertContact(dto, It.IsAny<DateTimeOffset>()))
                .ReturnsAsync(insertedDto);

            repositoryMock
                .Setup(m => m.RetireContact(contact.Id, It.IsAny<DateTimeOffset>()))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateContact(contact));
        }

        [Fact]
        public async Task UpdateContactCallsRetireContact()
        {
            var contact = fixture.Create<Contact>();
            var expectedId = contact.Id;
            var dto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var insertedDto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var retiredDto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<ContactDto>(It.IsAny<Contact>()))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.InsertContact(dto, It.IsAny<DateTimeOffset>()))
                .ReturnsAsync(insertedDto);

            repositoryMock
                .Setup(m => m.RetireContact(expectedId, It.IsAny<DateTimeOffset>()))
                .ReturnsAsync(retiredDto);

            await service.UpdateContact(contact);

            repositoryMock
                .Verify(m => m.RetireContact(expectedId, It.IsAny<DateTimeOffset>()),
                    Times.Once);
        }

        [Fact]
        public async Task UpdateContactDoesNotCallRetireContactIfNewIdWasNotCreated()
        {
            var contact = fixture.Create<Contact>();
            var expectedId = contact.Id;
            var dto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var insertedDto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .With(p => p.Id, expectedId)
                .Create();

            var retiredDto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<ContactDto>(It.IsAny<Contact>()))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.InsertContact(dto, It.IsAny<DateTimeOffset>()))
                .ReturnsAsync(insertedDto);

            repositoryMock
                .Setup(m => m.RetireContact(It.IsAny<int>(), It.IsAny<DateTimeOffset>()))
                .ReturnsAsync(retiredDto);

            await service.UpdateContact(contact);

            repositoryMock
                .Verify(m => m.RetireContact(It.IsAny<int>(), It.IsAny<DateTimeOffset>()),
                    Times.Never);
        }

        [Fact]
        public async Task UpdateThrowsExceptionWhenContactMapperThrowsException()
        {
            var contact = fixture.Create<Contact>();
            var dto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var insertedDto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<ContactDto>(It.IsAny<Contact>()))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.InsertContact(dto, It.IsAny<DateTimeOffset>()))
                .ReturnsAsync(insertedDto);

            mapperMock
                .Setup(m => m.Map<Contact>(insertedDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateContact(contact));
        }

        [Fact]
        public async Task UpdateContactReturnsExpected()
        {
            var contact = fixture.Create<Contact>();
            var expectedContact = fixture.Create<Contact>();
            var dto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var insertedDto = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            mapperMock
                .Setup(m => m.Map<ContactDto>(It.IsAny<Contact>()))
                .Returns(dto);

            repositoryMock
                .Setup(m => m.InsertContact(dto, It.IsAny<DateTimeOffset>()))
                .ReturnsAsync(insertedDto);

            mapperMock
                .Setup(m => m.Map<Contact>(insertedDto))
                .Returns(expectedContact);

            var actual = await service.UpdateContact(contact);

            Assert.Equal(
                expectedContact,
                actual);
        }
    }
}
