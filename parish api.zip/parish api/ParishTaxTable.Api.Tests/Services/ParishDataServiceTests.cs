﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using AutoMapper;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Services;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Services
{
    public class ParishDataServiceTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<IParishRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private ParishDataService service;

        public ParishDataServiceTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IParishRepository>();
            mapperMock = new Mock<IMapper>();

            service = new ParishDataService(
                repositoryMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllParishesThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllParishes());
        }

        [Fact]
        public async Task GetAllParishesThrowsExceptionWhenMapperThrowsException()
        {
            var parishes = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .CreateMany()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(parishes);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Parish>>(parishes))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllParishes());
        }

        [Fact]
        public async Task GetAllParishesReturnsExpected()
        {
            var parishes = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .CreateMany()
                .ToList();

            var expected = fixture
                .CreateMany<Parish>()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(parishes);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Parish>>(parishes))
                .Returns(expected);

            var actual = await service
                .GetAllParishes();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetParishByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var parishId = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(parishId))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetParishById(parishId));
        }

        [Fact]
        public async Task GetParishByIdThrowsExceptionWhenMapperThrowsException()
        {
            var parishId = fixture.Create<int>();

            var dto = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(parishId))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Parish>(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetParishById(parishId));
        }

        [Fact]
        public async Task GetParishByIdReturnsExpceted()
        {
            var parishId = fixture.Create<int>();

            var dto = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            var expected = fixture.Create<Parish>();

            repositoryMock
                .Setup(m => m.GetById(parishId))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Parish>(dto))
                .Returns(expected);

            var actual = await service
                .GetParishById(parishId);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
