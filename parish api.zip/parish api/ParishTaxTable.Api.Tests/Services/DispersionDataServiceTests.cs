﻿using System;
using System.Threading.Tasks;
using AutoMapper;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Services;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Services
{
    public class DispersionDataServiceTests
        : IDisposable
    {        
        private Fixture fixture;
        private DispersionDataService service;
        private Mock<IDispersionRepository> repositoryMock;
        private Mock<IDispersionUpdateRules> updateRulesMock;
        private Mock<IDispersionCreateRules> createRulesMock;
        private Mock<IDispersionDeleteRules> deleteRulesMock;
        private Mock<IDispersionReplaceRules> replaceRulesMock;
        private Mock<IMapper> mapperMock;

        public DispersionDataServiceTests()
        {
            fixture = new Fixture();

            updateRulesMock = 
                new Mock<IDispersionUpdateRules>();

            createRulesMock =
                new Mock<IDispersionCreateRules>();

            deleteRulesMock =
                new Mock<IDispersionDeleteRules>();

            replaceRulesMock =
                new Mock<IDispersionReplaceRules>();

            repositoryMock =
                new Mock<IDispersionRepository>();

            mapperMock =
                new Mock<IMapper>();            

            service = new DispersionDataService(
                repositoryMock.Object,
                updateRulesMock.Object,
                createRulesMock.Object,
                deleteRulesMock.Object,
                replaceRulesMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            updateRulesMock = null;
            createRulesMock = null;
            deleteRulesMock = null;
            replaceRulesMock = null;
            mapperMock = null;
            service = null;
        }

        [Fact]
        public void ConstructorCanCreate()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetDispersionByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var dispersionId = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(dispersionId))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetDispersionById(
                    dispersionId));
        }

        [Fact]
        public async Task GetDispersionByIdThrowsExceptionWhenMapperThrowsException()
        {
            var dispersionId = fixture.Create<int>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(dispersionId))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Dispersion>(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetDispersionById(
                    dispersionId));
        }

        [Fact]
        public async Task GetDispersionByIdReturnsExpected()
        {
            var dispersionId = fixture.Create<int>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var expected = fixture.Create<Dispersion>();

            repositoryMock
                .Setup(m => m.GetById(dispersionId))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Dispersion>(dto))
                .Returns(expected);

            var actual = await service
                .GetDispersionById(dispersionId);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task UpdateThrowsExceptionWhenRepositoryGetByIdThrowsException()
        {
            var dispersion = fixture
                .Create<Dispersion>();

            repositoryMock
                .Setup(m => m.GetById(
                    dispersion.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateDispersion(
                    dispersion));
        }

        [Fact]
        public async Task UpdateThrowsExceptionWhenUpdateRulesThrowsException()
        {
            var dispersion = fixture
                .Create<Dispersion>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(
                    dispersion.Id))
                .ReturnsAsync(dto);

            updateRulesMock
                .Setup(m => m.Test(
                    dispersion,
                    dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateDispersion(
                    dispersion));
        }

        [Fact]
        public async Task UpdateThrowsExceptionWhenRepositoryUpdateThrowsException()
        {
            var dispersion = fixture
                .Create<Dispersion>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(
                    dispersion.Id))
                .ReturnsAsync(dto);

            updateRulesMock
                .Setup(m => m.Test(
                    dispersion,
                    dto));

            repositoryMock
                .Setup(m => m.Update(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateDispersion(
                    dispersion));
        }

        [Fact]
        public async Task UpdateThrowsExceptionWhenMapperThrowsException()
        {
            var dispersion = fixture
                .Create<Dispersion>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();
           

            repositoryMock
                .Setup(m => m.GetById(
                    dispersion.Id))
                .ReturnsAsync(dto);

            updateRulesMock
                .Setup(m => m.Test(
                    dispersion,
                    dto));

            repositoryMock
                .Setup(m => m.Update(dto))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Dispersion>(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.UpdateDispersion(
                    dispersion));
        }

        [Fact]
        public async Task UpdateReturnsExpected()
        {
            var dispersion = fixture
                .Create<Dispersion>();

            var expected = fixture
                .Create<Dispersion>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();
           

            repositoryMock
                .Setup(m => m.GetById(
                    dispersion.Id))
                .ReturnsAsync(dto);

            updateRulesMock
                .Setup(m => m.Test(
                    dispersion,
                    dto));

            repositoryMock
                .Setup(m => m.Update(dto))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Dispersion>(dto))
                .Returns(expected);

            var actual = await service
                .UpdateDispersion(dispersion);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task UpdateSetsTermDateToEndOfDay()
        {
            var dispersion = fixture
                .Create<Dispersion>();

            var expected = fixture
                .Create<Dispersion>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();
           

            repositoryMock
                .Setup(m => m.GetById(
                    dispersion.Id))
                .ReturnsAsync(dto);

            updateRulesMock
                .Setup(m => m.Test(
                    dispersion,
                    dto));

            repositoryMock
                .Setup(m => m.Update(dto))
                .ReturnsAsync(dto);

            mapperMock
                .Setup(m => m.Map<Dispersion>(dto))
                .Returns(expected);

            await service
                .UpdateDispersion(dispersion);

            Assert.Equal(
                dispersion.TermDate.EndOfDay(),
                dto.TermDate);
        }

        [Fact]
        public async Task CreateThrowsExceptionWhenDtoMapperThrowsException()
        {
            var dispersion = fixture
                .Create<Dispersion>();

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateDispersion(
                    dispersion));
        }

        [Fact]
        public async Task CreateThrowsExceptionWhenCreateRulesThrowsException()
        {
            var dispersion = fixture
                .Create<Dispersion>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Returns(dto);

            createRulesMock
                .Setup(m => m.Test(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateDispersion(
                    dispersion));
        }

        [Fact]
        public async Task CreateThrowsExceptionWhenRepositoryCreateThrowsException()
        {
            var dispersion = fixture
                .Create<Dispersion>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Returns(dto);

            createRulesMock
                .Setup(m => m.Test(dto));

            repositoryMock
                .Setup(m => m.Create(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateDispersion(
                    dispersion));
        }

        [Fact]
        public async Task CreateThrowsExceptionWhenDispersionMapperThrowsException()
        {            
            var dispersion = fixture
                .Create<Dispersion>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var createdDto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Returns(dto);

            createRulesMock
                .Setup(m => m.Test(dto));

            repositoryMock
                .Setup(m => m.Create(dto))
                .ReturnsAsync(createdDto);

            mapperMock
                .Setup(m => m.Map<Dispersion>(createdDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateDispersion(
                    dispersion));
        }

        [Fact]
        public async Task CreateReturnsExpected()
        {
            var dispersion = fixture
                .Create<Dispersion>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var createdDto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var expected = fixture
                .Create<Dispersion>();

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Returns(dto);

            createRulesMock
                .Setup(m => m.Test(dto));

            repositoryMock
                .Setup(m => m.Create(dto))
                .ReturnsAsync(createdDto);

            mapperMock
                .Setup(m => m.Map<Dispersion>(createdDto))
                .Returns(expected);

            var actual = await service
                .CreateDispersion(
                    dispersion);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task DeleteThrowsExceptionWhenRepositoryGetByIdThrowsException()
        {
            var id = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.DeleteDispersion(id));
        }

        [Fact]
        public async Task DeleteThrowsExceptionWhenDeleteRulesThrowsException()
        {
            var id = fixture.Create<int>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(dto);

            deleteRulesMock
                .Setup(m => m.Test(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.DeleteDispersion(id));
        }

        [Fact]
        public async Task DeleteThrowsExceptionWhenRepositoryDeleteThrowsException()
        {
            var id = fixture.Create<int>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(dto);

            deleteRulesMock
                .Setup(m => m.Test(dto));

            repositoryMock
                .Setup(m => m.Delete(id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.DeleteDispersion(id));
        }

        [Fact]
        public async Task DeleteExecutesSuccessfully()
        {
            var id = fixture.Create<int>();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(dto);

            deleteRulesMock
                .Setup(m => m.Test(dto));

            repositoryMock
                .Setup(m => m.Delete(id))
                .Returns(Task.FromResult(true))
                .Verifiable();

            await service.DeleteDispersion(id);

            repositoryMock
                .Verify(m => m.Delete(id), 
                    Times.Once);
        }

        [Fact]
        public async Task ReplaceDispersionThrowsExceptionWhenRepositoryGetThrowsException()
        {
            var dispersion = fixture.Create<Dispersion>();
            var invalidatedId = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(invalidatedId))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.ReplaceDispersion(
                    dispersion,
                    invalidatedId));
        }

        [Fact]
        public async Task ReplaceDispersionThrowsInvalidOperationExceptionWhenRepositoryReturnsNull()
        {
            var dispersion = fixture.Create<Dispersion>();
            var invalidatedId = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(invalidatedId))
                .ReturnsAsync((DispersionDto) null);

            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                service.ReplaceDispersion(
                    dispersion,
                    invalidatedId));
        }

        [Fact]
        public async Task ReplaceDispersionThrowsInvalidOperationExceptionWhenNotReplacingInvalidatedDispersion()
        {            
            var dispersion = fixture.Create<Dispersion>();
            var invalidatedId = fixture.Create<int>();

            var invalidatedDispersion = fixture
                .Build<DispersionDto>()
                .With(p => p.Id, invalidatedId)
                .With(p => p.IsInvalidDispersion, false)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(invalidatedId))
                .ReturnsAsync(invalidatedDispersion);

            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                service.ReplaceDispersion(
                    dispersion,
                    invalidatedId));
        }

        [Fact]
        public async Task ReplaceDispersionThrowsExceptionWhenDtoMapperThrowsException()
        {
            var dispersion = fixture.Create<Dispersion>();
            var invalidatedId = fixture.Create<int>();

            var invalidatedDispersion = fixture
                .Build<DispersionDto>()
                .With(p => p.Id, invalidatedId)
                .With(p => p.IsInvalidDispersion, true)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(invalidatedId))
                .ReturnsAsync(invalidatedDispersion);

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.ReplaceDispersion(
                    dispersion,
                    invalidatedId));
        }

        [Fact]
        public async Task ReplaceDispersionThrowsExceptionWhenRulesThrowsException()
        {
            var dispersion = fixture.Create<Dispersion>();
            var invalidatedId = fixture.Create<int>();

            var invalidatedDispersion = fixture
                .Build<DispersionDto>()
                .With(p => p.Id, invalidatedId)
                .With(p => p.IsInvalidDispersion, true)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(invalidatedId))
                .ReturnsAsync(invalidatedDispersion);

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Returns(dto);

            replaceRulesMock
                .Setup(m => m.Test(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.ReplaceDispersion(
                    dispersion,
                    invalidatedId));
        }

        [Fact]
        public async Task ReplaceDispersionThrowsExceptionWhenRepositoryCreateThrowsException()
        {
            var dispersion = fixture.Create<Dispersion>();
            var invalidatedId = fixture.Create<int>();

            var invalidatedDispersion = fixture
                .Build<DispersionDto>()
                .With(p => p.Id, invalidatedId)
                .With(p => p.IsInvalidDispersion, true)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(invalidatedId))
                .ReturnsAsync(invalidatedDispersion);

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Returns(dto);

            replaceRulesMock
                .Setup(m => m.Test(dto));

            repositoryMock
                .Setup(m => m.Create(dto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.ReplaceDispersion(
                    dispersion,
                    invalidatedId));
        }

        [Fact]
        public async Task ReplaceDispersionThrowsExceptionWhenDispersionMapperThrowsException()
        {
            var dispersion = fixture.Create<Dispersion>();
            var invalidatedId = fixture.Create<int>();

            var invalidatedDispersion = fixture
                .Build<DispersionDto>()
                .With(p => p.Id, invalidatedId)
                .With(p => p.IsInvalidDispersion, true)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var createdDto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(invalidatedId))
                .ReturnsAsync(invalidatedDispersion);

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Returns(dto);

            replaceRulesMock
                .Setup(m => m.Test(dto));

            repositoryMock
                .Setup(m => m.Create(dto))
                .ReturnsAsync(createdDto);                

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.ReplaceDispersion(
                    dispersion,
                    invalidatedId));
        }

        [Fact]
        public async Task ReplaceDispersionReturnsExpected()
        {
            var dispersion = fixture.Create<Dispersion>();
            var invalidatedId = fixture.Create<int>();

            var invalidatedDispersion = fixture
                .Build<DispersionDto>()
                .With(p => p.Id, invalidatedId)
                .With(p => p.IsInvalidDispersion, true)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var dto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var createdDto = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var expected = fixture.Create<Dispersion>();

            repositoryMock
                .Setup(m => m.GetById(invalidatedId))
                .ReturnsAsync(invalidatedDispersion);

            mapperMock
                .Setup(m => m.Map<DispersionDto>(dispersion))
                .Returns(dto);

            replaceRulesMock
                .Setup(m => m.Test(dto));

            repositoryMock
                .Setup(m => m.Create(dto))
                .ReturnsAsync(createdDto);

            mapperMock
                .Setup(m => m.Map<Dispersion>(createdDto))
                .Returns(expected);

            var actual = await service
                .ReplaceDispersion(dispersion, invalidatedId);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
