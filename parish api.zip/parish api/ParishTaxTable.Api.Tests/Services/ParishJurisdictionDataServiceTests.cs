﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using AutoMapper;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Services;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Services
{
    public class ParishJurisdictionDataServiceTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<IParishRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private ParishJurisdictionDataService service;

        public ParishJurisdictionDataServiceTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IParishRepository>();
            mapperMock = new Mock<IMapper>();

            service = new ParishJurisdictionDataService(
                repositoryMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllParishContactsThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.GetWithJurisdictions())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllParishJurisdictions());
        }

        [Fact]
        public async Task GetAllParishContactsThrowsExceptionWhenMapperThrowsException()
        {
            var parishes = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .CreateMany();

            repositoryMock
                .Setup(m => m.GetWithJurisdictions())
                .ReturnsAsync(parishes);

            mapperMock
                .Setup(m => m.Map<IEnumerable<ParishJurisdiction>>(parishes))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllParishJurisdictions());
        }

        [Fact]
        public async Task GetAllParishContactsReturnsExpected()
        {
            var parishes = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .CreateMany();

            var expected = fixture
                .CreateMany<ParishJurisdiction>()
                .ToList();

            repositoryMock
                .Setup(m => m.GetWithJurisdictions())
                .ReturnsAsync(parishes);

            mapperMock
                .Setup(m => m.Map<IEnumerable<ParishJurisdiction>>(parishes))
                .Returns(expected);

            var actual = await service
                .GetAllParishJurisdictions();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetParishContactsByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var parishId = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetWithJurisdictionsById(parishId))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetParishJurisdictionById(parishId));
        }

        [Fact]
        public async Task GetParishContactsByIdThrowsExceptionWhenMapperThrowsException()
        {
            var parishId = fixture.Create<int>();

            var parish = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            repositoryMock
                .Setup(m => m.GetWithJurisdictionsById(parishId))
                .ReturnsAsync(parish);

            mapperMock
                .Setup(m => m.Map<ParishJurisdiction>(parish))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetParishJurisdictionById(parishId));
        }

        [Fact]
        public async Task GetParishContactsByIdReturnsExpected()
        {
            var parishId = fixture.Create<int>();

            var parish = fixture
                .Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            var expected = fixture
                .Create<ParishJurisdiction>();

            repositoryMock
                .Setup(m => m.GetWithJurisdictionsById(parishId))
                .ReturnsAsync(parish);

            mapperMock
                .Setup(m => m.Map<ParishJurisdiction>(parish))
                .Returns(expected);

            var actual = await service
                .GetParishJurisdictionById(parishId);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
