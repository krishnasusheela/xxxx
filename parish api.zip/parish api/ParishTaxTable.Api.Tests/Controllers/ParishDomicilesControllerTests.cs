﻿using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Api.Controllers;
using ParishTaxTable.Api.Requests;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Controllers
{
    public class ParishDomicilesControllerTests
         : IDisposable
    {
        private Fixture fixture;
        private ParishDomicilesController controller;
        private Mock<IMediator> mediatorMock;

        public ParishDomicilesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller =
                new ParishDomicilesController(
                    mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorException()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishDomicilesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get();
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNull()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishDomicilesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((IEnumerable<ParishDomicile>)null);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsEmpty()
        {
            var expected = new List<ParishDomicile>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishDomicilesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResult()
        {
            var expected =
                fixture.CreateMany<ParishDomicile>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishDomicilesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<ParishDomicile>>(viewResult.Value);
        }

        //Specific Parish Tests
        [Fact]
        public async Task GetReturnsBadRequestOnMediatorExceptionForSpecificDomicile()
        {
            var expected = fixture.Create<ParishDomicile>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<ParishDomicileInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get(expected.Id);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNullForSpecificDomicile()
        {
            var expected = fixture.Create<ParishDomicile>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<ParishDomicileInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((ParishDomicile)null);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResultForSpecificDomicile()
        {
            var expected = fixture.Create<ParishDomicile>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<ParishDomicileInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<ParishDomicile>(viewResult.Value);
        }

    }
}
