﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Api.Controllers;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Controllers
{
    public class DispersionsControllerTests
         : IDisposable
    {
        private Fixture fixture;
        private DispersionsController controller;
        private Mock<IMediator> mediatorMock;

        public DispersionsControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller =
                new DispersionsController(
                    mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        //Specific Dispersion Tests
        [Fact]
        public async Task GetWithIdReturnsBadRequestOnMediatorException()
        {
            var expected = fixture.Create<Dispersion>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<DispersionInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get(expected.Id);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetWithIdReturnsNoContentWhenMediatorReturnsNull()
        {
            var expected = fixture.Create<Dispersion>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<DispersionInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Dispersion)null);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetWithIdReturnsExpectedResult()
        {
            var expected = fixture.Create<Dispersion>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Dispersion>(viewResult.Value);
        }

        [Fact]
        public async Task UpdateReturnsBadRequestOnMediatorException()
        {
            var expected = fixture.Create<Dispersion>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionUpdateRequest>(g => g.Dispersion == expected),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Update(expected.Id,expected);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }
        [Fact]
        public async Task UpdateReturnsBadRequestOnIdNotMatchingDispersionId()
        {
            var expected = fixture.Create<Dispersion>();
            var id = expected.Id + 1;

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionUpdateRequest>(g => g.Dispersion == expected),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result = await controller.Update(id, expected);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }
        [Fact]
        public async Task UpdateReturnsBadRequestWithCustomMessageOnInvalidOperationException()
        {
            var expected = fixture.Create<Dispersion>();
            var expectedErrorMessage = "Custom Error";

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionUpdateRequest>(g => g.Dispersion == expected),
                    default(System.Threading.CancellationToken)))
                .Throws(new InvalidOperationException(expectedErrorMessage));

            var result = await controller.Update(expected.Id, expected);

            Assert.IsType<BadRequestObjectResult>(result);

            var badRequestObjectResult = result as BadRequestObjectResult;

            Assert.Equal(expectedErrorMessage, badRequestObjectResult?.Value);
        }

        [Fact]
        public async Task UpdateReturnsNoContentWhenMediatorReturnsNull()
        {
            var expected = fixture.Create<Dispersion>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionUpdateRequest>(g => g.Dispersion == expected),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Dispersion)null);

            var result =
                await controller.Update(expected.Id, expected);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task UpdateReturnsExpectedResult()
        {
            var expected = fixture.Create<Dispersion>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionUpdateRequest>(g => g.Dispersion == expected),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Update(expected.Id, expected);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Dispersion>(viewResult.Value);
        }


        [Fact]
        public async Task CreateReturnsBadRequestOnMediatorException()
        {
            var expectedId = 0;

            var expectedInvalidatedId = fixture.Create<int?>();

            var expected = fixture
                .Build<Dispersion>()
                .With(x => x.Id, expectedId)
                .Create();            

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionCreateRequest>(g => g.Dispersion == expected && g.InvalidatedId == expectedInvalidatedId),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Create(expected, expectedInvalidatedId);

            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task CreateReturnsBadRequestOnIdNotZero()
        {
            var unexpectedId = 1;
            var expectedInvalidatedId = fixture.Create<int?>();
            var expected = fixture
                .Build<Dispersion>()
                .With(x => x.Id, unexpectedId)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionCreateRequest>(g => g.Dispersion == expected && g.InvalidatedId == expectedInvalidatedId),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result = await controller.Create(expected, expectedInvalidatedId);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task CreateReturnsBadRequestWithCustomMessageOnInvalidOperationException()
        {
            var expectedId = 0;
            var expectedInvalidatedId = fixture.Create<int?>();
            var expected = fixture
                .Build<Dispersion>()
                .With(x => x.Id, expectedId)
                .Create();

            var expectedErrorMessage = "Custom Error";

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionCreateRequest>(g => g.Dispersion == expected && g.InvalidatedId == expectedInvalidatedId),
                    default(System.Threading.CancellationToken)))
                .Throws(new InvalidOperationException(expectedErrorMessage));

            var result = await controller.Create(expected, expectedInvalidatedId);

            Assert.IsType<BadRequestObjectResult>(result);

            var badRequestObjectResult = result as BadRequestObjectResult;

            Assert.Equal(expectedErrorMessage, badRequestObjectResult?.Value);
        }

        [Fact]
        public async Task CreateReturnsNoContentWhenMediatorReturnsNull()
        {
            var expectedId = 0;
            var expectedInvalidatedId = fixture.Create<int?>();
            var expected = fixture
                .Build<Dispersion>()
                .With(x => x.Id, expectedId)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionCreateRequest>(g => g.Dispersion == expected && g.InvalidatedId ==  expectedInvalidatedId),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Dispersion)null);

            var result =
                await controller.Create(expected, expectedInvalidatedId);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task CreateReturnsExpectedResult()
        {
            var expectedId = 0;
            var expectedInvalidatedId = fixture.Create<int?>();
            var expected = fixture
                .Build<Dispersion>()
                .With(x => x.Id, expectedId)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionCreateRequest>(g => g.Dispersion == expected && g.InvalidatedId == expectedInvalidatedId),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Create(expected, expectedInvalidatedId);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            Assert.IsAssignableFrom<Dispersion>(viewResult.Value);
        }

        [Fact]
        public async Task DeleteReturnsBadRequestOnMediatorException()
        {
            var id = fixture.Create<int>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionDeleteRequest>(g => g.Id == id),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Delete(id);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task DeleteReturnsBadRequestWithCustomMessageOnInvalidOperationException()
        {
            var id = fixture.Create<int>();
            var expectedErrorMessage = "Custom Error";
            
            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionDeleteRequest>(g => g.Id == id),
                    default(System.Threading.CancellationToken)))
                .Throws(new InvalidOperationException(expectedErrorMessage));

            var result = await controller.Delete(id);

            Assert.IsType<BadRequestObjectResult>(result);

            var badRequestObjectResult = result as BadRequestObjectResult;

            Assert.Equal(expectedErrorMessage, badRequestObjectResult?.Value);
        }



        [Fact]
        public async Task DeleteReturnsExpectedResult()
        {
            var id = fixture.Create<int>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionDeleteRequest>(g => g.Id == id),
                    default(System.Threading.CancellationToken)))
            .ReturnsAsync(Unit.Value);

            var result =
                await controller.Delete(id);

            Assert.IsType<OkResult>(result);
        }

    }
}
