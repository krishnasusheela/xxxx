﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Api.Controllers;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Controllers
{
    public class DomicileCodesControllerTests
        : IDisposable
    {
        private Fixture fixture;
        private DomicileCodesController controller;
        private Mock<IMediator> mediatorMock;

        public DomicileCodesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller =
                new DomicileCodesController(
                    mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }



        [Fact]
        public async Task GetWithCodeReturnsBadRequestOnMediatorException()
        {
            var expected = fixture.Create<Domicile>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileCodeInquiryRequest>(g => g.Code == expected.ParishCode+expected.DomicileCode),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get(expected.ParishCode + expected.DomicileCode);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetWithCodeReturnsNoContentWhenMediatorReturnsNull()
        {
            var expected = fixture.Create<Domicile>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileCodeInquiryRequest>(g => g.Code == expected.ParishCode + expected.DomicileCode),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Domicile)null);

            var result =
                await controller.Get(expected.ParishCode + expected.DomicileCode);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetWithCodeReturnsExpectedResult()
        {
            var expected = fixture.Create<Domicile>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileCodeInquiryRequest>(g => g.Code == expected.ParishCode + expected.DomicileCode),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get(expected.ParishCode + expected.DomicileCode);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Domicile>(viewResult.Value);
        }
    }
}
