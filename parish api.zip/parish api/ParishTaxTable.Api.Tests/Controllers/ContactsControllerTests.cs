﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Api.Controllers;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Controllers
{
    public class ContactsControllerTests
         : IDisposable
    {
        private Fixture fixture;
        private ContactsController controller;
        private Mock<IMediator> mediatorMock;

        public ContactsControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller =
                new ContactsController(
                    mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        //Specific Contact Tests
        [Fact]
        public async Task GetReturnsBadRequestOnMediatorExceptionForSpecificContact()
        {
            var expected = fixture.Create<Contact>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<ContactInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get(expected.Id);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNullForSpecificContact()
        {
            var expected = fixture.Create<Contact>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<ContactInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Contact)null);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResultForSpecificContact()
        {
            var expected = fixture.Create<Contact>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<ContactInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Contact>(viewResult.Value);
        }

    }
}
