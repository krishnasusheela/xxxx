﻿using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Api.Controllers;
using ParishTaxTable.Api.Requests;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Controllers
{
    public class ParishesControllerTests
        : IDisposable
    {
        private Fixture fixture;
        private ParishesController controller;
        private Mock<IMediator> mediatorMock;

        public ParishesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller = 
                new ParishesController(
                    mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorException()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishesInquiryRequest>(), 
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get();
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNull()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((IEnumerable<Parish>)null);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsEmpty()
        {
            var expected = new List<Parish>();
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResult()
        {
            var expected = 
                fixture.CreateMany<Parish>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<Parish>>(viewResult.Value);
        }

        //Specific Parish Tests
        [Fact]
        public async Task GetReturnsBadRequestOnMediatorExceptionForSpecificParish()
        {
            var expected = fixture.Create<Parish>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<ParishInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get(expected.Id);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNullForSpecificParish()
        {
            var expected = fixture.Create<Parish>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<ParishInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Parish)null);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResultForSpecificParish()
        {
            var expected = fixture.Create<Parish>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<ParishInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Parish>(viewResult.Value);
        }

        [Fact]
        public async Task GetNextDomicileCodeReturnsBadRequestOnMediatorException()
        {

            var expected =
                fixture.Create<ParishNextDomicileCode>();

            var expectedId =
                fixture.Create<int>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<ParishNextDomicileCodeInquiryRequest>(g => g.Id == expectedId),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.GetNextDomicileCode(expectedId);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetNextDomicileCodeReturnsNoContentWhenMediatorReturnsNull()
        {

            var expected =
                fixture.Create<ParishNextDomicileCode>();

            var expectedId =
                fixture.Create<int>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<ParishNextDomicileCodeInquiryRequest>(g => g.Id == expectedId),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((ParishNextDomicileCode)null);

            var result =
                await controller.GetNextDomicileCode(expectedId);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetNextDomicileCodeReturnsExpectedResult()
        {
            var expected =
                fixture.Create<ParishNextDomicileCode>();

            var expectedId =
                fixture.Create<int>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<ParishNextDomicileCodeInquiryRequest>(g => g.Id == expectedId),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.GetNextDomicileCode(expectedId);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<ParishNextDomicileCode>(viewResult.Value);
        }

    }
}
