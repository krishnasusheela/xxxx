﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Api.Controllers;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Controllers
{
    public class ParishContactsControllerTests
         : IDisposable
    {
        private Fixture fixture;
        private ParishContactsController controller;
        private Mock<IMediator> mediatorMock;

        public ParishContactsControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller =
                new ParishContactsController(
                    mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorException()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishContactsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get();
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNull()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishContactsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((IEnumerable<ParishContact>)null);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsEmpty()
        {
            var expected = new List<ParishContact>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishContactsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResult()
        {
            var expected =
                fixture.CreateMany<ParishContact>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishContactsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<ParishContact>>(viewResult.Value);
        }

        //Specific Parish Tests
        [Fact]
        public async Task GetReturnsBadRequestOnMediatorExceptionForSpecificContact()
        {
            var expected = fixture.Create<ParishContact>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<ParishContactInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get(expected.Id);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNullForSpecificContact()
        {
            var expected = fixture.Create<ParishContact>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<ParishContactInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((ParishContact)null);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResultForSpecificContact()
        {
            var expected = fixture.Create<ParishContact>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<ParishContactInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<ParishContact>(viewResult.Value);
        }

    }
}
