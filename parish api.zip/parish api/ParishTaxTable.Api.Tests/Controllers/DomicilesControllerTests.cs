﻿using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Api.Controllers;
using ParishTaxTable.Api.Requests;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Controllers
{
    public class DomicilesControllerTests
        : IDisposable
    {
        private Fixture fixture;
        private DomicilesController controller;
        private Mock<IMediator> mediatorMock;

        public DomicilesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller =
                new DomicilesController(
                    mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorException()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<DomicilesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get();
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNull()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<DomicilesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((IEnumerable<Domicile>)null);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsEmpty()
        {
            var expected = new List<Domicile>();
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<DomicilesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResult()
        {
            var expected =
                fixture.CreateMany<Domicile>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<DomicilesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<Domicile>>(viewResult.Value);
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorExceptionForSpecificDomicile()
        {
            var expected = fixture.Create<Domicile>();
            var expectedDate = fixture.Create<DateTimeOffset?>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<DomicileInquiryRequest>(g => (g.Id == expected.Id) && (g.Date == expectedDate)),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get(expected.Id, date: expectedDate);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNullForSpecificDomicile()
        {
            var expected = fixture.Create<Domicile>();
            var expectedDate = fixture.Create<DateTimeOffset?>();
            mediatorMock
                .Setup(m => m.Send(
                     It.Is<DomicileInquiryRequest>(g => (g.Id == expected.Id) && (g.Date == expectedDate)),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Domicile)null);

            var result =
                await controller.Get(expected.Id, expectedDate);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResultForSpecificDomicile()
        {
            var expected = fixture.Create<Domicile>();
            var expectedDate = fixture.Create<DateTimeOffset?>();
            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileInquiryRequest>(g => (g.Id == expected.Id) && (g.Date == expectedDate)),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get(expected.Id, expectedDate);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Domicile>(viewResult.Value);
        }

        [Fact]
        public async Task OnUpdateGetReturnsBadRequestOnMediatorExceptionForSpecificDomicile()
        {
            var domicileChangesForUpdate = fixture.Create<Domicile>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<DomicileUpdateRequest>(g => g.Domicile == domicileChangesForUpdate),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Update(domicileChangesForUpdate.Id,domicileChangesForUpdate);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task OnUpdateGetReturnsNoContentWhenMediatorReturnsNullForSpecificDomicile()
        {
            var domicileChangesForUpdate = fixture.Create<Domicile>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<DomicileUpdateRequest>(g => g.Domicile == domicileChangesForUpdate),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Domicile)null);

            var result =
                await controller.Update(domicileChangesForUpdate.Id, domicileChangesForUpdate);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task OnUpdateGetReturnsExpectedResultForSpecificDomicile()
        {
            var domicileChangesForUpdate = fixture.Create<Domicile>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileUpdateRequest>(g => g.Domicile == domicileChangesForUpdate),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(domicileChangesForUpdate);

            var result =
                await controller.Update(domicileChangesForUpdate.Id, domicileChangesForUpdate);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Domicile>(viewResult.Value);
        }
        
        [Fact]
        public async Task OnUpdateReturnsBadRequestWithCustomMessageOnInvalidOperationException()
        {
            var expected = fixture.Create<Domicile>();
            var expectedErrorMessage = "Custom Error";

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileUpdateRequest>(g => g.Domicile == expected),
                    default(System.Threading.CancellationToken)))
                .Throws(new InvalidOperationException(expectedErrorMessage));

            var result = await controller.Update(expected.Id, expected);

            Assert.IsType<BadRequestObjectResult>(result);

            var badRequestObjectResult = result as BadRequestObjectResult;

            Assert.Equal(expectedErrorMessage, badRequestObjectResult?.Value);
        }

        [Fact]
        public async Task CreateReturnsBadRequestOnMediatorException()
        {
            var expectedId = 0;

            var expected = fixture
                .Build<Domicile>()
                .With(x => x.Id, expectedId)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileCreateRequest>(g => g.Domicile == expected),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Create(expected);

            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task CreateReturnsBadRequestOnIdNotZero()
        {
            var unexpectedId = 1;
            var expected = fixture
                .Build<Domicile>()
                .With(x => x.Id, unexpectedId)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileCreateRequest>(g => g.Domicile == expected),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result = await controller.Create(expected);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task CreateReturnsBadRequestWithCustomMessageOnInvalidOperationException()
        {
            var expectedId = 0;
            var expected = fixture
                .Build<Domicile>()
                .With(x => x.Id, expectedId)
                .Create();

            var expectedErrorMessage = "Custom Error";

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileCreateRequest>(g => g.Domicile == expected),
                    default(System.Threading.CancellationToken)))
                .Throws(new InvalidOperationException(expectedErrorMessage));

            var result = await controller.Create(expected);

            Assert.IsType<BadRequestObjectResult>(result);

            var badRequestObjectResult = result as BadRequestObjectResult;

            Assert.Equal(expectedErrorMessage, badRequestObjectResult?.Value);
        }

        [Fact]
        public async Task CreateReturnsNoContentWhenMediatorReturnsNull()
        {
            var expectedId = 0;
            var expected = fixture
                .Build<Domicile>()
                .With(x => x.Id, expectedId)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileCreateRequest>(g => g.Domicile == expected),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Domicile)null);

            var result =
                await controller.Create(expected);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task CreateReturnsExpectedResult()
        {
            var expectedId = 0;
            var expected = fixture
                .Build<Domicile>()
                .With(x => x.Id, expectedId)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileCreateRequest>(g => g.Domicile == expected),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Create(expected);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            Assert.IsAssignableFrom<Domicile>(viewResult.Value);
        }

    }

}
