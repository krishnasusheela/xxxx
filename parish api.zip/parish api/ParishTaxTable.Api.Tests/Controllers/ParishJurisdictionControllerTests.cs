﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Api.Controllers;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Requests;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Controllers
{
    public class ParishJurisdictionsControllerTests
         : IDisposable
    {
        private Fixture fixture;
        private ParishJurisdictionsController controller;
        private Mock<IMediator> mediatorMock;

        public ParishJurisdictionsControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller =
                new ParishJurisdictionsController(
                    mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorException()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishJurisdictionsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get();
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNull()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishJurisdictionsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((IEnumerable<ParishJurisdiction>)null);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsEmpty()
        {
            var expected = new List<ParishJurisdiction>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishJurisdictionsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResult()
        {
            var expected =
                fixture.CreateMany<ParishJurisdiction>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishJurisdictionsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<ParishJurisdiction>>(viewResult.Value);
        }

        //Specific Parish Tests
        [Fact]
        public async Task GetReturnsBadRequestOnMediatorExceptionForSpecificJurisdiction()
        {
            var expected = fixture.Create<ParishJurisdiction>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<ParishJurisdictionInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get(expected.Id);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNullForSpecificJurisdiction()
        {
            var expected = fixture.Create<ParishJurisdiction>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<ParishJurisdictionInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((ParishJurisdiction)null);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResultForSpecificJurisdiction()
        {
            var expected = fixture.Create<ParishJurisdiction>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<ParishJurisdictionInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<ParishJurisdiction>(viewResult.Value);
        }

    }
}
