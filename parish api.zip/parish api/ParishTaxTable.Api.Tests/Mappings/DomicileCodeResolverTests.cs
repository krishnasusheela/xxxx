﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Infrastructure.Mappings;
using ParishTaxTable.Api.Infrastructure.Models;
using Xunit;

namespace ParishTaxTable.Api.Tests.Mappings
{
    public class DomicileCodeResolverTests
        : IDisposable
    {
        private Fixture fixture;
        private DomicileCodeResolver resolver;

        public DomicileCodeResolverTests()
        {
            fixture = new Fixture();
            resolver = new DomicileCodeResolver();
        }

        public void Dispose()
        {
            fixture = null;
            resolver = null;
        }

        [Fact]
        public void ResolveCreatesDomicileCode()
        {
            var parishCode = fixture.Create<string>();
            var domicileCode = fixture.Create<string>();

            var source = new DomicileDto()
            {
                Parish = new ParishDto
                {
                    Code = parishCode
                },
                Code = domicileCode
            };

            var expected = $"{parishCode}{domicileCode}";

            var actual = resolver.Resolve(
                source,
                null,
                null,
                null);

            Assert.Equal(expected, actual);
        }
    }
}
