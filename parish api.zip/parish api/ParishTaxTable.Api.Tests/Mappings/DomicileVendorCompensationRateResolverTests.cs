﻿using System;
using System.Collections.Generic;
using System.Globalization;
using ParishTaxTable.Api.Infrastructure.Mappings;
using ParishTaxTable.Api.Infrastructure.Models;
using Xunit;

namespace ParishTaxTable.Api.Tests.Mappings
{
    public class DomicileVendorCompensationRateResolverTests
        : IDisposable
    {
        private DomicileVendorCompensationRateResolver resolver;

        public DomicileVendorCompensationRateResolverTests()
        {
            resolver = new DomicileVendorCompensationRateResolver();
        }

        public void Dispose()
        {
            resolver = null;
        }

        [Fact]
        public void ResolveReturnsZeroWhenTheCollectionRateIsZero()
        {
            var expected = new decimal(0.0);

            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
                {
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(1)
                    }
                }
            };

            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = resolver.Resolve(
                source,
                null,
                new decimal(0.0),
                null);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void ResolveReturnsZeroWhenTheDistributionRateForAllDispersionsIsZero()
        {
            var expected = new decimal(0.0);

            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
                {
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(0.0),
                        VendorComp = new decimal(1.0)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(0.0),
                        VendorComp = new decimal(1.0)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(0.0),
                        VendorComp = new decimal(1.0)
                    },
                }
            };

            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = resolver.Resolve(
                source,
                null,
                new decimal(0.0),
                null);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void ResolveReturnsZeroWhenTheVendorCompForAllDispersionsIsZero()
        {
            var expected = new decimal(0.0);

            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
                {
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(1.0),
                        VendorComp = new decimal(0.0)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(1.0),
                        VendorComp = new decimal(0.0)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(1.0),
                        VendorComp = new decimal(0.0)
                    },
                }
            };

            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = resolver.Resolve(
                source,
                null,
                new decimal(0.0),
                null);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void ResolveReturnsTheVendorCompValueWhenAllVendorCompValuesAreTheSame()
        {
            var expected = new decimal(5.0);

            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
                {
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(5.0),
                        VendorComp = new decimal(5.0)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(5.0),
                        VendorComp = new decimal(5.0)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(5.0),
                        VendorComp = new decimal(5.0)
                    },
                }
            };

            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = resolver.Resolve(
                source,
                null,
                new decimal(0.0),
                null);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void ResolveReturnsTheVendorCompValueCorrectly()
        {
            var expected = new decimal(0.0067);

            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
                {
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(5.0),
                        VendorComp = new decimal(0.01)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(5.0),
                        VendorComp = new decimal(0.01)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(5.0),
                        VendorComp = new decimal(0.0)
                    },
                }
            };
            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }
            var actual = resolver.Resolve(
                source,
                null,
                new decimal(0.0),
                null);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void ResolveCorrectlyRoundsTheVendorCompensationRate()
        {
            const string expected = "5.0000";
         
            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
                {
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(5.0),
                        VendorComp = new decimal(5.0)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(5.0),
                        VendorComp = new decimal(5.0)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(5.0),
                        VendorComp = new decimal(5.0)
                    },
                }
            };
            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var value = resolver.Resolve(
                source,
                null,
                new decimal(0.0),
                null);

            var actual = 
                value.ToString(CultureInfo.InvariantCulture);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
