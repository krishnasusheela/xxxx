﻿using System;
using System.Collections.Generic;
using ParishTaxTable.Api.Infrastructure.Mappings;
using ParishTaxTable.Api.Infrastructure.Models;
using Xunit;
using AutoFixture;

namespace ParishTaxTable.Api.Tests.Mappings
{
    public class DomicileParishCollectionRateResolverTests : IDisposable
    {
        private DomicileParishCollectionRateResolver resolver;
        private Fixture fixture;
     
        public DomicileParishCollectionRateResolverTests()
        {
            resolver = new DomicileParishCollectionRateResolver();
            fixture = new Fixture();
        }

        public void Dispose()
        {
            resolver = null;
        }

        [Fact]
        public void ResolveReturnsSumOfDistributionRates()
        {
            var expected = new decimal(5.0);

            var parishJurisdiction = fixture.Build<JurisdictionDto>()
                .With(p => p.JurisdictionTypeId, 1)
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var dispersion = fixture.Build<DispersionDto>()
                .Without(p => p.Domicile)
                .With(p => p.Jurisdiction, parishJurisdiction)
                .With(p => p.DistributionRate,expected)
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-5))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(5))
                .With(p => p.IsInvalidDispersion, false)
                .Create();

            var source = fixture.Build<DomicileDto>()
                .With(p => p.Dispersions, new List<DispersionDto> { dispersion })
                .With(p => p.SearchDate, DateTimeOffset.Now)
                .Without(p => p.Parish)
                .Create();

            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = resolver.Resolve(
                source,
                null,
                new decimal(0.0),
                null);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
