﻿using System;
using System.Collections.Generic;
using ParishTaxTable.Api.Infrastructure.Mappings;
using ParishTaxTable.Api.Infrastructure.Models;
using Xunit;

namespace ParishTaxTable.Api.Tests.Mappings
{
    public class DomicileCollectionRateResolverTests
        : IDisposable
    {
        private DomicileCollectionRateResolver resolver;

        public DomicileCollectionRateResolverTests()
        {
            resolver = new DomicileCollectionRateResolver();
        }

        public void Dispose()
        {
            resolver = null;
        }

        [Fact]
        public void ResolveReturnsSumOfDistributionRates()
        {
            var expected = new decimal(30.0);
            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
                {
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(10.0)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(10.0)
                    },
                    new DispersionDto
                    {
                        EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                        TermDate = null,
                        DistributionRate = new decimal(10.0)
                    },
                }
            };
            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = resolver.Resolve(
                source,
                null,
                new decimal(0.0), 
                null);

            Assert.Equal(
                expected, 
                actual);
        }
    }
}
