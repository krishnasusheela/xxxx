﻿using System;
using System.Collections.Generic;
using System.Linq;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Models;
using Xunit;

namespace ParishTaxTable.Api.Tests.Helpers
{
    public class ContactDtoHelpersTests
    {
        [Fact]
        public void GetCurrentContactsReturnsNothingWhenAllContactsHaveAFutureCreateDate()
        {
            var contacts = new List<ContactDto>
            {
                new ContactDto
                {
                    CreateDate = DateTimeOffset.Now.AddDays(1)
                }
            };

            var currentContacts = contacts.AsQueryable().GetCurrentContactDtos();

            Assert.Empty(currentContacts);
        }

        [Fact]
        public void GetCurrentContactsReturnsNothingWhenAllContactsHaveAPastRetireDate()
        {
            var contacts = new List<ContactDto>
            {
                new ContactDto
                {
                    CreateDate = DateTimeOffset.Now.AddDays(-10),
                    RetireDate = DateTimeOffset.Now.AddDays(-5)
                }
            };

            var currentContacts = contacts.AsQueryable().GetCurrentContactDtos();

            Assert.Empty(currentContacts);
        }

        [Fact]
        public void GetCurrentContactsReturnsResultsWhenCreateDateIsInThePastAndRetireDateIsNull()
        {
            var contacts = new List<ContactDto>
            {
                new ContactDto
                {
                    CreateDate = DateTimeOffset.Now.AddDays(-10),
                    RetireDate = null
                }
            };

            var currentContacts = contacts.AsQueryable().GetCurrentContactDtos();

            Assert.Equal(
                contacts,
                currentContacts);
        }

        [Fact]
        public void GetCurrentContactsReturnsResultsWhenCreateDateIsInThePastAndRetireDateIsInTheFuture()
        {
            var contacts = new List<ContactDto>
            {
                new ContactDto
                {
                    CreateDate = DateTimeOffset.Now.AddDays(-10),
                    RetireDate = DateTimeOffset.Now.AddDays(10)
                }
            };

            var currentContacts = contacts.AsQueryable().GetCurrentContactDtos();

            Assert.Equal(
                contacts,
                currentContacts);
        }
    }
}
