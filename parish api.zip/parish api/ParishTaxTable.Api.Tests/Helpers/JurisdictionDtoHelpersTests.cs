﻿using System;
using System.Collections.Generic;
using System.Linq;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Models;
using Xunit;

namespace ParishTaxTable.Api.Tests.Helpers
{
    public class JurisdictionDtoHelpersTests
    {
        [Fact]
        public void GetCurrentJurisdictionsReturnsNothingWhenAllJurisdictionsHaveAFutureCreateDate()
        {
            var jurisdictions = new List<JurisdictionDto>
            {
                new JurisdictionDto
                {
                    CreateDate = DateTimeOffset.Now.AddDays(1)
                }
            };

            var currentJurisdictions = jurisdictions.AsQueryable().GetCurrentJurisdictionDtos();

            Assert.Empty(currentJurisdictions);
        }

        [Fact]
        public void GetCurrentJurisdictionsReturnsNothingWhenAllJurisdictionsHaveAPastRetireDate()
        {
            var jurisdictions = new List<JurisdictionDto>
            {
                new JurisdictionDto
                {
                    CreateDate = DateTimeOffset.Now.AddDays(-10),
                    RetireDate = DateTimeOffset.Now.AddDays(-5)
                }
            };

            var currentJurisdictions = jurisdictions.AsQueryable().GetCurrentJurisdictionDtos();

            Assert.Empty(currentJurisdictions);
        }

        [Fact]
        public void GetCurrentJurisdictionsReturnsResultsWhenCreateDateIsInThePastAndRetireDateIsNull()
        {
            var jurisdictions = new List<JurisdictionDto>
            {
                new JurisdictionDto
                {
                    CreateDate = DateTimeOffset.Now.AddDays(-10),
                    RetireDate = null
                }
            };

            var currentJurisdictions = jurisdictions.AsQueryable().GetCurrentJurisdictionDtos();

            Assert.Equal(
                jurisdictions,
                currentJurisdictions);
        }

        [Fact]
        public void GetCurrentJurisdictionsReturnsResultsWhenCreateDateIsInThePastAndRetireDateIsInTheFuture()
        {
            var jurisdictions = new List<JurisdictionDto>
            {
                new JurisdictionDto
                {
                    CreateDate = DateTimeOffset.Now.AddDays(-10),
                    RetireDate = DateTimeOffset.Now.AddDays(10)
                }
            };

            var currentJurisdictions = jurisdictions.AsQueryable().GetCurrentJurisdictionDtos();

            Assert.Equal(
                jurisdictions,
                currentJurisdictions);
        }
    }
}
