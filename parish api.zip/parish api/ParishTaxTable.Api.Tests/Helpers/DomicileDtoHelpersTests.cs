﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Models;
using Xunit;

namespace ParishTaxTable.Api.Tests.Helpers
{
    public class DomicileDtoHelpersTests
        : IDisposable
    {

        private Fixture fixture;

        public DomicileDtoHelpersTests()
        {
            fixture = new Fixture();
        }

        public void Dispose()
        {
            fixture = null;
        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(3)]
        [InlineData(4)]
        [InlineData(5)]
        [InlineData(6)]
        public void GetParishCodeAndDomicileReturnsExpectedResult(int length)
        {

            var domicileCodeString = fixture.Create<string>().Substring(0,length);

            (var parishCode, var domicileCode) = domicileCodeString.GetParishCodeAndDomicileCode();

            Assert.Equal(domicileCodeString, parishCode+domicileCode);
        }

        [Fact]
        public void IsEffectiveDomicileReturnsFalseWhenEffectiveDateIsGreaterThanPassedDate()
        {
            var domicile = fixture.Build<DomicileDto>()
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .With(p => p.EffectiveDate, DateTimeOffset.Now)
                .Create();

            var date = DateTimeOffset.Now.AddDays(-10);

            Assert.False(
                domicile.IsEffectiveDomicile(
                    date));
        }

        [Fact]
        public void IsEffectiveDomicileReturnsFalseWhenTermDateIsBeforeDate()
        {
            var domicile = fixture.Build<DomicileDto>()
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-5))
                .Create();

            var date = DateTimeOffset.Now;

            Assert.False(
                domicile.IsEffectiveDomicile(
                    date));
        }

        [Fact]
        public void IsEffectiveDomicileReturnsTrueWhenDateIsBetweenEffectiveAndTerm()
        {
            var domicile = fixture.Build<DomicileDto>()
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(5))
                .Create();

            var date = DateTimeOffset.Now;

            Assert.True(
                domicile.IsEffectiveDomicile(
                    date));
        }

        [Fact]
        public void IsEffectiveDomicileReturnsTrueWhenDateIsAfterEffectiveDateAndTermDateIsNull()
        {
            var domicile = fixture.Build<DomicileDto>()
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, null)
                .Create();

            var date = DateTimeOffset.Now;

            Assert.True(
                domicile.IsEffectiveDomicile(
                    date));
        }
    }
}
