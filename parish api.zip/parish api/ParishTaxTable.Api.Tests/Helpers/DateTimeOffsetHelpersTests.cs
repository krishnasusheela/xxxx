﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoFixture;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Models;
using Xunit;

namespace ParishTaxTable.Api.Tests.Helpers
{
    public class DateTimeOffsetHelpersTests
    {

        private Fixture fixture;

        public DateTimeOffsetHelpersTests()
        {
            fixture = new Fixture();
        }
        [Fact]
        public void NullableEndOfDayCorrectlyReturnsOneTickAwayFromTheEndOfTheDate()
        {
            var dateToCheck = fixture.Create<DateTimeOffset?>();

            var dateToCheckAtEndOfDay = dateToCheck.EndOfDay();
            
            Assert.Equal(dateToCheck?.Date.AddTicks(-1).AddDays(1), dateToCheckAtEndOfDay);
        }

        [Fact]
        public void EndOfDayCorrectlyReturnsOneTickAwayFromTheEndOfTheDate()
        {
            var dateToCheck = fixture.Create<DateTimeOffset>();

            var dateToCheckAtEndOfDay = dateToCheck.EndOfDay();

            Assert.Equal(dateToCheck.Date.AddTicks(-1).AddDays(1), dateToCheckAtEndOfDay);
        }
    }
}
