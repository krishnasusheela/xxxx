﻿using System;
using System.Collections.Generic;
using AutoFixture;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Models;
using Xunit;

namespace ParishTaxTable.Api.Tests.Helpers
{
    public class DispersionDtoHelpersTests
        : IDisposable
    {
        private Fixture fixture;

        public DispersionDtoHelpersTests()
        {
            fixture = new Fixture();
        }

        public void Dispose()
        {
            fixture = null;
        }

        [Fact]
        public void GetCurrentDispersionsReturnsNothingWhenAllDispersionsHaveAFutureEffectiveDate()
        {
            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
              {
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(1),
                    IsInvalidDispersion = false
                }
              }
            };
            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var currentDispersions = source.Dispersions.GetCurrentDispersionDtos();

            Assert.Empty(currentDispersions);
        }

        [Fact]
        public void GetCurrentDispersionsReturnsNothingWhenAllDispersionsHaveAPastTermDate()
        {
            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
              {
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = DateTimeOffset.Now.AddDays(-5),
                    IsInvalidDispersion = false
                }
              }
            };
            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }
            var currentDispersions = source.Dispersions.GetCurrentDispersionDtos();

            Assert.Empty(currentDispersions);
        }

        [Fact]
        public void GetCurrentDispersionsReturnsResultsWhenEffectiveDateIsInThePastAndTermDateIsNull()
        {
            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
             {
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = null,
                    IsInvalidDispersion = false
                }
             }
            };

            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var currentDispersions =source.Dispersions.GetCurrentDispersionDtos();

            Assert.Equal(
               source.Dispersions,
                currentDispersions);
        }

        [Fact]
        public void GetCurrentDispersionsReturnsResultsWhenEffectiveDateIsInThePastAndTermDateIsInTheFuture()
        {
            var source = new DomicileDto
            { 
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
              {
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = DateTimeOffset.Now.AddDays(10),
                    IsInvalidDispersion = false
                }
              }
            };
            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }
            var currentDispersions = source.Dispersions.GetCurrentDispersionDtos();

            Assert.Equal(
                source.Dispersions,
                currentDispersions);
        }

        [Fact]
        public void GetCurrentDispersionsDoesNotReturnResultsWhenDispersionsAreInvalid()
        {
            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
              {
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = null,
                    IsInvalidDispersion = true
                }
              }
            };
            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }
            var currentDispersions = source.Dispersions.GetCurrentDispersionDtos();

            Assert.Empty(currentDispersions);
        }

        [Fact]
        public void IsEffectiveDispersionReturnsFalseWhenEffectiveDateIsGreaterThanPassedDate()
        {
            var dispersion = fixture.Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .With(p => p.EffectiveDate, DateTimeOffset.Now)
                .Create();

            var date = DateTimeOffset.Now.AddDays(-10);

            Assert.False(
                dispersion.IsEffectiveDispersion(
                    date));
        }

        [Fact]
        public void IsEffectiveDispersionReturnsFalseWhenTermDateIsBeforeDate()
        {
            var dispersion = fixture.Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-5))
                .Create();

            var date = DateTimeOffset.Now;

            Assert.False(
                dispersion.IsEffectiveDispersion(
                    date));
        }

        [Fact]
        public void IsEffectiveDispersionReturnsTrueWhenDateIsBetweenEffectiveAndTerm()
        {
            var dispersion = fixture.Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(5))
                .Create();

            var date = DateTimeOffset.Now;

            Assert.True(
                dispersion.IsEffectiveDispersion(
                    date));
        }

        [Fact]
        public void IsEffectiveDispersionReturnsTrueWhenDateIsAfterEffectiveDateAndTermDateIsNull()
        {
            var dispersion = fixture.Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, null)
                .Create();

            var date = DateTimeOffset.Now;

            Assert.True(
                dispersion.IsEffectiveDispersion(
                    date));
        }

        [Fact]
        public void GetInvalidDispersionsDoesNotReturnResultsWhenDispersionsAreValid()
        {
            var dispersions = new List<DispersionDto>
            {
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = null,
                    IsInvalidDispersion = false
                },
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(10),
                    TermDate = null,
                    IsInvalidDispersion = false
                }
            };

            var invalidDispersions = dispersions.GetInvalidDispersionDtos();

            Assert.Empty(invalidDispersions);
        }

        [Fact]
        public void GetInvalidDispersionsReturnsResultsWhenDispersionsAreInvalid()
        {
            var dispersions = new List<DispersionDto>
            {
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = null,
                    IsInvalidDispersion = true
                },
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(10),
                    TermDate = null,
                    IsInvalidDispersion = true
                }
            };

            var invalidDispersions = dispersions.GetInvalidDispersionDtos();

            Assert.Equal(
                dispersions,
                invalidDispersions);
        }

        [Fact]
        public void GetCollectionRateReturnsZeroWhenCurrentDispersionsIsEmpty()
        {
            var expected = new decimal(0.0);
            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>

              {
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(1)
                }
              }
            };
            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = source.Dispersions.GetCollectionRate();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void GetCollectionRateReturnsSumOfDistributionRates()
        {
            var expected = new decimal(30.0);

            var source = new DomicileDto
            {
                SearchDate = DateTimeOffset.Now.Date,
                Dispersions = new List<DispersionDto>
             {
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10) ,
                    TermDate = null,

                    DistributionRate = new decimal(10.0)
                },
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = null,
                    DistributionRate = new decimal(10.0)
                },
                new DispersionDto
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = null,
                    DistributionRate = new decimal(10.0)
                },
              }
            };
            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }
            var actual = source.Dispersions
                .GetCollectionRate();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void GetVendorCompensationRateReturnsZeroWhenVendorCompIsZero()
        {
            var expected = new decimal(0.0);
            var dispersion = new DispersionDto
            {
                VendorComp = new decimal(0.0),
                DistributionRate = new decimal(1.0)
            };
            var collectionRate = new decimal(1.0);

            var actual = dispersion
                .GetVendorCompensationRate(collectionRate);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void GetVendorCompensationRateReturnsZeroWhenDistributionRateIsZero()
        {
            var expected = new decimal(0.0);
            var dispersion = new DispersionDto
            {
                VendorComp = new decimal(1.0),
                DistributionRate = new decimal(0.0)
            };
            var collectionRate = new decimal(1.0);

            var actual = dispersion
                .GetVendorCompensationRate(collectionRate);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void GetVendorCompensationRateReturnsZeroWhenCollectionRateIsZero()
        {
            var expected = new decimal(0.0);
            var dispersion = new DispersionDto
            {
                VendorComp = new decimal(1.0),
                DistributionRate = new decimal(1.0)
            };
            var collectionRate = new decimal(0.0);

            var actual = dispersion
                .GetVendorCompensationRate(collectionRate);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void GetVendorCompensationRateReturnsCorrectly()
        {
            var expected = new decimal(2.5);
            var dispersion = new DispersionDto
            {
                VendorComp = new decimal(5.0),
                DistributionRate = new decimal(5.0)
            };
            var collectionRate = new decimal(10.0);

            var actual = dispersion
                .GetVendorCompensationRate(collectionRate);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void GetParishCollectionRateReturnsZeroWhenCurrentDispersionsIsEmpty()
        {
            var expected = new decimal(0.0);
            var parishJurisdictionTypeId = 1;
            var municipalityJurisdictionTypeId = 2;

            var parishJurisdiction = fixture.Build<JurisdictionDto>()
                .With(p => p.JurisdictionTypeId, parishJurisdictionTypeId)
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var municipalityJurisdiction = fixture.Build<JurisdictionDto>()
              .With(p => p.JurisdictionTypeId, municipalityJurisdictionTypeId)
              .Without(p => p.JurisdictionType)
              .Without(p => p.Parish)
              .Create();

            var source = fixture.Build<DomicileDto>()
                .With(p => p.Dispersions, new List<DispersionDto>())
                .Without(p => p.Parish)
                .Create();

            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = source.Dispersions.GetParishCollectionRate();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void GetParishCollectionRateReturnsSumOfParishDistributionRates()
        {
            var expected = new decimal(5.0);
            var parishJurisdictionTypeId = 1;
            var municipalityJurisdictionTypeId = 2;

            var parishJurisdiction = fixture.Build<JurisdictionDto>()
                .With(p => p.JurisdictionTypeId, parishJurisdictionTypeId)
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var municipalityJurisdiction = fixture.Build<JurisdictionDto>()
                .With(p => p.JurisdictionTypeId, municipalityJurisdictionTypeId)
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var parishDispersion = fixture.Build<DispersionDto>()
                .Without(p => p.Domicile)
                .With(p => p.Jurisdiction, parishJurisdiction)
                .With(p => p.DistributionRate, expected)
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-5))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(5))
                .With(p => p.IsInvalidDispersion, false)
                .Create();

            var municipalDispersion = fixture.Build<DispersionDto>()
                .Without(p => p.Domicile)
                .With(p => p.Jurisdiction, municipalityJurisdiction)
                .With(p => p.DistributionRate, expected)
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-5))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(5))
                .With(p => p.IsInvalidDispersion, false)
                .Create();

            var source = fixture.Build<DomicileDto>()
                .With(p => p.Dispersions, new List<DispersionDto> { parishDispersion, municipalDispersion })
                .With(p => p.SearchDate, DateTimeOffset.Now)
                .Without(p => p.Parish)
                .Create();

            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = source.Dispersions
                .GetParishCollectionRate();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void GetMunicipalityCollectionRateReturnsZeroWhenCurrentDispersionsIsEmpty()
        {
            var expected = new decimal(0.0);
            var parishJurisdictionTypeId = 1;
            var municipalityJurisdictionTypeId = 2;

            var parishJurisdiction = fixture.Build<JurisdictionDto>()
              .With(p => p.JurisdictionTypeId, parishJurisdictionTypeId)
              .Without(p => p.JurisdictionType)
              .Without(p => p.Parish)
              .Create();

            var municipalityJurisdiction = fixture.Build<JurisdictionDto>()
                .With(p => p.JurisdictionTypeId, municipalityJurisdictionTypeId)
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var source = fixture.Build<DomicileDto>()
                .With(p => p.Dispersions, new List<DispersionDto>())
                .Without(p => p.Parish)
                .Create();

            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = source.Dispersions.GetMunicipalityCollectionRate();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public void GetMunicipalityCollectionRateReturnsSumOfMunicipalityDistributionRates()
        {
            var expected = new decimal(5.0);
            var parishJurisdictionTypeId = 1;
            var municipalityJurisdictionTypeId = 2;

            var parishJurisdiction = fixture.Build<JurisdictionDto>()
                .With(p => p.JurisdictionTypeId, parishJurisdictionTypeId)
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var municipalityJurisdiction = fixture.Build<JurisdictionDto>()
                .With(p => p.JurisdictionTypeId, municipalityJurisdictionTypeId)
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var parishDispersion = fixture.Build<DispersionDto>()
               .Without(p => p.Domicile)
               .With(p => p.Jurisdiction, parishJurisdiction)
               .With(p => p.DistributionRate, expected)
               .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-5))
               .With(p => p.TermDate, DateTimeOffset.Now.AddDays(5))
               .With(p => p.IsInvalidDispersion, false)
               .Create();

            var municipalityDispersion = fixture.Build<DispersionDto>()
                .Without(p => p.Domicile)
                .With(p => p.Jurisdiction, municipalityJurisdiction)
                .With(p => p.DistributionRate, expected)
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-5))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(5))
                .With(p => p.IsInvalidDispersion, false)
                .Create();

            var source = fixture.Build<DomicileDto>()
                .With(p => p.Dispersions, new List<DispersionDto> { parishDispersion, municipalityDispersion })
                .With(p => p.SearchDate, DateTimeOffset.Now)
                .Without(p => p.Parish)
                .Create();

            foreach (var item in source.Dispersions)
            {
                item.Domicile = source;
            }

            var actual = source.Dispersions
                .GetMunicipalityCollectionRate();

            Assert.Equal(
                expected,
                actual);
        }
    }
}
