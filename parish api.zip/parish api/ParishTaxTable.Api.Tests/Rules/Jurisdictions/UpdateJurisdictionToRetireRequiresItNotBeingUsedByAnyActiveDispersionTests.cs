﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Jurisdictions;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Jurisdictions
{
    public class UpdateJurisdictionToRetireRequiresItNotBeingUsedByAnyActiveDispersionsTests
        : IDisposable
    {
        private Fixture fixture;
        private UpdateJurisdictionToRetireRequiresItNotBeingUsedByAnyActiveDispersions rule;
        private Mock<IDispersionRepository> repositoryMock;
        private const string ExpectedExceptionMessage =
            "This jurisdiction has at least one affiliated in-use dispersion. Please invalidate this dispersion, or wait for its expiration, before retiring this jurisdiction.";


        public UpdateJurisdictionToRetireRequiresItNotBeingUsedByAnyActiveDispersionsTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IDispersionRepository>();
            rule = new UpdateJurisdictionToRetireRequiresItNotBeingUsedByAnyActiveDispersions(repositoryMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
            repositoryMock = null;
        }
        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }
        [Fact]
        public void RuleDoesNotThrowExceptionWhenJurisdictionHasNoDispersion()
        {
            
            var jurisdictionToUpdate = fixture
                .Build<JurisdictionDto>()
                .Without(x => x.Parish)
                .Without(x => x.JurisdictionType)
                .Create();

            var jurisdictionWithUpdates = fixture
             .Build<Jurisdiction>()
             .Without(x => x.JurisdictionType)
             .Create();
            
            var exception = Record.Exception(() =>
                rule.Test(jurisdictionToUpdate,
                    jurisdictionWithUpdates));

            Assert.Null(exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenDispersionAreExpired()
        {
            var dispersion = fixture
               .Build<DispersionDto>()
               .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-5))
               .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-2))
               .Without(p => p.Domicile)
               .Without(p => p.Jurisdiction)
               .Create();

            var jurisdictionToUpdate = fixture
                .Build<JurisdictionDto>()
                .Without(x => x.Parish)
                .Without(x => x.JurisdictionType)
                .Create();

            var jurisdictionWithUpdates = fixture
              .Build<Jurisdiction>()           
              .Without(x => x.JurisdictionType)
              .Create();

            repositoryMock
                .Setup(m => m.GetByJurisdictionId(jurisdictionToUpdate.Id))
                .ReturnsAsync(new List<DispersionDto> { dispersion });

            var exception = Record.Exception(() =>
                rule.Test(jurisdictionToUpdate,
                    jurisdictionWithUpdates));

            Assert.Null(exception);
        }

        [Fact]
        public void RuleThrowExceptionWhenDispersionAreNotExpired()
        {
            var dispersion = fixture
               .Build<DispersionDto>()
               .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-5))
               .Without(p => p.TermDate)
               .Without(p => p.Domicile)
               .Without(p => p.Jurisdiction)
               .Create();

            var jurisdictionToUpdate = fixture
                .Build<JurisdictionDto>()
                .Without(x => x.RetireDate)
                .Without(x => x.Parish)
                .Without(x => x.JurisdictionType)
                .Create();

            var jurisdictionWithUpdates = fixture
             .Build<Jurisdiction>()
             .Without(x => x.JurisdictionType)
             .Create();

            repositoryMock
                .Setup(m => m.GetByJurisdictionId(jurisdictionToUpdate.Id))
                .ReturnsAsync(new List<DispersionDto> { dispersion });

            var exception = Record.Exception(() =>
                rule.Test(
                    jurisdictionToUpdate,
                     jurisdictionWithUpdates));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
