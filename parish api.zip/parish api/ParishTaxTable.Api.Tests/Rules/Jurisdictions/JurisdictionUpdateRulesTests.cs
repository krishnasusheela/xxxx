﻿using System;
using System.Collections.Generic;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Jurisdictions;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Jurisdictions
{
    public class JurisdictionUpdateRulesTests
        :IDisposable
    {
        private Fixture fixture;
        private Mock<IUpdateJurisdictionRule> rule1;
        private Mock<IUpdateJurisdictionRule> rule2;
        private JurisdictionUpdateRules rules;

        public JurisdictionUpdateRulesTests()
        {
            fixture = new Fixture();
            rule1 = new Mock<IUpdateJurisdictionRule>();
            rule2 = new Mock<IUpdateJurisdictionRule>();

            rules = new JurisdictionUpdateRules(new List<IUpdateJurisdictionRule>
            {
                rule1.Object,
                rule2.Object
            });
        }

        public void Dispose()
        {
            fixture = null;
            rule1 = null;
            rule2 = null;
            rules = null;
        }

        [Fact]
        public void RulesCreateSuccessfully()
        {
            Assert.NotNull(
                rules);
        }

        [Fact]
        public void RulesThrowsExceptionWhenARuleThrowsAnException()
        {
            var jurisdictionWithUpdates = fixture.Create<Jurisdiction>();

            var jurisdictionToUpdate = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            rule2
                .Setup(m => m.Test(
                    jurisdictionToUpdate,
                    jurisdictionWithUpdates))
                .Throws<TestException>();

            Assert.Throws<TestException>(() =>
                rules.Test(
                    jurisdictionToUpdate,
                    jurisdictionWithUpdates));
        }

        [Fact]
        public void RulesCallsAllSubRules()
        {
            var jurisdictionWithUpdates = fixture.Create<Jurisdiction>();

            var jurisdictionToUpdate = fixture
                .Build<JurisdictionDto>()
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            rule1
                .Setup(m => m.Test(
                      jurisdictionToUpdate,
                    jurisdictionWithUpdates))
                .Verifiable();

            rule2
               .Setup(m => m.Test(
                     jurisdictionToUpdate,
                    jurisdictionWithUpdates))
               .Verifiable();

            rules.Test(
                  jurisdictionToUpdate,
                  jurisdictionWithUpdates);

            rule1
                .Verify(m => m.Test(
                    jurisdictionToUpdate,
                    jurisdictionWithUpdates));
            rule2
               .Verify(m => m.Test(
                    jurisdictionToUpdate,
                    jurisdictionWithUpdates));
        }
    }
}
