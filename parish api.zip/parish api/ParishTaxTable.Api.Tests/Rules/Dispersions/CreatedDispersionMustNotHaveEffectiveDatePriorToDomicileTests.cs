﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Dispersions;
using Xunit;
namespace ParishTaxTable.Api.Tests.Rules.Dispersions
{
    public class CreatedDispersionMustNotHaveEffectiveDatePriorToDomicileTests
        : IDisposable
    {
        private Fixture fixture;
        private CreatedDispersionMustNotHaveEffectiveDatePriorToDomicile rule;
        private Mock<IDomicileRepository> repositoryMock;

        private const string ExpectedExceptionMessage = 
            "Dispersion cannot have an effective date prior to the effective date of the Domicile that it is in.";

        public CreatedDispersionMustNotHaveEffectiveDatePriorToDomicileTests()
        {
            repositoryMock = new Mock<IDomicileRepository>();

            fixture = new Fixture();
            rule = new CreatedDispersionMustNotHaveEffectiveDatePriorToDomicile(repositoryMock.Object);

        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
            repositoryMock = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenEffectiveDateIsNotPriorToDomicile()
        {
            var domicileToCreate = fixture
                .Build<DomicileDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-3).Date)
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .Create();

            var dispersionToCreate = fixture
               .Build<DispersionDto>()
               .With(p => p.EffectiveDate, DateTimeOffset.Now.Date)
               .With(p => p.Domicile, domicileToCreate)
               .With(p => p.DomicileId, domicileToCreate.Id)
               .Without(p => p.Jurisdiction)
               .Create();

            repositoryMock
                .Setup(m => m.GetById(dispersionToCreate.DomicileId))
                .ReturnsAsync(domicileToCreate);

            var exception = Record.Exception(() =>
               rule.Test(
                   dispersionToCreate));

            Assert.Null(exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenEffectiveDateisEqualToDomicile()
        {
            var domicileToCreate = fixture
                .Build<DomicileDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.Date)
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .Create();

            var dispersionToCreate = fixture
               .Build<DispersionDto>()
               .With(p => p.EffectiveDate, DateTimeOffset.Now.Date)
               .With(p => p.Domicile, domicileToCreate)
               .With(p => p.DomicileId, domicileToCreate.Id)
               .Without(p => p.Jurisdiction)
               .Create();

            repositoryMock
                .Setup(m => m.GetById(dispersionToCreate.DomicileId))
                .ReturnsAsync(domicileToCreate);

            var exception = Record.Exception(() =>
               rule.Test(
                   dispersionToCreate));

            Assert.Null(exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenEffectiveDateIsPriorToDomicile()
        {
            var domicileToCreate = fixture
                .Build<DomicileDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(3).Date)
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .Create();

            var dispersionToCreate = fixture
               .Build<DispersionDto>()
               .With(p => p.EffectiveDate, DateTimeOffset.Now.Date)
               .With(p => p.Domicile, domicileToCreate)
               .With(p => p.DomicileId, domicileToCreate.Id)
               .Without(p => p.Jurisdiction)
               .Create();

            repositoryMock
                .Setup(m => m.GetById(dispersionToCreate.DomicileId))
                .ReturnsAsync(domicileToCreate);

            var exception = Record.Exception(() =>
               rule.Test(
                   dispersionToCreate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                    exception);
            
        }
    }
}
