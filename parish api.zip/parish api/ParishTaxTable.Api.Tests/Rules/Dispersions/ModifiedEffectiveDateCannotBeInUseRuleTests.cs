﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Dispersions;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Dispersions
{
    public class ModifiedEffectiveDateCannotBeInUseRuleTests
        : IDisposable
    {
        private Fixture fixture;
        private ModifiedEffectiveDateCannotBeInUseRule rule;

        private const string ExpectedExceptionMessage =
            "Effective Date cannot be edited to a current or previous date.";

        public ModifiedEffectiveDateCannotBeInUseRuleTests()
        {
            fixture = new Fixture();
            rule = new ModifiedEffectiveDateCannotBeInUseRule();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenEffectiveDatesMatch()
        {
            var effectiveDate = DateTimeOffset.Now;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, effectiveDate)
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, effectiveDate)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenUpdatedDispersionHasFutureEffectiveDate()
        {
            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(4))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenOriginalDispersionHasACurrentEffectiveDate()
        {
            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-4))
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenUpdatedDispersionHasCurrentEffectiveDateAndOriginalDispersionHasFutureEffectiveDate()
        {
            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(4))
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
