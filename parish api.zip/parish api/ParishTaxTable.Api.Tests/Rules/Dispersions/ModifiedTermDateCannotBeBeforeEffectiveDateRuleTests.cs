﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoFixture;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Dispersions;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Dispersions
{
    public class ModifiedTermDateCannotBeBeforeEffectiveDateRuleTests
        : IDisposable
    {
        private Fixture fixture;
        private ModifiedTermDateCannotBeBeforeEffectiveDateRule rule;

        private const string ExpectedExceptionMessage =
            "Dispersions cannot have an expiration date before the effective date.";

        public ModifiedTermDateCannotBeBeforeEffectiveDateRuleTests()
        {
            fixture = new Fixture();
            rule = new ModifiedTermDateCannotBeBeforeEffectiveDateRule();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsNull()
        {
            var effectiveDate = DateTimeOffset.Now;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, effectiveDate)
                .Without(p => p.TermDate)
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, effectiveDate)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsAfterEffectiveDate()
        {
            var effectiveDate = DateTimeOffset.Now;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.TermDate, effectiveDate.AddDays(1))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, effectiveDate)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenTermDateIsBeforeEffectiveDate()
        {
            var effectiveDate = DateTimeOffset.Now;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.TermDate, effectiveDate.AddDays(-1))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, effectiveDate)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.NotNull(
                exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenTermDateIsEqualToEffectiveDate()
        {
            var effectiveDate = DateTimeOffset.Now;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.TermDate, effectiveDate)
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, effectiveDate)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.NotNull(
                exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
