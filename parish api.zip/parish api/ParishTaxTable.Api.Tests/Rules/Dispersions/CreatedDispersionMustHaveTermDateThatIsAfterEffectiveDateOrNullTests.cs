﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Dispersions;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Dispersions
{
    public class CreatedDispersionMustHaveTermDateThatIsAfterEffectiveDateOrNullTests
        : IDisposable
    {
        private Fixture fixture;
        private CreatedDispersionMustHaveTermDateThatIsAfterEffectiveDateOrNull rule;

        private const string ExpectedExceptionMessage =
            "New dispersions cannot have an expiration date before the effective date.";

        public CreatedDispersionMustHaveTermDateThatIsAfterEffectiveDateOrNullTests()
        {
            fixture = new Fixture();
            rule = new CreatedDispersionMustHaveTermDateThatIsAfterEffectiveDateOrNull();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsNull()
        {
            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, null)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsAfterEffectiveDate()
        {
            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(10))
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenTermDateIsEqualToEffectiveDate()
        {
            var currentDate = DateTimeOffset.Now.AddDays(1);

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, currentDate)
                .With(p => p.TermDate, currentDate)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionToUpdate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenTermDateIsBeforeEffectiveDate()
        {
            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-11))
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionToUpdate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
