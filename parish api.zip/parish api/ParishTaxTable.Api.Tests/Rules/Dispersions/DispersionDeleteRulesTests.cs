﻿using System;
using System.Collections.Generic;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Dispersions;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Dispersions
{
    public class DispersionDeleteRulesTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<IDeleteDispersionRule> rule1;
        private Mock<IDeleteDispersionRule> rule2;
        private DispersionDeleteRules rules;

        public DispersionDeleteRulesTests()
        {
            fixture = new Fixture();

            rule1 = new Mock<IDeleteDispersionRule>();
            rule2 = new Mock<IDeleteDispersionRule>();

            rules = new DispersionDeleteRules(
                new List<IDeleteDispersionRule>
                {
                    rule1.Object,
                    rule2.Object
                });
        }

        public void Dispose()
        {
            fixture = null;
            rule1 = null;
            rule2 = null;
            rules = null;
        }

        [Fact]
        public void RulesCreateSuccessfully()
        {
            Assert.NotNull(
                rules);
        }

        [Fact]
        public void RulesThrowsExceptionWhenARuleThrowsAnException()
        {

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            rule2
                .Setup(m => m.Test(
                    dispersionToUpdate))
                .Throws<TestException>();

            Assert.Throws<TestException>(() =>
                rules.Test(
                    dispersionToUpdate));
        }

        [Fact]
        public void RulesCallsAllSubRules()
        {

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            rule1
                .Setup(m => m.Test(
                    dispersionToUpdate))
                .Verifiable();

            rule2
                .Setup(m => m.Test(
                    dispersionToUpdate))
                .Verifiable();

            rules.Test(
                dispersionToUpdate);

            rule1
                .Verify(m => m.Test(
                    dispersionToUpdate));

            rule2
                .Verify(m => m.Test(
                    dispersionToUpdate));
        }
    }
}
