﻿using System;
using System.Collections.Generic;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Dispersions;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Dispersions
{
    public class DispersionUpdateRulesTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<IUpdateDispersionRule> rule1;
        private Mock<IUpdateDispersionRule> rule2;
        private DispersionUpdateRules rules;

        public DispersionUpdateRulesTests()
        {
            fixture = new Fixture();

            rule1 = new Mock<IUpdateDispersionRule>();
            rule2 = new Mock<IUpdateDispersionRule>();

            rules = new DispersionUpdateRules(
                new List<IUpdateDispersionRule>
                {
                    rule1.Object,
                    rule2.Object
                });
        }

        public void Dispose()
        {
            fixture = null;
            rule1 = null;
            rule2 = null;
            rules = null;
        }

        [Fact]
        public void RulesCreateSuccessfully()
        {
            Assert.NotNull(
                rules);
        }

        [Fact]
        public void RulesThrowsExceptionWhenARuleThrowsAnException()
        {
            var dispersionWithUpdates = fixture
                .Create<Dispersion>();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            rule2
                .Setup(m => m.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate))
                .Throws<TestException>();

            Assert.Throws<TestException>(() =>
                rules.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));
        }

        [Fact]
        public void RulesCallsAllSubRules()
        {
            var dispersionWithUpdates = fixture
                .Create<Dispersion>();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            rule1
                .Setup(m => m.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate))
                .Verifiable();

            rule2
                .Setup(m => m.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate))
                .Verifiable();

            rules.Test(
                dispersionWithUpdates,
                dispersionToUpdate);

            rule1
                .Verify(m => m.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            rule2
                .Verify(m => m.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));
        }
    }
}
