﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Dispersions;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Dispersions
{
    public class CreatedDispersionsMustHaveFutureEffectiveDateTests
        : IDisposable
    {
        private Fixture fixture;
        private CreatedDispersionsMustHaveFutureEffectiveDate rule;

        private const string ExpectedExceptionMessage =
            "New dispersions cannot have an effective date in the past.";

        public CreatedDispersionsMustHaveFutureEffectiveDateTests()
        {
            fixture = new Fixture();
            rule = new CreatedDispersionsMustHaveFutureEffectiveDate();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenEffectiveDateIsInFuture()
        {
            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(10))
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenEffectiveDateIsInThePast()
        {
            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionToUpdate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenEffectiveDateIsNow()
        {
            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionToUpdate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
