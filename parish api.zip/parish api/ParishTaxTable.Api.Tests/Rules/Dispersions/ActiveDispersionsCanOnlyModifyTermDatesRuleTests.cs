﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Dispersions;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Dispersions
{
    public class ActiveDispersionsCanOnlyModifyTermDatesRuleTests
        : IDisposable
    {  
        private Fixture fixture;
        private ActiveDispersionsCanOnlyModifyTermDatesRule rule;
        private const string ExpectedExceptionMessage =
            "Only the expiration date can be modified on In-Use Dispersions.";

        public ActiveDispersionsCanOnlyModifyTermDatesRuleTests()
        {
            fixture = new Fixture();
            rule = new ActiveDispersionsCanOnlyModifyTermDatesRule();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }
        
        [Fact]
        public void RuleDoesNotThrowExceptionWhenOriginalDispersionIsNotActive()
        {
            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(10))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(10))
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenDispersionIsHistorical()
        {
            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-5))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-5))
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsChanged()
        {
            var distributionRate = fixture.Create<decimal>();
            var vendorComp = fixture.Create<decimal>();
            var effectiveDate = DateTimeOffset.Now.AddDays(-5);
            var invalidDispersion = false;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.DistributionRate, distributionRate)
                .With(p => p.VendorCompensation, vendorComp)
                .With(p => p.IsInvalidDispersion, invalidDispersion)
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(20))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.DistributionRate, distributionRate)
                .With(p => p.VendorComp, vendorComp)
                .With(p => p.IsInvalidDispersion, invalidDispersion)
                .With(p => p.TermDate, null)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenEffectiveDateChangesOnActiveDispersion()
        {
            var distributionRate = fixture.Create<decimal>();
            var vendorComp = fixture.Create<decimal>();
            var invalidDispersion = false;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-5))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(20))
                .With(p => p.DistributionRate, distributionRate)
                .With(p => p.VendorCompensation, vendorComp)
                .With(p => p.IsInvalidDispersion, invalidDispersion)
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(20))
                .With(p => p.DistributionRate, distributionRate)
                .With(p => p.VendorComp, vendorComp)
                .With(p => p.IsInvalidDispersion, invalidDispersion)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenDistributionRateChangesOnActiveDispersion()
        {
            var distributionRate = fixture.Create<decimal>();
            var vendorComp = fixture.Create<decimal>();
            var effectiveDate = DateTimeOffset.Now.AddDays(-5);
            var invalidDispersion = false;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(20))
                .With(p => p.DistributionRate, fixture.Create<decimal>())
                .With(p => p.VendorCompensation, vendorComp)
                .With(p => p.IsInvalidDispersion, invalidDispersion)
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(20))
                .With(p => p.DistributionRate, distributionRate)
                .With(p => p.VendorComp, vendorComp)
                .With(p => p.IsInvalidDispersion, invalidDispersion)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenVendorCompensationChangesOnActiveDispersion()
        {
            var distributionRate = fixture.Create<decimal>();
            var vendorComp = fixture.Create<decimal>();
            var effectiveDate = DateTimeOffset.Now.AddDays(-5);
            var invalidDispersion = false;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.DistributionRate, distributionRate)
                .With(p => p.VendorCompensation, fixture.Create<decimal>())
                .With(p => p.IsInvalidDispersion, invalidDispersion)
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(20))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.DistributionRate, distributionRate)
                .With(p => p.VendorComp, vendorComp)
                .With(p => p.IsInvalidDispersion, invalidDispersion)
                .With(p => p.TermDate, null)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenIsInvalidDispersionChangesOnActiveDispersion()
        {
            var distributionRate = fixture.Create<decimal>();
            var vendorComp = fixture.Create<decimal>();
            var effectiveDate = DateTimeOffset.Now.AddDays(-5);
            var invalidDispersion = false;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.DistributionRate, distributionRate)
                .With(p => p.VendorCompensation, vendorComp)
                .With(p => p.IsInvalidDispersion, true)
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(20))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.EffectiveDate, effectiveDate)
                .With(p => p.DistributionRate, distributionRate)
                .With(p => p.VendorComp, vendorComp)
                .With(p => p.IsInvalidDispersion, invalidDispersion)
                .With(p => p.TermDate, null)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }
    }
}
