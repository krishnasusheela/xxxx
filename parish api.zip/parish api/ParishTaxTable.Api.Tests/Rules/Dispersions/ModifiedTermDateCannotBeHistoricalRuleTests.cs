﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Helpers;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Dispersions;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Dispersions
{
    public class ModifiedTermDateCannotBeHistoricalRuleTests
        : IDisposable
    {
        private Fixture fixture;
        private ModifiedTermDateCannotBeHistoricalRule rule;

        private const string ExpectedExceptionMessage =
            "Dispersions cannot be edited to have a past expiration date.";

        public ModifiedTermDateCannotBeHistoricalRuleTests()
        {
            fixture = new Fixture();
            rule = new ModifiedTermDateCannotBeHistoricalRule();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDatesMatch()
        {
            var termDate = DateTimeOffset.Now;

            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.TermDate, termDate)
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.TermDate, termDate.EndOfDay())
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenUpdatedDispersionHasFutureTermDate()
        {
            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(4))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.TermDate, DateTimeOffset.Now.EndOfDay())
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenOriginalDispersionHasHistoricalTermDate()
        {
            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-1))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-10).EndOfDay())
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenUpdatedDispersionHasPastTermDateAndOriginalDispersionHasFutureTermDate()
        {
            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-10))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(1).EndOfDay())
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);

        }

        [Fact]
        public void RuleThrowsExceptionWhenUpdatedDispersionHasPastTermDateAndOriginalDispersionHasNullTermDate()
        {
            var dispersionWithUpdates = fixture
                .Build<Dispersion>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-10))
                .Create();

            var dispersionToUpdate = fixture
                .Build<DispersionDto>()
                .With(p => p.TermDate, null)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    dispersionWithUpdates,
                    dispersionToUpdate));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);

        }
    }
}
