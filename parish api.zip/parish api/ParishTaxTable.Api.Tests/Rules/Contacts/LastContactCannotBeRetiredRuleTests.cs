﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Contacts;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Contacts
{
    public class LastContactCannotBeRetiredRuleTests
        : IDisposable
    {
        private Fixture fixture;
        private LastContactCannotBeRetiredRule rule;
        private Mock<IParishRepository> repositoryMock;
        private const string ExpectedExceptionMessage =
            "This parish has one contact remaining. You may not remove that contact until another contact has been added.";

        public LastContactCannotBeRetiredRuleTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IParishRepository>();
            rule = new LastContactCannotBeRetiredRule(repositoryMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenThereAreContactsRemaining()
        {
            var parish = fixture.Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            var contacts = fixture.Build<ContactDto>()
                .With(p => p.Parish, parish)
                .With(p => p.ParishId, parish.Id)
                .CreateMany();

            parish.Contacts = contacts;

            repositoryMock
                .Setup(m => m.GetWithContactsById(parish.Id))
                .ReturnsAsync(parish);

            var expected = parish.Contacts.FirstOrDefault(p => true);

            var exception = Record.Exception(() =>
                rule.Test(expected));

            Assert.Null(exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenThereIsOneContactRemaining()
        {
            var contact = fixture.Build<ContactDto>()
                .Without(p => p.Parish)
                .Create();

            var parish = fixture.Build<ParishDto>()
                .Without(p => p.Contacts)
                .Without(p => p.Domiciles)
                .Without(p => p.Jurisdictions)
                .Create();

            var contacts = new List<ContactDto> { contact };
            parish.Contacts = contacts;
            contact.Parish = parish;
            contact.ParishId = parish.Id;

            repositoryMock
                .Setup(m => m.GetWithContactsById(parish.Id))
                .ReturnsAsync(parish);

            var expected = parish.Contacts.FirstOrDefault(p => true);

            var exception = Record.Exception(() =>
                rule.Test(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
