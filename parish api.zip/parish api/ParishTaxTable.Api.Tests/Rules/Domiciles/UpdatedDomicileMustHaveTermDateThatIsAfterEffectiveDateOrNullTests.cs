﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Domiciles;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Domiciles
{
    public class UpdatedDomicileMustHaveTermDateThatIsAfterEffectiveDateOrNullTests
        : IDisposable
    {
        private Fixture fixture;
        private UpdatedDomicileMustHaveTermDateThatIsAfterEffectiveDateOrNull rule;

        private const string ExpectedExceptionMessage =
            "Domiciles cannot have an expiration date before the effective date.";

        public UpdatedDomicileMustHaveTermDateThatIsAfterEffectiveDateOrNullTests()
        {
            fixture = new Fixture();
            rule = new UpdatedDomicileMustHaveTermDateThatIsAfterEffectiveDateOrNull();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsNull()
        {
            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, null)
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, null)
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsAfterEffectiveDate()
        {
            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(10))
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(10))
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenTermDateIsEqualToEffectiveDate()
        {
            var currentDate = DateTimeOffset.Now.AddDays(1);

            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .With(p => p.EffectiveDate, currentDate)
                .With(p => p.TermDate, currentDate)
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()
                .With(p => p.EffectiveDate, currentDate)
                .With(p => p.TermDate, currentDate)
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenTermDateIsBeforeEffectiveDate()
        {
            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-11))
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-11))
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.NotNull(exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
