﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Domiciles;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Domiciles
{
    public class CreatedDomicileMustHaveTermDateAfterEffectiveDateOrNullTermDateTests
        : IDisposable
    {
        private Fixture fixture;
        private CreatedDomicileMustHaveTermDateAfterEffectiveDateOrNullTermDate rule;
        private const string ExceptionMessage =
            "New domiciles cannot have an expiration date that is before their effective date.";

        public CreatedDomicileMustHaveTermDateAfterEffectiveDateOrNullTermDateTests()
        {
            fixture = new Fixture();

            rule = new CreatedDomicileMustHaveTermDateAfterEffectiveDateOrNullTermDate();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsNull()
        {
            var domicile = fixture
                .Build<DomicileDto>()
                .With(p => p.TermDate, null)
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(domicile));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsAheadOfEffectiveDate()
        {
            var domicile = fixture
                .Build<DomicileDto>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(10))
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(5))
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(domicile));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenTermDateIsTheSameDateAsEffectiveDate()
        {
            var testedDate = fixture.Create<DateTimeOffset>();

            var domicile = fixture
                .Build<DomicileDto>()
                .With(p => p.TermDate, testedDate)
                .With(p => p.EffectiveDate, testedDate)
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(domicile));

            Assert.NotNull(exception);
            Assert.Equal(
                ExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenTermDateIsPriorToEffectiveDate()
        {
            var domicile = fixture
                .Build<DomicileDto>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(5))
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(10))
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(domicile));

            Assert.NotNull(exception);
            Assert.Equal(
                ExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
