﻿using System;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Infrastructure.Interfaces.Repositories;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Domiciles;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Domiciles
{
    public class CreatedDomicileCannotHaveSameCodeAsOtherDomicilesTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<IDomicileRepository> repositoryMock;
        private CreatedDomicileCannotHaveSameCodeAsOtherDomiciles rule;

        private const string ExpectedExceptionMessage =
            "Created Domicile's Code is already in use.";

        public CreatedDomicileCannotHaveSameCodeAsOtherDomicilesTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IDomicileRepository>();
            rule = new CreatedDomicileCannotHaveSameCodeAsOtherDomiciles(repositoryMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenCodeIsUnique()
        {
            var domicile = fixture
                .Build<DomicileDto>()
                .Without(x => x.Dispersions)
                .Without(x => x.Parish)
                .Create();

            repositoryMock
                .Setup(m => m.GetByCode(domicile.ParishId, domicile.Code))
                .ReturnsAsync((DomicileDto)null);

            var exception = Record.Exception(() =>
                rule.Test(
                    domicile));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenCodeIsAlreadyUsed()
        {
            var domicile = fixture
                .Build<DomicileDto>()
                .Without(x => x.Dispersions)
                .Without(x => x.Parish)
                .Create();

            var expected = fixture
                .Build<DomicileDto>()
                .Without(x => x.Dispersions)
                .Without(x => x.Parish)
                .Create();

            repositoryMock
                .Setup(m => m.GetByCode(domicile.ParishId, domicile.Code))
                .ReturnsAsync(expected);

            var exception = Record.Exception(() =>
                rule.Test(
                    domicile));

            Assert.NotNull(
                exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
