﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Domiciles;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Domiciles
{
    public class UpdatedDomicileCannotBeModifiedIfDomicileIsExpiredTests
        : IDisposable
    {
        private Fixture fixture;
        private UpdatedDomicileCannotBeModifiedIfDomicileIsExpired rule;
        private const string ExceptionMessage =
            "Unable to modify domicile after Expiration Date has passed.";

        public UpdatedDomicileCannotBeModifiedIfDomicileIsExpiredTests()
        {
            fixture = new Fixture();

            rule = new UpdatedDomicileCannotBeModifiedIfDomicileIsExpired();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsNull()
        {
            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()
                .With(p => p.TermDate, null)
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsInTheFuture()
        {
            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(10))
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenTermDateIsInThePast()
        {
            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-2))
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.NotNull(exception);
            Assert.Equal(
                ExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}