﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Domiciles;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Domiciles
{
    public class CreatedDomicileMustHaveFutureEffectiveDateTests
        : IDisposable
    {
        private Fixture fixture;
        private CreatedDomicileMustHaveFutureEffectiveDate rule;
        private const string ExceptionMessage =
            "New domiciles cannot be created as immediately current. Create one with an effective date in the future.";

        public CreatedDomicileMustHaveFutureEffectiveDateTests()
        {
            fixture = new Fixture();

            rule = new CreatedDomicileMustHaveFutureEffectiveDate();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenEffectiveDateIsInTheFuture()
        {
            var domicile = fixture
                .Build<DomicileDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(10))
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(domicile));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenEffectiveDateIsToday()
        {
            var domicile = fixture
                .Build<DomicileDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now)
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(domicile));

            Assert.NotNull(exception);
            Assert.Equal(
                ExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenEffectiveDateIsInThePast()
        {
            var domicile = fixture
                .Build<DomicileDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-10))
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(domicile));

            Assert.NotNull(exception);
            Assert.Equal(
                ExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}