﻿using System;
using AutoFixture;
using ParishTaxTable.Api.Core.Entities;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Domiciles;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Domiciles
{
    public class UpdatedDomicileCannotChangeTermDateToPastDateTests
        : IDisposable
    {
        private Fixture fixture;
        private UpdatedDomicileCannotChangeTermDateToPastDate rule;
        private const string ExceptionMessage =
            "Domicile Expiration Date must be in the future.";

        public UpdatedDomicileCannotChangeTermDateToPastDateTests()
        {
            fixture = new Fixture();

            rule = new UpdatedDomicileCannotChangeTermDateToPastDate();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsNull()
        {
            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .With(p => p.TermDate, null)
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()                
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.Null(
                exception);

        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDatesMatch()
        {
            var termDate = fixture.Create<DateTimeOffset>();

            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .With(p => p.TermDate, termDate)
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()
                .With(p => p.TermDate, termDate)
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenTermDateIsAFutureDate()
        {
            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(10))
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenTermDateIsInThePast()
        {
            var domicileWithUpdates = fixture
                .Build<Domicile>()
                .With(p => p.TermDate, DateTimeOffset.Now.AddDays(-2))
                .Create();

            var domicileToUpdate = fixture
                .Build<DomicileDto>()
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)                
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    domicileToUpdate,
                    domicileWithUpdates));

            Assert.NotNull(exception);
            Assert.Equal(
                ExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
