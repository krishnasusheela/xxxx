﻿using System;
using System.Collections.Generic;
using AutoFixture;
using Moq;
using ParishTaxTable.Api.Infrastructure.Interfaces.Rules;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Rules.Domiciles;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Rules.Domiciles
{
    public class DomicileCreateRulesTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<ICreateDomicileRule> rule1;
        private Mock<ICreateDomicileRule> rule2;
        private DomicileCreateRules rules;

        public DomicileCreateRulesTests()
        {
            fixture = new Fixture();

            rule1 = new Mock<ICreateDomicileRule>();
            rule2 = new Mock<ICreateDomicileRule>();

            rules = new DomicileCreateRules(
                new List<ICreateDomicileRule>
                {
                    rule1.Object,
                    rule2.Object
                });
        }

        public void Dispose()
        {
            fixture = null;
            rule1 = null;
            rule2 = null;
            rules = null;
        }

        [Fact]
        public void RulesCreateSuccessfully()
        {
            Assert.NotNull(
                rules);
        }

        [Fact]
        public void RulesThrowsExceptionWhenARuleThrowsAnException()
        {
            var domicile = fixture
                .Build<DomicileDto>()
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .Create();

            rule2
                .Setup(m => m.Test(
                    domicile))
                .Throws<TestException>();

            Assert.Throws<TestException>(() =>
                rules.Test(
                    domicile));
        }

        [Fact]
        public void RulesCallsAllSubRules()
        {

            var domicile = fixture
                .Build<DomicileDto>()
                .Without(p => p.Dispersions)
                .Without(p => p.Parish)
                .Create();

            rule1
                .Setup(m => m.Test(
                    domicile))
                .Verifiable();

            rule2
                .Setup(m => m.Test(
                    domicile))
                .Verifiable();

            rules.Test(
                domicile);

            rule1
                .Verify(m => m.Test(
                    domicile));

            rule2
                .Verify(m => m.Test(
                    domicile));
        }
    }
}
