﻿using System;
using System.Linq;
using System.Threading.Tasks;
using ParishTaxTable.Api.Infrastructure.Repositories;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Repositories
{
    public class ParishRepositoryTests
        : ParishTaxTableContextTestBase
    {
        private ParishRepository repository;

        public ParishRepositoryTests()
        {
            repository = new ParishRepository(
                TableContext);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository = null;
            }
        }

        [Fact]
        public void RepositoryCreatesSuccessfully()
        {
            Assert.NotNull(
                repository);
        }

        [Fact]
        public async Task GetByIdReturnsExpected()
        {
            var expected = 1;

            Seed(TableContext);

            var actual = await repository
                .GetById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }

        [Fact]
        public async Task GetReturnsAllItems()
        {
            var expected = 4;

            Seed(TableContext);

            var actual = await repository
                .Get();

            Assert.Equal(
                expected,
                actual.Count());
        }

        [Fact]
        public async Task GetWithDomicilesByIdReturnsExpected()
        {
            var expected = 1;

            Seed(TableContext);

            var actual = await repository
                .GetWithDomicilesById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }

        [Fact]
        public async Task GetWithDomicilesReturnsWithActiveDomicilesAndJurisdictions()
        {
            var expected = 4;

            Seed(TableContext);

            var actual = await repository
                .GetWithDomiciles();

            Assert.Equal(
                expected,
                actual.Count());
        }

        [Fact]
        public async Task GetWithContactsByIdReturnsExpected()
        {
            var expected = 1;

            Seed(TableContext);

            var actual = await repository
                .GetWithContactsById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }

        [Fact]
        public async Task GetWithContactsByIdReturnsOnlyActiveContacts()
        {
            var parishId = 1;

            Seed(TableContext);

            var actual = await repository
                .GetWithContactsById(parishId);

            Assert.True(
                actual
                    .Contacts
                    .All(y =>
                        y.CreateDate <= DateTimeOffset.Now
                        && (y.RetireDate == null
                            || y.RetireDate >= DateTimeOffset.Now)));
        }

        [Fact]
        public async Task GetWithContactsReturnsExpected()
        {
            var expected = 4;

            Seed(TableContext);

            var actual = await repository
                .GetWithContacts();

            Assert.Equal(
                expected,
                actual.Count());
        }

        [Fact]
        public async Task GetWithContactsReturnsOnlyActiveContacts()
        {
            Seed(TableContext);

            var actual = await repository
                .GetWithContacts();

            Assert.True(
                actual
                    .First()
                    .Contacts
                    .All(y =>
                        y.CreateDate <= DateTimeOffset.Now
                        && (y.RetireDate == null
                            || y.RetireDate >= DateTimeOffset.Now)));
        }

        [Fact]
        public async Task GetWithJurisdictionsByIdReturnsExpected()
        {
            var expected = 1;

            Seed(TableContext);

            var actual = await repository
                .GetWithJurisdictionsById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }

        [Fact]
        public async Task GetWithJurisdictionsReturnsExpected()
        {
            var expected = 4;

            Seed(TableContext);

            var actual = await repository
                .GetWithJurisdictions();

            Assert.Equal(
                expected,
                actual.Count());
        }
    }
}
