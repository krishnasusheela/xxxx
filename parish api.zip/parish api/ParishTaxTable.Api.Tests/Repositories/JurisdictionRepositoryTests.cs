﻿using System;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using Microsoft.EntityFrameworkCore;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Repositories;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Repositories
{
    public class JurisdictionRepositoryTests
        : ParishTaxTableContextTestBase
    {
        private JurisdictionRepository repository;

        public JurisdictionRepositoryTests()
        {
            repository = new JurisdictionRepository(
                TableContext);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository = null;
            }
        }

        [Fact]
        public void RepositoryCreatesSuccessfully()
        {
            Assert.NotNull(
                repository);
        }

        [Fact]
        public async Task GetReturnsExpected()
        {
            Seed(TableContext);

            var actual = await repository.Get();

            Assert.NotEmpty(
                actual);
        }

        [Fact]
        public async Task GetByIdReturnsExpected()
        {
            var expected = 1000;

            Seed(TableContext);

            var jurisdiction = CreateJurisdiction(
                expected);

            TableContext.Jurisdictions.Add(jurisdiction);
            TableContext.SaveChanges();
            
            var actual = await repository
                .GetById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }

        [Fact]
        public async Task CreateAddsNewJurisdictionToDatabase()
        {
            var jurisdiction = TestFixture
                .Build<JurisdictionDto>()
                .With(p => p.Id, 0)
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            await repository
                .Create(jurisdiction);

            Assert.Equal(
                1, TableContext.Jurisdictions.Count());
        }

        [Fact]
        public async Task CreateSetsCreateDate()
        {
            var jurisdiction = TestFixture
                .Build<JurisdictionDto>()
                .With(p => p.Id, 0)
                .With(p => p.CreateDate, DateTimeOffset.MinValue)
                .Without(p => p.JurisdictionType)
                .Without(p => p.Parish)
                .Create();

            var actual = await repository
                .Create(jurisdiction);

            Assert.Equal(
                DateTimeOffset.Now.Date,
                actual.CreateDate.Date);
        }

        [Fact]
        public async Task UpdateChangesValues()
        {
            var jurisdictionId = TestFixture.Create<int>();
            var expectedName = TestFixture.Create<string>();

            Seed(TableContext);
            var jurisdiction = CreateJurisdiction(
                jurisdictionId);

            TableContext.Jurisdictions.Add(jurisdiction);
            TableContext.SaveChanges();

            var item = await TableContext
                .Jurisdictions
                .SingleOrDefaultAsync(p => p.Id == jurisdictionId);

            item.Name = expectedName;

            var actual = await repository.Update(item);

            Assert.Equal(
                expectedName,
                actual.Name);
        }
    }
}
