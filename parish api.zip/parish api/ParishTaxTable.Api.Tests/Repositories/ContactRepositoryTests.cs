﻿using System;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Repositories;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Repositories
{
    public class ContactRepositoryTests
        : ParishTaxTableContextTestBase
    {
        private ContactRepository repository;

        public ContactRepositoryTests()
        {
            repository = new ContactRepository(
                TableContext);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository = null;
            }
        }

        [Fact]
        public void RepositoryCreatesSuccessfully()
        {
            Assert.NotNull(
                repository);
        }

        [Fact]
        public async Task GetByIdReturnsExpected()
        {
            var expected = 1;

            Seed(TableContext);

            var contact = TestFixture
                .Build<ContactDto>()
                .With(p => p.Id, expected)
                .Without(p => p.Parish)
                .Create();

            TableContext.Contacts.Add(contact);
            TableContext.SaveChanges();

            var actual = await repository
                .GetById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }

        [Fact]
        public async Task CreateContactAddsNewContactToDatabase()
        {
            var newContact = TestFixture.Build<ContactDto>()
                .With(t => t.Id, 0)
                .Without(t => t.Parish)
                .Create();

            await repository
                .InsertContact(newContact);

            Assert.Equal(
                1, TableContext.Contacts.Count());
        }

        [Fact]
        public async Task CreateContactSetsCreateDate()
        {
            var newContact = TestFixture.Build<ContactDto>()
                .With(t => t.Id, 0)
                .With(t => t.CreateDate, DateTimeOffset.MinValue)
                .Without(t => t.Parish)
                .Create();

            var actual = await repository
                .InsertContact(newContact);

            Assert.Equal(
                DateTimeOffset.Now.Date,
                actual.CreateDate.Date);
        }

        [Fact]
        public async Task CreateContactSetsRetireDateToNull()
        {
            var newContact = TestFixture.Build<ContactDto>()
                .With(t => t.Id, 0)
                .With(t => t.CreateDate, DateTimeOffset.MinValue)
                .With(t => t.RetireDate, DateTimeOffset.MaxValue)
                .Without(t => t.Parish)
                .Create();

            var actual = await repository
                .InsertContact(newContact);

            Assert.Null(
                actual.RetireDate);
        }

        [Fact]
        public async Task CreateContactWithSpecifiedDateSetsCreateDate()
        {
            var expectedDate = DateTimeOffset.UnixEpoch;

            var newContact = TestFixture.Build<ContactDto>()
                .With(t => t.Id, 0)
                .With(t => t.CreateDate, DateTimeOffset.MinValue)
                .Without(t => t.Parish)
                .Create();

            var actual = await repository
                .InsertContact(
                    newContact,
                    expectedDate);

            Assert.Equal(
                expectedDate,
                actual.CreateDate);
        }

        [Fact]
        public async Task CreateContactReturnsCreatedContact()
        {
            var newContact = TestFixture.Build<ContactDto>()
                .With(t => t.Id, 0)
                .Without(t => t.Parish)
                .Create();

            var createdContact = await repository
                .InsertContact(newContact);

            Assert.Equal(
                newContact.Name,
                createdContact.Name);

            Assert.Equal(
                1, createdContact.Id);
        }

        [Fact]
        public async Task RetireContactSetsRetireDate()
        {
            const int id = 1;

            var contact = TestFixture
                .Build<ContactDto>()
                .With(p => p.Id, id)
                .With(p => p.RetireDate, null)
                .Without(t => t.Parish)
                .Create();

            TableContext.Contacts.Add(contact);
            TableContext.SaveChanges();

            var actual = await repository
                .RetireContact(id);

            var actualDate = actual.RetireDate ?? DateTimeOffset.MinValue;

            Assert.Equal(
                DateTimeOffset.Now.Date,
                actualDate.Date);
        }

        [Fact]
        public async Task RetireContactWithSpecifiedRetireDateSetsRetireDate()
        {
            const int id = 1;
            var expectedDate = DateTime.UnixEpoch;

            var contact = TestFixture
                .Build<ContactDto>()
                .With(p => p.Id, id)
                .With(p => p.RetireDate, null)
                .Without(t => t.Parish)
                .Create();

            TableContext.Contacts.Add(contact);
            TableContext.SaveChanges();

            var actual = await repository
                .RetireContact(id, expectedDate);

            var actualDate = actual.RetireDate ?? DateTimeOffset.MinValue;

            Assert.Equal(
                expectedDate,
                actualDate.Date);
        }
    }
}
