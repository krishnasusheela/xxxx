﻿using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using Microsoft.EntityFrameworkCore;
using ParishTaxTable.Api.Infrastructure.Models;
using ParishTaxTable.Api.Infrastructure.Repositories;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Repositories
{
    public class DispersionRepositoryTests
        : ParishTaxTableContextTestBase
    {
        private DispersionRepository repository;

        public DispersionRepositoryTests()
        {
            repository = new DispersionRepository(
                TableContext);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository = null;
            }
        }

        [Fact]
        public void RepositoryCreatesSuccessfully()
        {
            Assert.NotNull(
                repository);
        }

        [Fact]
        public async Task GetByIdReturnsExpected()
        {
            const int expected = 1000;

            Seed(TableContext);

            var dispersion = CreateDispersion(expected);

            TableContext.Dispersions.Add(dispersion);
            TableContext.SaveChanges();

            var actual = await repository
                .GetById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }

        [Fact]
        public async Task GetByJurisdictionIdReturnsExpected()
        {
            const int expected = 1000;

            Seed(TableContext);

            var dispersion = CreateDispersion(expected);
            var expectedJurisdictionId = dispersion.JurisdictionId;

            TableContext.Dispersions.Add(dispersion);
            TableContext.SaveChanges();

            var actual = await repository
                .GetByJurisdictionId(expectedJurisdictionId);

            Assert.Equal(
                expected,
                actual.FirstOrDefault().Id);
        }

        [Fact]
        public async Task CreateAddsNewDispersionToDatabase()
        {
            var dispersion = TestFixture
                .Build<DispersionDto>()
                .With(p => p.Id, 0)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            await repository
                .Create(dispersion);

            Assert.Equal(
                1, TableContext
                    .Dispersions
                    .IgnoreQueryFilters()
                    .Count());
        }

        [Fact]
        public async Task CreateReturnsDispersionWithUpdatedId()
        {
            var dispersion = TestFixture
                .Build<DispersionDto>()
                .With(p => p.Id, 0)
                .Without(p => p.Domicile)
                .Without(p => p.Jurisdiction)
                .Create();

            var actual = await repository
                .Create(dispersion);

            Assert.NotEqual(
                0,
                actual.Id);
        }

        [Fact]
        public async Task UpdateChangesValues()
        {
            const int expectedId = 1000;
            var expectedComp = TestFixture.Create<decimal>();

            Seed(TableContext);

            var dispersion = CreateDispersion(expectedId);

            TableContext.Dispersions.Add(dispersion);
            TableContext.SaveChanges();

            var dispersionToUpdate = await TableContext
                .Dispersions
                .IgnoreQueryFilters()
                .SingleOrDefaultAsync(p => p.Id == expectedId);

            dispersionToUpdate.VendorComp = expectedComp;

            var actual = await repository
                .Update(dispersionToUpdate);

            Assert.Equal(
                expectedComp,
                actual.VendorComp);
        }

        [Fact]
        public async Task DeleteRemovesItem()
        {
            const int expectedId = 1000;

            Seed(TableContext);

            var dispersion = CreateDispersion(expectedId);

            TableContext.Dispersions.Add(dispersion);
            TableContext.SaveChanges();

            var dispersionToDelete = await TableContext
                .Dispersions
                .IgnoreQueryFilters()
                .SingleOrDefaultAsync(p => p.Id == expectedId);

            Assert.NotNull(
                dispersionToDelete);

            await repository.Delete(expectedId);

            var deletedDispersion = await TableContext
                .Dispersions
                .IgnoreQueryFilters()
                .SingleOrDefaultAsync(p => p.Id == expectedId);

            Assert.Null(
                deletedDispersion);
        }
    }
}
