﻿using System;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using Microsoft.EntityFrameworkCore;
using ParishTaxTable.Api.Infrastructure.Repositories;
using ParishTaxTable.Api.Tests.TestHelpers;
using Xunit;

namespace ParishTaxTable.Api.Tests.Repositories
{
    public class DomicileRepositoryTests
        : ParishTaxTableContextTestBase
    {
        private DomicileRepository repository;

        public DomicileRepositoryTests()
        {
            repository = 
                new DomicileRepository(
                    TableContext);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository = null;
            }
        }

        [Fact]
        public void RepositoryCreatesSuccessfully()
        {
            Assert.NotNull(
                repository);
        }

        [Fact]
        public async Task GetReturnsExpected()
        {
            Seed(TableContext);

            var actual = await repository.Get();

            Assert.NotEmpty(
                actual);
        }

        [Fact]
        public async Task GetByIdReturnsExpected()
        {
            const int expected = 1000;

            Seed(TableContext);

            var domicile = CreateDomicileWithRelatedData(
                expected);

            TableContext.Domiciles.Add(domicile);
            TableContext.SaveChanges();

            var actual = await repository
                .GetById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }
        
        [Fact]
        public async Task GetByIdAndDateReturnsExpected()
        {
            const int expected = 1000;
            DateTimeOffset expectedDate = DateTimeOffset.Now;

            Seed(TableContext);

            var domicile = CreateDomicileWithRelatedDataByDate(expected, expectedDate);

            TableContext.Domiciles.Add(domicile);
            TableContext.SaveChanges();

            var actual = await repository
                .GetByIdAndDate(expected,expectedDate);

            Assert.Equal(
                expected,
                actual.Id);
        }

        [Fact]
        public async Task CreateAddsNewDomicileToDatabase()
        {
            var domicileId = TestFixture.Create<int>();

            var domicile = CreateDomicile(domicileId);

            await repository
                .Create(domicile);

            Assert.Equal(
                1, 
                TableContext
                    .Domiciles
                    .IgnoreQueryFilters()
                    .Count());
        }

        [Fact]
        public async Task UpdateChangesValues()
        {
            var domicileId = TestFixture.Create<int>();
            var expectedName = TestFixture.Create<string>();

            Seed(TableContext);

            var domicile = CreateDomicile(
                domicileId);

            TableContext.Domiciles.Add(domicile);
            TableContext.SaveChanges();

            var item = await TableContext
                .Domiciles
                .IgnoreQueryFilters()
                .SingleOrDefaultAsync(
                    p => p.Id == domicileId);

            item.Name = expectedName;

            var actual = await repository
                .Update(item);

            Assert.Equal(
                expectedName,
                actual.Name);
        }

        [Fact]
        public async Task GetByCodeReturnsExpected()
        { 
            var expected = TestFixture.Create<int>() % 99;

            Seed(TableContext);

            var domicile = TableContext.Domiciles.First();

            var actual = await repository
                .GetByCodes(domicile.Parish.Code, domicile.Code);

            Assert.NotNull(actual);
            Assert.Equal(
                domicile.Id,
                actual.Id);
        }
    }
}
