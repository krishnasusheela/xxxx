﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Core.Interfaces
{
    public interface IJurisdictionDataService
    {
        Task<IEnumerable<Jurisdiction>> GetAllJurisdictions();
        Task<Jurisdiction> GetJurisdictionById(int id);
        Task<Jurisdiction> CreateJurisdiction(Jurisdiction jurisdiction);
        Task<Jurisdiction> UpdateJurisdiction(Jurisdiction jurisdiction);
    }
}
