﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Core.Interfaces
{
    public interface IParishDomicileDataService
    {
        Task<IEnumerable<ParishDomicile>> GetAllParishDomiciles();
        Task<ParishDomicile> GetDomicileParishById(int id);
        Task<ParishNextDomicileCode> GetNextParishDomicileCode(int id);
    }
}
