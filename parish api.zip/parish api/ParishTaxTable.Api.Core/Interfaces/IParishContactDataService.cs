﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Core.Interfaces
{
    public interface IParishContactDataService
    {
        Task<IEnumerable<ParishContact>> GetAllParishContacts();
        Task<ParishContact> GetParishContactsById(int id);
    }
}
