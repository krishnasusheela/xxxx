﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Core.Interfaces
{
    public interface IJurisdictionTypeDataService
    {
        Task<IEnumerable<JurisdictionType>> GetAllJurisdictionTypes();
    }
}
