﻿using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Core.Interfaces
{
    public interface IContactDataService
    {
        Task<Contact> GetContactById(int id);
        Task<Contact> CreateContact(Contact contact);
        Task<Contact> RetireContact(int id);
        Task<Contact> UpdateContact(Contact contact);
    }
}
