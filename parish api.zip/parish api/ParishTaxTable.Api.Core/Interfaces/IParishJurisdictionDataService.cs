﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Core.Interfaces
{
    public interface IParishJurisdictionDataService
    {
        Task<IEnumerable<ParishJurisdiction>> GetAllParishJurisdictions();
        Task<ParishJurisdiction> GetParishJurisdictionById(int id);
    }
}
