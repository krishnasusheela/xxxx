﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Core.Interfaces
{
    public interface IDomicileDataService
    {
        Task<IEnumerable<Domicile>> GetAllDomiciles();
        Task<Domicile> GetDomicileById(int id);
        Task<Domicile> CreateDomicile(Domicile domicile);
        Task<Domicile> UpdateDomicile(Domicile domicile);
        Task<Domicile> GetDomicileByIdAndDate(int id, DateTimeOffset date);
        Task<Domicile> GetDomicileCodeByCode(string code);
    }
}
