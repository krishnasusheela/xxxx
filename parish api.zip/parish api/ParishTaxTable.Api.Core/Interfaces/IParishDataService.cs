﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Core.Interfaces
{
    public interface IParishDataService
    {
        Task<IEnumerable<Parish>> GetAllParishes();
        Task<Parish> GetParishById(int id);
    }
}
