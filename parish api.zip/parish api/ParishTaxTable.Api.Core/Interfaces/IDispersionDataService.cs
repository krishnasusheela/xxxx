﻿using System.Threading.Tasks;
using ParishTaxTable.Api.Core.Entities;

namespace ParishTaxTable.Api.Core.Interfaces
{
    public interface IDispersionDataService
    {
        Task<Dispersion> GetDispersionById(int id);
        Task<Dispersion> UpdateDispersion(Dispersion domicile);
        Task<Dispersion> CreateDispersion(Dispersion dispersion);
        Task<Dispersion> ReplaceDispersion(Dispersion dispersion, int invalidatedId);
        Task DeleteDispersion(int id);
    }
}
