﻿using System;

namespace ParishTaxTable.Api.Core.Entities
{
    public class Dispersion
    {
        public int Id { get; set; }
        public decimal DistributionRate { get; set; }
        public decimal VendorCompensation { get; set; }
        public bool IsInvalidDispersion { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? TermDate { get; set; }

        public int DomicileId { get; set; }
        public int JurisdictionId { get; set; }


        public Jurisdiction Jurisdiction { get; set; }
    }
}
