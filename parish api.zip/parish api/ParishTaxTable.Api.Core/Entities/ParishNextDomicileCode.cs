﻿namespace ParishTaxTable.Api.Core.Entities
{
    public class ParishNextDomicileCode
    {
        public string NextDomicileCode { get; set; }
    }
}
