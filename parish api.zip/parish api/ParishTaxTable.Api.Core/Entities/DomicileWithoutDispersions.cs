﻿using System;

namespace ParishTaxTable.Api.Core.Entities
{
    public class DomicileWithoutDisperions : Domicile
    {
    }
}
