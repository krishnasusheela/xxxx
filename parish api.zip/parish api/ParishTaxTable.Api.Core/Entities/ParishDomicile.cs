﻿using System.Collections.Generic;

namespace ParishTaxTable.Api.Core.Entities
{
    public class ParishDomicile
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public IEnumerable<Domicile> Domiciles { get; set; }
    }
}
