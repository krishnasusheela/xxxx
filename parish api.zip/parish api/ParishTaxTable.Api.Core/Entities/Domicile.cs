﻿using System;
using System.Collections.Generic;

namespace ParishTaxTable.Api.Core.Entities
{
    public class Domicile
    {
        public int Id { get; set; }
        public int ParishId { get; set; }
        public string CombinedCode { get; set; }
        public decimal CollectionRate { get; set; }
        public decimal VendorCompensation { get; set; }
        public decimal ParishCollectionRate { get; set; }
        public decimal MunicipalityCollectionRate { get; set; }
        public string ParishCode { get; set; }
        public string DomicileCode { get; set; }
        public string Name { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? TermDate { get; set; }
        public IEnumerable<Dispersion> Dispersions { get; set; }
    }   
}
