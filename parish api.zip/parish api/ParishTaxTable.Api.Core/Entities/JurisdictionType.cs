﻿namespace ParishTaxTable.Api.Core.Entities
{
    public class JurisdictionType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
