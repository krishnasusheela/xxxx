﻿using System;

namespace ParishTaxTable.Api.Core.Entities
{
    public class Jurisdiction
    {
        public int Id { get; set; }
        public int ParishId { get; set; }
        public string Name { get; set; }
        public JurisdictionType JurisdictionType { get; set; }
        public DateTimeOffset CreateDate { get; set; }
        public DateTimeOffset? RetireDate { get; set; }
    }
}
