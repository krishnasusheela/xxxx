﻿using System;

namespace ParishTaxTable.Api.Core.Entities
{
    public class Contact
    {
        public int Id { get; set; }
        public int ParishId { get; set; }
        public string TaxingAuthority { get; set; }
        public string EftCode { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mailto { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Zip4 { get; set; }
        public string ContactPhoneNumber { get; set; }
        public string ContactPhoneNumberExtension { get; set; }
        public string ContactPhoneNumberAlt { get; set; }
        public string ContactPhoneNumberAltExtension { get; set; }
        public string FaxPhoneNumber { get; set; }
        public DateTime? AgreementDate { get; set; }
        public DateTimeOffset CreateDate { get; set; }
        public DateTimeOffset? RetireDate { get; set; }
    }
}
