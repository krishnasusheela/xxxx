﻿using System.Collections.Generic;

namespace ParishTaxTable.Api.Core.Entities
{
    public class ParishContact
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public IEnumerable<Contact> Contacts { get; set; }
    }
}
