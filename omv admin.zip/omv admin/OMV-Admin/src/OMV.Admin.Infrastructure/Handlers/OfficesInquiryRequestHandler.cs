﻿using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Configurations;
using OMV.Admin.Infrastructure.Requests;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Handlers
{
    public class OfficesInquiryRequestHandler : IRequestHandler<OfficesInquiryRequest, Office>
    {
        private readonly WebApiServer webApiServer;
        public OfficesInquiryRequestHandler(IOptions<WebApiServer> webApiServer)
        {
            this.webApiServer = webApiServer.Value;
        }

        public async Task<Office> Handle(
            OfficesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            using (var httpClient = new HttpClient())
            {
                var response = await httpClient
                    .GetAsync(
                        $"{webApiServer.OMVOfficeListingApi}/Offices/{request.Id}",
                        cancellationToken);

                response.EnsureSuccessStatusCode();

                var stringResult = await response.Content.ReadAsStringAsync();
                var office = JsonConvert.DeserializeObject<Office>(stringResult);

                return office;
            }
        }
    }
}