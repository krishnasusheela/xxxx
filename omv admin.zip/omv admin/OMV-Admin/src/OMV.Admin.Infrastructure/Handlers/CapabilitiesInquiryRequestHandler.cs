﻿using MediatR;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;
using OMV.Admin.Infrastructure.Requests;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Handlers
{
    public class CapabilitiesInquiryRequestHandler : IRequestHandler<CapabilitiesInquiryRequest, IEnumerable<Capability>>
    {
        private readonly ICapabilitiesService service;

        public CapabilitiesInquiryRequestHandler(ICapabilitiesService service) 
        {
            this.service = service;
        }


        public async Task<IEnumerable<Capability>> Handle(
            CapabilitiesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await service.CapabilitiesInquiry();
        }
    }
}
