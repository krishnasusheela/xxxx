﻿using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Configurations;
using OMV.Admin.Infrastructure.Requests;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Handlers
{
    public class OfficesIndexRequestHandler : IRequestHandler<OfficesIndexRequest, IEnumerable<Office>>
    {
        private readonly WebApiServer webApiServer;
        public OfficesIndexRequestHandler(IOptions<WebApiServer> webApiServer)
        {
            this.webApiServer = webApiServer.Value;
        }

        public async Task<IEnumerable<Office>> Handle(
            OfficesIndexRequest request,
            CancellationToken cancellationToken)
        {
            using (var httpClient = new HttpClient())
            {
                var response = await httpClient
                    .GetAsync(
                        $"{webApiServer.OMVOfficeListingApi}/Offices",
                        cancellationToken);

                response.EnsureSuccessStatusCode();

                var stringResult = await response.Content.ReadAsStringAsync();

                var offices = JsonConvert.DeserializeObject<IList<Office>>(stringResult);


                return offices;
            }
        }
    }
}