﻿using OMV.Admin.Infrastructure.Requests;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;

namespace OMV.Admin.Infrastructure.Handlers
{
    public class TaxesDateInquiryRequestHandler
        : IRequestHandler<TaxesDateInquiryRequest, Domicile>
    {
        private readonly ITaxTableService service;

        public TaxesDateInquiryRequestHandler(
            ITaxTableService service)
        {
            this.service = service;
        }

        public async Task<Domicile> Handle(
            TaxesDateInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await service.GetDomicileByIdAndDate(
                request.DomicileId,
                request.Date);
        }
    }
}
