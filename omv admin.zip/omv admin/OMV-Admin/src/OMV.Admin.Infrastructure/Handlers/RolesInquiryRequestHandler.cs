﻿using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Configurations;
using OMV.Admin.Infrastructure.Requests;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Handlers
{
    public class RolesInquiryRequestHandler : IRequestHandler<RolesInquiryRequest, IEnumerable<Role>>
    {
        private readonly WebApiServer webApiServer;
        public RolesInquiryRequestHandler(IOptions<WebApiServer> webApiServer)
        {
            this.webApiServer = webApiServer.Value;
        }

        public async Task<IEnumerable<Role>> Handle(
            RolesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            using (var httpClient = new HttpClient())
            {
                var response = await httpClient
                    .GetAsync(
                        $"{webApiServer.OMVOfficeListingApi}/Roles",
                        cancellationToken);

                response.EnsureSuccessStatusCode();

                var stringResult = await response.Content.ReadAsStringAsync();
                var roles = JsonConvert.DeserializeObject<IList<Role>>(stringResult);

                return roles;
            }
        }
    }
}
