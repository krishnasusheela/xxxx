﻿using MediatR;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;
using OMV.Admin.Infrastructure.Requests;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Handlers
{
    public class OfficeTypesInquiryRequestHandler
        : IRequestHandler<OfficeTypesInquiryRequest, IEnumerable<OfficeType>>
    {
        private readonly IOfficeTypesService service;

        public OfficeTypesInquiryRequestHandler(IOfficeTypesService service)
        {
            this.service = service;
        }


        public async Task<IEnumerable<OfficeType>> Handle(
            OfficeTypesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await service.OfficeTypesInquiry();
        }
    }
}
