﻿using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;
using OMV.Admin.Infrastructure.Configurations;
using OMV.Admin.Infrastructure.Requests;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Handlers
{
    public class RoleInquiryRequestHandler : IRequestHandler<RoleInquiryRequest, Role>
    {
        private readonly IRolesService service;

        public RoleInquiryRequestHandler(IRolesService service)
        {
            this.service = service;
        }

        public async Task<Role> Handle(
            RoleInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await service.RoleInquiry(request.Id);
        }
    }
}
