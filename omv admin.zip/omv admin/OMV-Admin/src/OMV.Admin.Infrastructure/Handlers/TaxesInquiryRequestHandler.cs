﻿using OMV.Admin.Infrastructure.Requests;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;

namespace OMV.Admin.Infrastructure.Handlers
{
    public class TaxesInquiryRequestHandler
        : IRequestHandler<TaxesInquiryRequest, Domicile>
    {
        private readonly ITaxTableService service;

        public TaxesInquiryRequestHandler(
            ITaxTableService service)
        {
            this.service = service;
        }

        public async Task<Domicile> Handle(
            TaxesInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await service.GetDomicileByCode(
                request.DomicileCode);
        }
    }
}
