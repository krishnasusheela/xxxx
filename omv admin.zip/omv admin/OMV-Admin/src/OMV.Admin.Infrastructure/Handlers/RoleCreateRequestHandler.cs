﻿using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Configurations;
using OMV.Admin.Infrastructure.Requests;
using System;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Handlers
{
    public class RoleCreateRequestHandler 
        : IRequestHandler<RoleCreateRequest, Role>
    {
        private readonly WebApiServer webApiServer;

        public RoleCreateRequestHandler(IOptions<WebApiServer> webApiServer)
        {
            this.webApiServer = webApiServer.Value;
        }

        public async Task<Role> Handle(
            RoleCreateRequest request,
            CancellationToken cancellationToken)
        {
            using (var client = new HttpClient())
            {

                var jsonRole = JsonConvert.SerializeObject(request.role);
                var content = new StringContent(jsonRole, Encoding.UTF8, "application/json");

                var response = await client
                    .PostAsync(
                        $"{webApiServer.OMVOfficeListingApi}/Roles/",
                        content,
                        cancellationToken);

                if (!response.IsSuccessStatusCode)
                {
                    var postresponse = await response.Content.ReadAsStringAsync();
                    if (!string.IsNullOrEmpty(postresponse))
                        throw new InvalidOperationException(postresponse);
                }
                response.EnsureSuccessStatusCode();

                var stringResult = await response.Content.ReadAsStringAsync();
                var role = JsonConvert.DeserializeObject<Role>(stringResult);

                return role;
            }
        }
    }
}
