﻿using MediatR;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;
using OMV.Admin.Infrastructure.Requests;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Handlers
{
    public class ProgramFunctionsInquiryRequestHandler 
        : IRequestHandler<ProgramFunctionsInquiryRequest, IEnumerable<ProgramFunction>>
    {
        private readonly IProgramFunctionsService service;

        public ProgramFunctionsInquiryRequestHandler(IProgramFunctionsService service)
        {
            this.service = service;
        }


        public async Task<IEnumerable<ProgramFunction>> Handle(
            ProgramFunctionsInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await service.ProgramFunctionsInquiry();
        }
    }
}
