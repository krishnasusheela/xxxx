﻿using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Services
{
    public class ProgramFunctionsService : IProgramFunctionsService
    {
        private readonly HttpClient client;

        public ProgramFunctionsService(
            HttpClient client)
        {
            this.client = client;
        }

        public async Task<IEnumerable<ProgramFunction>> ProgramFunctionsInquiry()
        {
            var uri = $"/api/programfunctions";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var responseObject = JsonConvert.DeserializeObject<IEnumerable<ProgramFunction>>(stringResult);

            return responseObject;
        }
    }
}