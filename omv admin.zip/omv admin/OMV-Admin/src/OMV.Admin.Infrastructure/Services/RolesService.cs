﻿using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Services
{
    public class RolesService : IRolesService
    {
        private readonly HttpClient client;

        public RolesService(
            HttpClient client)
        {
            this.client = client;
        }

        public async Task<IEnumerable<Role>> RolesInquiry()
        {
            var uri = $"/api/Roles";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var roles = JsonConvert.DeserializeObject<IEnumerable<Role>>(stringResult);

            return roles;
        }

        public async Task<Role> RoleInquiry( int id )
        {
            var uri = $"/api/Roles/{id}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var role = JsonConvert.DeserializeObject<Role>(stringResult);

            return role;

        }
    }
}
