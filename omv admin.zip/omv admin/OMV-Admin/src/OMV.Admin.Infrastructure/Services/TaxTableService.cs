﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;

namespace OMV.Admin.Infrastructure.Services
{
    public class TaxTableService
        : ITaxTableService
    {
        private readonly HttpClient client;

        public TaxTableService(
            HttpClient client)
        {
            this.client = client;
        }

        public async Task<Domicile> GetDomicileByCode(string domicileCode)
        {
            var uri = $"/api/domicilecodes/{domicileCode}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var domicile = JsonConvert.DeserializeObject<Domicile>(stringResult);

            return domicile;
        }

        public async Task<Domicile> GetDomicileByIdAndDate(int id, DateTimeOffset date)
        {
            var uri = $"/api/domiciles/{id}?date={date.ToString("yyyy-MM-dd")}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var domicile = JsonConvert.DeserializeObject<Domicile>(stringResult);

            return domicile;
        }
    }
}
