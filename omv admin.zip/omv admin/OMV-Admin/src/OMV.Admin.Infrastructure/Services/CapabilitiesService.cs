﻿using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace OMV.Admin.Infrastructure.Services
{
    public class CapabilitiesService : ICapabilitiesService
    {
        private readonly HttpClient client;

        public CapabilitiesService(
            HttpClient client)
        {
            this.client = client;
        }

        public async Task<IEnumerable<Capability>> CapabilitiesInquiry()
        {
            var uri = $"/api/capabilities";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var responseObject = JsonConvert.DeserializeObject<IEnumerable<Capability>>(stringResult);

            return responseObject;
        }
    }
}
