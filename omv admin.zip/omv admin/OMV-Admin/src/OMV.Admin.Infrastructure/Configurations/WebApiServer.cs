﻿namespace OMV.Admin.Infrastructure.Configurations
{
    public class WebApiServer
    {
        public string OMVOfficeListingApi { get; set; }
        public string ParishTaxTableApi { get; set; }
    }
}
