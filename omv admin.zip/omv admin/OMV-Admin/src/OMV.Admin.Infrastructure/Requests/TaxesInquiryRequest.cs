﻿using MediatR;
using OMV.Admin.Core.Entities;

namespace OMV.Admin.Infrastructure.Requests
{
    public class TaxesInquiryRequest 
        : IRequest<Domicile>
    {
        public string DomicileCode { get; set; }
    }
}
