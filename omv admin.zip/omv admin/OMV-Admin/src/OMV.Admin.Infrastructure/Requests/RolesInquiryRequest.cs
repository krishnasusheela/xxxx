﻿using MediatR;
using OMV.Admin.Core.Entities;
using System.Collections.Generic;

namespace OMV.Admin.Infrastructure.Requests
{
    public class RolesInquiryRequest : IRequest<IEnumerable<Role>>
    {
    }
}
