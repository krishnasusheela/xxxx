﻿using MediatR;
using OMV.Admin.Core.Entities;

namespace OMV.Admin.Infrastructure.Requests
{
    public class RoleInquiryRequest : IRequest<Role>
    {
        public int Id { get; set; }
    }
}
