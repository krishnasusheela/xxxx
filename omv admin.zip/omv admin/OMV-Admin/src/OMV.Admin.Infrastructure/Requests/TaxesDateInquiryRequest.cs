﻿using MediatR;
using OMV.Admin.Core.Entities;
using System;

namespace OMV.Admin.Infrastructure.Requests
{
    public class TaxesDateInquiryRequest
        : IRequest<Domicile>
    {
        public int DomicileId { get; set; }
        public DateTimeOffset Date { get; set; }
    }
}
