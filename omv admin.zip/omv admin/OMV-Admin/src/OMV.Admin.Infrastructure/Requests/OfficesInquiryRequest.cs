﻿using MediatR;
using OMV.Admin.Core.Entities;

namespace OMV.Admin.Infrastructure.Requests
{
    public class OfficesInquiryRequest : IRequest<Office>
    {
        public int Id { get; set; }
    }
}