﻿using MediatR;
using OMV.Admin.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMV.Admin.Infrastructure.Requests
{
    public class RoleCreateRequest : IRequest<Role>
    {
        public RoleCreate role { get; set; }


    }
}
