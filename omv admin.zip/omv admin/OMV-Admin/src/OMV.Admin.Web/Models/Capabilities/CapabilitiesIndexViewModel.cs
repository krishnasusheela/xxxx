﻿using Microsoft.AspNetCore.Mvc.Rendering;
using OMV.Admin.Core.Entities;
using System;
using System.Collections.Generic;

namespace OMV.Admin.Web.Models.Capabilities
{
    public class CapabilitiesIndexViewModel
    {
        public IEnumerable<Capability> Capabilities { get; set; }
        public IEnumerable<SelectListItem> OfficeTypeSelectListItems { get; set; }
        public IEnumerable<SelectListItem> ProgramFunctionSelectListItems { get; set; }
    }
}
