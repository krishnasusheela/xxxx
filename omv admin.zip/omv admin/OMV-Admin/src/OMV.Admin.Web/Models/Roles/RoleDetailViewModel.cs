﻿using OMV.Admin.Core.Entities;

namespace OMV.Admin.Web.Models.Roles
{
    public class RoleDetailViewModel
    {
        public Role Role { get; set; }
    }
}
