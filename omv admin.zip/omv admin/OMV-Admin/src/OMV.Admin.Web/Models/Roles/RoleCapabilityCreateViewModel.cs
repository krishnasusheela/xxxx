﻿using OMV.Admin.Core.Entities;
using System;
using System.ComponentModel.DataAnnotations;
using OMV.Admin.Core.Helpers;

namespace OMV.Admin.Web.Models.Roles
{
    public class RoleCapabilityCreateViewModel
    {
        [Required]
        [Display(Name = "Effective Date")]
        public DateTimeOffset? EffectiveDate { get; set; }
        [Display(Name = "Expiration Date")]
        public DateTimeOffset? ExpireDate { get; set; }
        public Capability Capability { get; set; }
        public string DisplayedEffectiveDate => EffectiveDate.ToDisplayDateString();
        public string DisplayedExpireDate => ExpireDate.ToDisplayDateString();
    }
}
