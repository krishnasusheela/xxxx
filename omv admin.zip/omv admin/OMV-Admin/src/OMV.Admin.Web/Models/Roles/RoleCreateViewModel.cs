﻿using Microsoft.AspNetCore.Mvc.Rendering;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OMV.Admin.Web.Models.Roles
{
    public class RoleCreateViewModel
    { 
        public IList<ProgramFunction> ProgramFunctions { get; set; }

        [Required(ErrorMessage = "You must enter a name for this role.")]
        [StringLength(100, ErrorMessage ="Role name cannot exceed 100 characters.")]
        [Display(Name="Name of Role")]
        public string Name { get; set; }

        [Required(ErrorMessage = "You must enter a description for this role.")]
        [StringLength(500, ErrorMessage = "Role description cannot exceed 500 characters.")]
        [Display(Name = "Description of Role")]
        public string Description { get; set; }

        [StringLength(500, ErrorMessage = "Role public description cannot exceed 500 characters.")]
        [Display(Name = "Public Description")]
        public string PublicDescription { get; set; }

        [Required(ErrorMessage ="You must enter an effective date for this role.")]
        [Display(Name="Effective Date")]
        public DateTimeOffset? EffectiveDate { get; set; }

        [Display(Name = "Expiration Date")]
        public DateTimeOffset? ExpireDate { get; set; }

        [Range(1,int.MaxValue,ErrorMessage="Please select a valid program function.")]
        [Display(Name = "Program Functions")]
        public int ProgramFunctionId { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Please select a valid office type.")]
        [Display(Name = "Office Type")]
        public int OfficeTypeId { get; set; }   

        public IList<SelectListItem> ProgramFunctionListItems { get; set; }
        public IList<SelectListItem> OfficeTypeListItems { get; set; }

        [Display(Name = "Make Public Description Available")]
        public Boolean IsPublic { get; set; }

    }
}
