﻿using OMV.Admin.Core.Entities;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;


namespace OMV.Admin.Web.Models.Roles
{
    public class RoleIndexViewModel
    {
        public IEnumerable<Role> Roles { get; set; }

        public IEnumerable<SelectListItem> OfficeTypeSelectListItems { get; set; }
        public IEnumerable<SelectListItem> ProgramFunctionSelectListItems { get; set; }

    }
}
