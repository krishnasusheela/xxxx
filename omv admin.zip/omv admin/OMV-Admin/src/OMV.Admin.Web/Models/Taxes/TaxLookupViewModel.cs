﻿using OMV.Admin.Core.Entities;
using System;
using System.ComponentModel.DataAnnotations;

namespace OMV.Admin.Web.Models.Taxes
{
    public class TaxLookupViewModel
    {
        [Display(Name = "Historical Search")]
        public DateTimeOffset? SearchDate { get; set; }
        [Required(ErrorMessage = "Please enter a valid domicile code.")]
        [RegularExpression(@"^\d{4}$", ErrorMessage = "Please enter a valid domicile code.")]
        public string SearchCode { get; set; }
        public Domicile Domicile { get; set; }

        public string DisplayedDomicileCode => $"{Domicile?.CombinedCode} - {Domicile?.Name}";
        public string DisplayedCollectionRate => Domicile?.CollectionRate.ToString("p2");
        public string DisplayedParishCollectionRate => Domicile?.ParishCollectionRate.ToString("p2");
        public string DisplayedMunicipalityCollectionRate => Domicile?.MunicipalityCollectionRate.ToString("p2");
        public string DisplayedVendorCompensation => Domicile?.VendorCompensation.ToString("p2");
        public string DisplayedEffectiveDate => Domicile?.EffectiveDate.ToString("yyyy-MM-dd");
        public string DisplayedTermDate => Domicile?.TermDate?.ToString("yyyy-MM-dd");
        public string DisplayedSearchDate => SearchDate?.ToString("yyyy-MM-dd");
    }
}
