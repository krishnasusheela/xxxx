﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OMV.Admin.Web.Models.Offices
{
    public class OfficesIndexViewModel
    {
        public IEnumerable<OfficesBriefModel> Offices;
    }
}