﻿using OMV.Admin.Core.Entities;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace OMV.Admin.Web.Models.Offices
{
    public class OfficesBriefModel
    {
        public int Id { get; set; }
        public int ParishId { get; set; }

        [Display(Name = "Parish Name")]
        public string ParishName { get; set; }
        [Display(Name = "Office Name")]
        public string OfficeName { get; set; }
        [Display(Name = "Office Number")]
        public string OfficeNumber { get; set; }


        public string PhysicalAddress1 { get; set; }
        public string PhysicalAddress2 { get; set; }
        public string PhysicalCity { get; set; }
        public string PhysicalState { get; set; }
        public string PhysicalZip { get; set; }
        public string PhysicalZip4 { get; set; }

        public IEnumerable<PhoneNumber> PhoneNumbers { get; set; }

        public PhoneNumber DisplayedPhoneNumber()
        {
            if (PhoneNumbers == null)
                return null;

            return PhoneNumbers.Where(x => x.PhoneNumberType.Type == "Private").FirstOrDefault() ??
                   PhoneNumbers.Where(x => x.PhoneNumberType.Type == "Public").FirstOrDefault();
        }
    }
}