﻿using OMV.Admin.Core.Entities;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OMV.Admin.Web.Models.Offices
{
    public class OfficesDetailViewModel
    {
        public int Id { get; set; }

        [Display(Name = "Parish Name")]
        public string ParishName { get; set; }
        [Display(Name = "Region Name")]
        public string RegionName { get; set; }
        [Display(Name = "Office Type")]
        public string OfficeType { get; set; }
        [Display(Name = "Inventory Fulfillment Center")]
        public string InventoryFulfillmentCenter { get; set; }
        [Display(Name = "Office Name")]
        public string OfficeName { get; set; }
        [Display(Name = "Office Number")]
        public string OfficeNumber { get; set; }
        [Display(Name = "Physical Address")]
        public string PhysicalAddress1 { get; set; }
        public string PhysicalAddress2 { get; set; }

        public string PhysicalCity { get; set; }
        public string PhysicalState { get; set; }
        public string PhysicalZip { get; set; }
        public string PhysicalZip4 { get; set; }

        public string MailingRecipient { get; set; }
        [Display(Name = "Mailing Address")]
        public string MailingAddress1 { get; set; }
        public string MailingAddress2 { get; set; }

        public string MailingCity { get; set; }
        public string MailingState { get; set; }
        public string MailingZip { get; set; }
        public string MailingZip4 { get; set; }

        [Display(Name = "Office Manager")]
        public string OfficeManager { get; set; }
        [Display(Name = "Regional Manager")]
        public string RegionalManager { get; set; }

        [Display(Name = "Hours of Operation")]
        public string HoursOperation { get; set; }
        [Display(Name = "Days of Operation")]
        public string DaysOperation { get; set; }


        [Display(Name = "Capability Roles")]
        public string CapabilityRoles { get; set; }
        [Display(Name = "Map Directions")]
        public string MapDirections { get; set; }
        [Display(Name = "Road Skills Schedule")]
        public string RoadSkillsSchedule { get; set; }
        [Display(Name = "Office Total Operators")]
        public string OfficeTotalOperators { get; set; }
        [Display(Name = "Status")]
        public string Status { get; set; }
        [Display(Name = "EFT Code")]
        public string EftCode { get; set; }
        [Display(Name ="Phone Numbers")]
        public IEnumerable<PhoneNumber> PhoneNumbers { get; set; }

        public string DisplayedPhysicalCityStateZip => DisplayedCityStateZip(PhysicalCity, PhysicalState, PhysicalZip, PhysicalZip4);
        public string DisplayedMailingCityStateZip => DisplayedCityStateZip(MailingCity, MailingState, MailingZip, MailingZip4);

        public string DisplayedCityStateZip(string city, string state, string zip, string zip4)
        {
            if (string.IsNullOrEmpty(city))
                return "";
            else if (string.IsNullOrEmpty(zip4))
                return string.Format("{0}, {1}, {2}", city, state, zip);
            else
                return string.Format("{0}, {1}, {2}-{3}", city, state, zip, zip4);
        }
    }
}