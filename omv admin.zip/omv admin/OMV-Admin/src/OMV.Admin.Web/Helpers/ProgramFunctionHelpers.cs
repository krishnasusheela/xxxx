﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using OMV.Admin.Core.Entities;

namespace OMV.Admin.Web.Helpers
{
    public static class ProgramFunctionHelpers
    {
        public static IEnumerable<SelectListItem> ToSelectListItems(this IEnumerable<ProgramFunction> programFunctions)
        {
            return programFunctions
                .OrderBy(x => x.Id)
                .Select(rcd => new SelectListItem
                {
                    Value = rcd.Id.ToString(),
                    Text = rcd.Code + " - " + rcd.Name
                });
        }

        public static IEnumerable<SelectListItem> ToAbbrSelectListItems(this IEnumerable<ProgramFunction> programFunctions)
        {
            return programFunctions
                .OrderBy(x => x.Id)
                .Select(rcd => new SelectListItem
                {
                    Value = (rcd.Id).ToString(),
                    Text = $"{rcd.Code}"
                });
        }
    }
}
