﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using OMV.Admin.Core.Entities;

namespace OMV.Admin.Web.Helpers
{
    public static class OfficeTypeHelpers
    {
        public static IEnumerable<SelectListItem> ToSelectListItems(this IEnumerable<OfficeType> officeTypes)
        {
            return officeTypes
                .OrderBy(x => x.Id)
                .Select(rcd => new SelectListItem
                {
                    Value = rcd.Id.ToString(),
                    Text = rcd.Code
                });
        }

        public static IEnumerable<OfficeType> ValidForRoles(this IEnumerable<OfficeType> officeTypes)
        {
            return officeTypes
                .Where(x => x.IsValidForRole == true);
        }

        public static string ToIdCsvString(this IEnumerable<OfficeType> officeTypes)
        {
            return string.Join(",", officeTypes.Select(x => x.Id.ToString()).ToList());
        }
    }
}
