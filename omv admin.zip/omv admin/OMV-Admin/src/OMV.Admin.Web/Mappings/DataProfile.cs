﻿using AutoMapper;
using OMV.Admin.Core.Entities;
using OMV.Admin.Web.Models.Offices;

namespace OMV.Admin.Web.Mappings
{
    public class DataProfile : Profile
    {
        public DataProfile()
        {
            CreateMap<Office, OfficesIndexViewModel>();
            CreateMap<Office, OfficesBriefModel>();
            CreateMap<Office, OfficesDetailViewModel>()
                .ForMember(
                    dest => dest.ParishName,
                    opt => opt.MapFrom(src => src.Parish.Name))
                .ForMember(
                    dest => dest.RegionName,
                    opt => opt.MapFrom(src => src.Region.Name))
                .ForMember(
                    dest => dest.OfficeType,
                    opt => opt.MapFrom(src => src.OfficeType.Name));
        }
    }
}
