﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Web.Helpers;
using OMV.Admin.Web.Models.Capabilities;
using System.Linq;
using System.Threading.Tasks;

namespace OMV.Admin.Web.Controllers
{
    public class CapabilitiesController : Controller
    {
        private readonly IMapper mapper;
        private readonly IMediator mediator;

        public CapabilitiesController(IMediator mediator, IMapper mapper)
        {
            this.mediator = mediator;
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var result = await mediator.Send(new CapabilitiesInquiryRequest());
            var officeTypes = await mediator.Send(new OfficeTypesInquiryRequest());
            var programFunctions = await mediator.Send(new ProgramFunctionsInquiryRequest());
            
            var model = new CapabilitiesIndexViewModel()
            {
                Capabilities = result.OrderBy(x => x.Name),
                OfficeTypeSelectListItems = officeTypes.ValidForRoles().ToSelectListItems().ToList(),
                ProgramFunctionSelectListItems = programFunctions.ToSelectListItems().ToList()
            };
            
            return View(model);
        }



    }
}
