﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Web.Models.Roles;
using OMV.Admin.Web.Models.Shared;
using OMV.Admin.Web.Helpers;

namespace OMV.Admin.Web.Controllers
{
    public class RolesController : Controller
    {

        private readonly IMediator mediator;

        public RolesController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        public async Task<IActionResult> Index()
        {
            var roles = await mediator.Send(new RolesInquiryRequest());
            var officeTypes = await mediator.Send(new OfficeTypesInquiryRequest());
            var programFunctions = await mediator.Send(new ProgramFunctionsInquiryRequest());

            var viewModel = new RoleIndexViewModel
            {
                OfficeTypeSelectListItems = officeTypes.ValidForRoles().ToSelectListItems().ToList(),
                ProgramFunctionSelectListItems = programFunctions.ToSelectListItems().ToList(),
                Roles = roles.OrderBy(p => p.Name)
            };

            return View(viewModel);
        }

        public async Task<IActionResult> Detail(int id)
        {
            var result = await mediator.Send(new RoleInquiryRequest { Id = id });

            var viewModel = new RoleDetailViewModel
            {
                Role = result
            };

            return View(viewModel);

        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var programFunctions = await mediator.Send(new ProgramFunctionsInquiryRequest());
            var officeTypes = await mediator.Send(new OfficeTypesInquiryRequest());

            var viewModel = new RoleCreateViewModel
            {
                ProgramFunctionListItems = programFunctions.ToAbbrSelectListItems().ToList(),
                OfficeTypeListItems = officeTypes.ValidForRoles().ToSelectListItems().ToList()
            };

            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Create(RoleCreateViewModel roleCreateViewModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await mediator.Send(new RoleCreateRequest()
                    {
                        role = new RoleCreate()
                        {
                            Name = roleCreateViewModel.Name.Trim(),
                            Description = roleCreateViewModel.Description,
                            PublicDescription = roleCreateViewModel.PublicDescription,
                            IsPublic = roleCreateViewModel.IsPublic,
                            EffectiveDate = roleCreateViewModel.EffectiveDate.Value,
                            ExpireDate = roleCreateViewModel.ExpireDate,
                            OfficeTypeId = roleCreateViewModel.OfficeTypeId,
                            ProgramFunctionId = roleCreateViewModel.ProgramFunctionId
                        }
                    });
                    return RedirectToAction("Index", "Roles");
                }

                catch (InvalidOperationException e)
                {
                    ModelState.AddModelError(string.Empty, e.Message);
                }
            }

            var programFunctions = await mediator.Send(new ProgramFunctionsInquiryRequest());
            var officeTypes = await mediator.Send(new OfficeTypesInquiryRequest());

            roleCreateViewModel.ProgramFunctionListItems = programFunctions.ToAbbrSelectListItems().ToList();
            roleCreateViewModel.OfficeTypeListItems = officeTypes.ValidForRoles().ToSelectListItems().ToList();

            return View(roleCreateViewModel);
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
