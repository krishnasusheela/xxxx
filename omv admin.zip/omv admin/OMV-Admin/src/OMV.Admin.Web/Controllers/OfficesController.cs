﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Web.Models.Offices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OMV.Admin.Web.Controllers
{
    public class OfficesController : Controller
    {
        private readonly IMapper mapper;
        private readonly IMediator mediator;

        public OfficesController(IMediator mediator, IMapper mapper)
        {
            this.mediator = mediator;
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            try
            {
                var result = await mediator.Send(new OfficesIndexRequest());

                var indexModels = mapper.Map<IEnumerable<OfficesBriefModel>>(result);

                var model = new OfficesIndexViewModel()
                {
                    Offices = indexModels.OrderBy(x => x.ParishName).ThenBy(x => x.OfficeName)
                };

                return View(model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        public async Task<IActionResult> Detail(int id)
        {
            try
            {
                var result = await mediator.Send(new OfficesInquiryRequest { Id = id });
                
                var model = mapper.Map<OfficesDetailViewModel>(result);

                return View(model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
