﻿using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Web.Models.Taxes;

namespace OMV.Admin.Web.Controllers
{
    public class TaxesController 
        : Controller
    {
        private readonly IMediator mediator;

        public TaxesController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        public IActionResult Index()
        {
            var viewModel = new TaxLookupViewModel();
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(
            TaxLookupViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                if (viewModel.SearchDate.HasValue)
                {
                    var requestWithDate = new TaxesDateInquiryRequest
                    {
                        DomicileId = viewModel.Domicile.Id,
                        Date = viewModel.SearchDate.Value
                    };

                    var domicileWithDate = await mediator.Send(
                        requestWithDate);

                    if (domicileWithDate != null)
                    {
                        viewModel.Domicile = domicileWithDate;
                    }
                    else
                    {
                        ModelState.AddModelError("SearchDate", "No active domicile for this date.");
                        viewModel.SearchDate = null;
                    }
                }
                
                if (!viewModel.SearchDate.HasValue)
                {
                    var request = new TaxesInquiryRequest
                    {
                        DomicileCode = viewModel.SearchCode
                    };

                    var domicile = await mediator.Send(
                        request);

                    if (domicile == null)
                    {
                        ModelState.AddModelError("SearchCode", "Please enter a valid domicile code.");
                    }

                    viewModel.Domicile = domicile;
                }
            }

            return View(viewModel);
        }
    }
}