﻿using System.Reflection;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Infrastructure.Configurations;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using OMV.Admin.Core.Interfaces;
using OMV.Admin.Infrastructure.Services;
using System;

namespace OMV.Admin.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMediatR(
                typeof(RolesInquiryRequest)
                .GetTypeInfo()
                .Assembly);

            services.Configure<WebApiServer>(Configuration.GetSection("WebApiServer"));

            services.AddHttpClient<ITaxTableService, TaxTableService>(client =>
                client.BaseAddress = new Uri(Configuration["WebApiServer:ParishTaxTableApi"]));
            services.AddHttpClient<ICapabilitiesService, CapabilitiesService>(client =>
                client.BaseAddress = new Uri(Configuration["WebApiServer:OMVOfficeListingApi"]));
            services.AddHttpClient<IRolesService, RolesService>(client =>
                client.BaseAddress = new Uri(Configuration["WebApiServer:OMVOfficeListingApi"]));
            services.AddHttpClient<IProgramFunctionsService, ProgramFunctionsService>(client =>
                client.BaseAddress = new Uri(Configuration["WebApiServer:OMVOfficeListingApi"]));
            services.AddHttpClient<IOfficeTypesService, OfficeTypesService>(client =>
                client.BaseAddress = new Uri(Configuration["WebApiServer:OMVOfficeListingApi"]));

            services.AddAutoMapper();
            services
                .AddMvc()
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
