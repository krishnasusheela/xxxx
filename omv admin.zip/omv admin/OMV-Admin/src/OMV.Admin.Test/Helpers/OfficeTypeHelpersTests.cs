﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoFixture;
using Microsoft.AspNetCore.Mvc.Rendering;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Helpers;
using OMV.Admin.Web.Helpers;
using Xunit;

namespace OMV.Admin.Test.Helpers
{
    public class OfficeTypeHelpersTests : IDisposable
    {
        private Fixture fixture;

        public OfficeTypeHelpersTests()
        {
            this.fixture = new Fixture();
        }

        public void Dispose()
        {
            fixture = null;
        }

        [Fact]
        public void ToSelectListItemsReturnsSelectListItems()
        {
            var officeTypes = fixture.Create<IEnumerable<OfficeType>>();
            var expected = officeTypes
                .OrderBy(x => x.Id)
                .Select(rcd => new SelectListItem
                {
                    Value = rcd.Id.ToString(),
                    Text = rcd.Code
                });

            var result = officeTypes.ToSelectListItems();
            Assert.Equal(expected.FirstOrDefault().Value, result.FirstOrDefault().Value);
            Assert.Equal(expected.LastOrDefault().Value, result.LastOrDefault().Value);
        }

        [Fact]
        public void ValidForRolesReturnsOfficeTypesValidForRoles()
        {
            var officeTypes = fixture.Create<IEnumerable<OfficeType>>();
            var expected = officeTypes
                .Where(x => x.IsValidForRole == true);

            var result = officeTypes.ValidForRoles();
            Assert.Equal(expected, result);
        }

        [Fact]
        public void CommaDelimitedConcatenationReturnsString()
        {
            List<OfficeType> expected = new List<OfficeType>();

            expected.Add(fixture.Build<OfficeType>()
                   .With(x => x.Id, 1)
                   .Create());
            expected.Add(fixture.Build<OfficeType>()
                   .With(x => x.Id, 2)
                   .Create());
            expected.Add(fixture.Build<OfficeType>()
                   .With(x => x.Id, 3)
                   .Create());

            var result = expected.ToIdCsvString();

            Assert.False(String.IsNullOrEmpty(result));
            Assert.Equal("1,2,3", result);
        }

    }


}
