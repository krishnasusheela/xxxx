﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoFixture;
using Microsoft.AspNetCore.Mvc.Rendering;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Helpers;
using OMV.Admin.Web.Helpers;
using Xunit;

namespace OMV.Admin.Test.Helpers
{
    public class ProgramFunctionHelpersTests : IDisposable
    {
        private Fixture fixture;

        public ProgramFunctionHelpersTests()
        {
            this.fixture = new Fixture();
        }

        public void Dispose()
        {
            fixture = null;
        }

        [Fact]
        public void ToSelectListItemsReturnsSelectListItems()
        {
            var programFunctions = fixture.Create<IEnumerable<ProgramFunction>>();
            var expected = programFunctions
                .OrderBy(x => x.Id)
                .Select(rcd => new SelectListItem
                {
                    Value = rcd.Id.ToString(),
                    Text = rcd.Code + " - " + rcd.Name
                });

            var result = programFunctions.ToSelectListItems();
            Assert.Equal(expected.FirstOrDefault().Value, result.FirstOrDefault().Value);
            Assert.Equal(expected.LastOrDefault().Value, result.LastOrDefault().Value);
        }

        [Fact]
        public void ToAbbrSelectListItemsReturnsAbbrSelectListItems()
        {
            var programFunctions = fixture.Create<IEnumerable<ProgramFunction>>();
            var expected = programFunctions
                .OrderBy(x => x.Id)
                .Select(rcd => new SelectListItem
                {
                    Value = (rcd.Id).ToString(),
                    Text = $"{rcd.Code}"
                });

            var result = programFunctions.ToAbbrSelectListItems();
            Assert.Equal(expected.FirstOrDefault().Value, result.FirstOrDefault().Value);
            Assert.Equal(expected.LastOrDefault().Value, result.LastOrDefault().Value);
        }

    }


}
