﻿using System;
using AutoFixture;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Helpers;
using Xunit;

namespace OMV.Admin.Test.Helpers
{
    public class RoleCapabilityHelpersTests : IDisposable
    {
        private Fixture fixture;

        public RoleCapabilityHelpersTests()
        {
            this.fixture = new Fixture();
        }

        public void Dispose()
        {
            fixture = null;
        }

        [Fact]
        public void IsRoleCapabilityActiveReturnsTrueForActiveRoleCapability()
        {
            var expected = fixture.Build<RoleCapability>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-1))
                .With(p => p.ExpireDate, DateTimeOffset.Now.AddDays(1))
                .Create();

            var result = expected.IsRoleCapabilityActive();
            Assert.True(result);
        }

        [Fact]
        public void IsRoleCapabilityActiveReturnsFalseForInactiveRoleCapability()
        {
            var expected = fixture.Build<RoleCapability>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(-5))
                .With(p => p.ExpireDate, DateTimeOffset.Now.AddDays(-1))
                .Create();

            var result = expected.IsRoleCapabilityActive();
            Assert.False(result);
        }

    }


}
