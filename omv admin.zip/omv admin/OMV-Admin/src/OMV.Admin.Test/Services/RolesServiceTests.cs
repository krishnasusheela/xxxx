﻿using AutoFixture;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace OMV.Admin.Test.Services
{
    public class RolesServiceTests : IDisposable
    {
        private Fixture fixture;
        private RolesService service;
        private Mock<HttpMessageHandler> httpMock;
        private HttpClient clientMock;

        public RolesServiceTests()
        {
            fixture = new Fixture();
            httpMock = new Mock<HttpMessageHandler>();
            clientMock = new HttpClient(httpMock.Object)
            {
                BaseAddress = new Uri("http://test.com/")
            };
            service = new RolesService(clientMock);
        }

        public void Dispose()
        {
            fixture = null;
            httpMock = null;
            clientMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(service);
        }

        [Fact]
        public async void RolesInquiryReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expectedCode = fixture.Create<string>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.RolesInquiry());

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(exception);
        }

        [Fact]
        public async void RolesInquiryDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<IEnumerable<Role>>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.RolesInquiry());

            Assert.Null(exception);
        }

        [Fact]
        public async void RolesInquiryReturnsExpectedCollectionOfRoles()
        {
            var expected = fixture.Create<IEnumerable<Role>>();
            var expectedIds = expected.Select<Role, int>(id => id.Id);

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var result = await service.RolesInquiry();

            var resultCollection = Assert.IsAssignableFrom<IEnumerable<Role>>(result);
            Assert.Equal(expected.Count(), resultCollection.Count());
            Assert.All(resultCollection, o => Assert.Contains(o.Id, expectedIds));
        }

        [Fact]
        public async void RoleInquiryReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expectedCode = fixture.Create<string>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.RolesInquiry());

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(exception);
        }

        [Fact]
        public async void RoleInquiryDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<IEnumerable<Role>>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.RolesInquiry());

            Assert.Null(exception);
        }
    }
}
