﻿using AutoFixture;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace OMV.Admin.Test.Services
{
    public class CapabilitiesServiceTests : IDisposable
    {
        private Fixture fixture;
        private CapabilitiesService service;
        private Mock<HttpMessageHandler> httpMock;
        private HttpClient clientMock;

        public CapabilitiesServiceTests()
        {
            fixture = new Fixture();
            httpMock = new Mock<HttpMessageHandler>();
            clientMock = new HttpClient(httpMock.Object)
            {
                BaseAddress = new Uri("http://test.com/")
            };
            service = new CapabilitiesService(clientMock);
        }

        public void Dispose()
        {
            fixture = null;
            httpMock = null;
            clientMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(service);
        }

        [Fact]
        public async void CapabilitiesInquiryReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expectedCode = fixture.Create<string>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.CapabilitiesInquiry());

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(exception);
        }

        [Fact]
        public async void CapabilitiesInquiryDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<IEnumerable<Capability>>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.CapabilitiesInquiry());
            
            Assert.Null(exception);
        }

        [Fact]
        public async void CapabilitiesInquiryReturnsExpectedCollectionOfCapabilities()
        {
            var expected = fixture.Create<IEnumerable<Capability>>();
            var expectedIds = expected.Select<Capability, int>(id => id.Id);

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var result = await service.CapabilitiesInquiry();

            var resultCollection = Assert.IsAssignableFrom<IEnumerable<Capability>>(result);
            Assert.Equal(expected.Count(), resultCollection.Count());
            Assert.All(resultCollection, o => Assert.Contains(o.Id, expectedIds));
        }
    }
}
