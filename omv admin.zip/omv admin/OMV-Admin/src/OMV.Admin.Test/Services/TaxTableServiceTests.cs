﻿using AutoFixture;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Services;
using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace OMV.Admin.Test.Services
{
    public class TaxTableServiceTests
        : IDisposable
    {
        private Fixture fixture;
        private TaxTableService service;
        private Mock<HttpMessageHandler> httpMock;
        private HttpClient clientMock;

        public TaxTableServiceTests()
        {
            fixture = new Fixture();
            httpMock = new Mock<HttpMessageHandler>();
            clientMock = new HttpClient(httpMock.Object)
            {
                BaseAddress = new Uri("http://test.com/")
            };
            service = new TaxTableService(clientMock);
        }

        public void Dispose()
        {
            fixture = null;
            httpMock = null;
            clientMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(service);
        }

        [Fact]
        public async void GetDomicileByCodeReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expectedCode = fixture.Create<string>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.GetDomicileByCode(expectedCode));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void GetDomicileByCodeDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expectedCode = fixture.Create<string>();
            var expectedDomicile = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expectedDomicile))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.GetDomicileByCode(expectedCode));

            Assert.Null(exception);
        }

        [Fact]
        public async void GetDomicileByIdAndDateReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expectedId = fixture.Create<int>();
            var expectedDate = fixture.Create<DateTimeOffset>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.GetDomicileByIdAndDate(expectedId, expectedDate));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void GetDomicileByCodeAndIdDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expectedId = fixture.Create<int>();
            var expectedDate = fixture.Create<DateTimeOffset>();
            var expectedDomicile = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expectedDomicile))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.GetDomicileByIdAndDate(expectedId, expectedDate));

            Assert.Null(exception);
        }
    }
}
