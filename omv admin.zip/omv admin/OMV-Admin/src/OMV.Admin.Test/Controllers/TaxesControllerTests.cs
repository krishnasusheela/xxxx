﻿using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Web.Controllers;
using OMV.Admin.Web.Models.Taxes;
using System;
using System.Threading.Tasks;
using Xunit;

namespace OMV.Admin.Test.Controllers
{
    public class TaxesControllerTests
        : IDisposable
    {
        private Fixture fixture;
        private TaxesController controller;
        private Mock<IMediator> mediatorMock;

        public TaxesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller = new TaxesController(mediatorMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            mediatorMock = null;
            controller = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task IndexReturnsExpectedResultForDomicileCode()
        {
            var expected = fixture.Create<Domicile>();
            var viewModel = fixture.Build<TaxLookupViewModel>()
                .With(p => p.SearchCode, expected.CombinedCode)
                .Without(p => p.SearchDate)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<TaxesInquiryRequest>(p => p.DomicileCode == expected.CombinedCode),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result = await controller.Index(viewModel);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<TaxLookupViewModel>(viewResult.ViewData.Model);
            Assert.Equal(expected, model.Domicile);
        }

        [Fact]
        public async Task IndexReturnsExpectedResultForHistoricalSearch()
        {
            var expected = fixture.Create<Domicile>();
            var domicile = fixture.Build<Domicile>()
                .With(p => p.Id, expected.Id)
                .Create();
            var viewModel = fixture.Build<TaxLookupViewModel>()
                .With(p => p.SearchDate, DateTimeOffset.Now.Date)
                .With(p => p.Domicile, domicile)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<TaxesDateInquiryRequest>(p => (p.DomicileId == expected.Id && p.Date == DateTimeOffset.Now.Date)),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result = await controller.Index(viewModel);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<TaxLookupViewModel>(viewResult.ViewData.Model);
            Assert.Equal(expected, model.Domicile);
        }
    }
}
