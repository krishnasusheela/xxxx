﻿using AutoFixture;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Web.Controllers;
using OMV.Admin.Web.Models.Capabilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace OMV.Admin.Test.Controllers
{
    public class CapabilitiesControllerTests : IDisposable
    {
        private Fixture fixture;
        private CapabilitiesController controller;
        private Mock<IMediator> mediatorMock;
        private Mock<IMapper> mapperMock;

        public CapabilitiesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();
            mapperMock = new Mock<IMapper>();

            controller = new CapabilitiesController(mediatorMock.Object, mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            mediatorMock = null;
            controller = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task IndexReturnsViewResultWithAListOfCapabilities()
        {
            var expected = fixture.Create<List<Capability>>();
            var expectedViewModel = fixture.Build<CapabilitiesIndexViewModel>()
                .With(x => x.Capabilities, expected.OrderBy(x => x.Name))
            .Create();
            
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<CapabilitiesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result = await controller.Index();

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<CapabilitiesIndexViewModel>(viewResult.ViewData.Model);
            Assert.Equal(expectedViewModel.Capabilities, model.Capabilities);
        }

    }
}
