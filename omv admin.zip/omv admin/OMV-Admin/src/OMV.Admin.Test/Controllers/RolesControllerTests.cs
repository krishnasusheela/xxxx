﻿using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Web.Controllers;
using OMV.Admin.Web.Helpers;
using OMV.Admin.Web.Models.Roles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace OMV.Admin.Test.Controllers
{
    public class RolesControllerTests : IDisposable
    {
        private Fixture fixture;
        private RolesController controller;
        private Mock<IMediator> mediatorMock;

        public RolesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller = new RolesController(mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task IndexReturnsExpectedResultForRoles()
        {
            var expectedRoles = fixture.Create<IEnumerable<Role>>();
            var expectedProgramFunctions = fixture.Create<IEnumerable<ProgramFunction>>();
            var expectedOfficeTypes = fixture.Create<IEnumerable<OfficeType>>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<RolesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expectedRoles);

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ProgramFunctionsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expectedProgramFunctions);

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<OfficeTypesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expectedOfficeTypes);

            var result = await controller.Index();

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<RoleIndexViewModel>(viewResult.ViewData.Model);
            Assert.Equal(expectedRoles.OrderBy(p => p.Name), model.Roles);
            Assert.Equal(expectedProgramFunctions.ToSelectListItems().FirstOrDefault().Value, model.ProgramFunctionSelectListItems.FirstOrDefault().Value);
            Assert.Equal(expectedProgramFunctions.ToSelectListItems().LastOrDefault().Value, model.ProgramFunctionSelectListItems.LastOrDefault().Value);
            Assert.Equal(expectedOfficeTypes.ValidForRoles().ToSelectListItems().FirstOrDefault().Value, model.OfficeTypeSelectListItems.FirstOrDefault().Value);
            Assert.Equal(expectedOfficeTypes.ValidForRoles().ToSelectListItems().LastOrDefault().Value, model.OfficeTypeSelectListItems.LastOrDefault().Value);
        }

        [Fact]
        public async Task DetailsReturnsExpectedResultForRole()
        {
            var expected = fixture.Create<Role>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<RoleInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result = await controller.Detail(expected.Id);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<RoleDetailViewModel>(viewResult.ViewData.Model);
            Assert.Equal(expected, model.Role);
        }

        [Fact]
        public async Task CreateReturnsExpectedRole()
        {
            var expectedViewModel = fixture
                .Build<RoleCreateViewModel>()
                .Create();

            var expectedRole = fixture
                .Build<Role>()
                .With(x => x.Name, expectedViewModel.Name)
                .With(x => x.Description, expectedViewModel.Description)
                .With(x => x.EffectiveDate, expectedViewModel.EffectiveDate)
                .With(x => x.ExpireDate, expectedViewModel.ExpireDate)
                //TODO: This is broken .With(x => x.RoleCapabilities, expectedViewModel.CapabilitiesChosen)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<RoleCreateRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expectedRole);

            var result = await controller.Create(expectedViewModel);

            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", viewResult.ActionName);
            Assert.Equal("Roles", viewResult.ControllerName);

        }

    }
}
