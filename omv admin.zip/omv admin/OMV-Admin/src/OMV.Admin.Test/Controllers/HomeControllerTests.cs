﻿using OMV.Admin.Web.Controllers;
using System;
using Xunit;

namespace OMV.Admin.Test.Controllers
{
    public class HomeControllerTests : IDisposable
    {
        private HomeController controller;

        public HomeControllerTests()
        {
            controller = new HomeController();
        }

        public void Dispose()
        {
            controller = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }
    }
}
