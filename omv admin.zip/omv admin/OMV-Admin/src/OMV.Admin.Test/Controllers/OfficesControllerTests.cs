﻿using AutoFixture;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Web.Controllers;
using OMV.Admin.Web.Mappings;
using OMV.Admin.Web.Models.Offices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace OMV.Admin.Test.Controllers
{
    public class OfficesControllerTests : IDisposable
    {
        private Fixture fixture;
        private Mock<IMediator> mediatorMock;
        private Mock<IMapper> mapperMock;
        private IMapper mapper;
        private OfficesController controller;
        private OfficesController controllerWithMapper;
        
        public OfficesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();
            mapperMock = new Mock<IMapper>();
            mapper = new Mapper(new MapperConfiguration(cfg => cfg.AddProfile(new DataProfile())));
            controller = new OfficesController(mediatorMock.Object, mapperMock.Object);
            controllerWithMapper = new OfficesController(mediatorMock.Object, mapper);
        }

        public void Dispose()
        {
            fixture = null;
            mediatorMock = null;
            mapperMock = null;
            controller = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }
        
        [Fact]
        public async Task IndexReturnsViewResultWithAListOfOfficesMapperInjected()
        {
            var expectedEntity = fixture.Create<IEnumerable<Office>>();
            var indexViews = expectedEntity
                .Select(entity => GetAsIndexViewModel(entity))
                .OrderBy(x => x.ParishName)
                .ThenBy(x => x.OfficeName);
            var expectedView = new OfficesIndexViewModel()
            {
                Offices = indexViews
            };

            mediatorMock.Setup(m => m.Send(
                            It.IsAny<OfficesIndexRequest>(),
                            default(System.Threading.CancellationToken)))
                        .ReturnsAsync(expectedEntity);

            var result = await controllerWithMapper.Index();

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<OfficesIndexViewModel>(viewResult.ViewData.Model);
            Assert.IsAssignableFrom<IEnumerable<OfficesBriefModel>>(model.Offices);
            Assert.Equal(expectedEntity.Count(), model.Offices.Count());
            AssertAreEqualByJson(expectedView, model);
        }

        [Fact]
        public async Task IndexReturnsViewResultWithAListOfOfficesMapperMocked()
        {
            var expectedEntity = fixture.Create<IEnumerable<Office>>();
            var indexViews = expectedEntity
                .Select(entity => GetAsIndexViewModel(entity))
                .OrderBy(x => x.ParishName)
                .ThenBy(x => x.OfficeName);
            var expectedView = new OfficesIndexViewModel()
            {
                Offices = indexViews
            };

            mediatorMock.Setup(m => m.Send(
                            It.IsAny<OfficesIndexRequest>(),
                            default(System.Threading.CancellationToken)))
                        .ReturnsAsync(expectedEntity);

            mapperMock.Setup(x => x.Map<IEnumerable<OfficesBriefModel>>(It.IsAny<IEnumerable<Office>>()))
                .Returns(indexViews);

            var result = await controller.Index();

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<OfficesIndexViewModel>(viewResult.ViewData.Model);
            Assert.IsAssignableFrom<IEnumerable<OfficesBriefModel>>(model.Offices);
            Assert.Equal(expectedEntity.Count(), model.Offices.Count());
            AssertAreEqualByJson(expectedView, model);
        }

        [Fact]
        public async Task IndexReturnsBadRequestWhenMediatorThrowsException()
        {
            mediatorMock.Setup(m => m.Send(
                            It.IsAny<OfficesIndexRequest>(),
                            default(System.Threading.CancellationToken)))
                        .Throws(new Exception("Test Exception"));

            var result = await controller.Index();

            var resultObject = Assert.IsType<BadRequestObjectResult>(result);
            var badRequestObjectResult = result as BadRequestObjectResult;
        }

        [Fact]
        public async Task DetailsReturnsViewResultWithOfficeDetailsByOfficeIdMapperInjected()
        {
            var expectedEntity = fixture.Create<Office>();
            var expectedView = GetAsDetailViewModel(expectedEntity);

            mediatorMock.Setup(m => m.Send(
                            It.IsAny<OfficesInquiryRequest>(),
                            default(System.Threading.CancellationToken)))
                        .ReturnsAsync(expectedEntity);

            var result = await controllerWithMapper.Detail(expectedEntity.Id);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<OfficesDetailViewModel>(viewResult.ViewData.Model);
            AssertAreEqualByJson(expectedView, model);
        }

        [Fact]
        public async Task DetailsReturnsViewResultWithOfficeDetailsByOfficeIdMapperMocked()
        {
            var expectedEntity = fixture.Create<Office>();
            var expectedView = GetAsDetailViewModel(expectedEntity);

            mediatorMock.Setup(m => m.Send(
                            It.IsAny<OfficesInquiryRequest>(),
                            default(System.Threading.CancellationToken)))
                        .ReturnsAsync(expectedEntity);

            mapperMock.Setup(x => x.Map<OfficesDetailViewModel>(It.IsAny<Office>()))
                .Returns(expectedView);

            var result = await controller.Detail(expectedEntity.Id);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<OfficesDetailViewModel>(viewResult.ViewData.Model);
            Assert.Equal(expectedView, model);
        }

        [Fact]
        public async Task DetailsReturnsBadRequestWhenMediatorThrowsException()
        {
            mediatorMock.Setup(m => m.Send(
                            It.IsAny<OfficesInquiryRequest>(),
                            default(System.Threading.CancellationToken)))
                        .Throws(new Exception("Test Exception"));

            var result = await controller.Detail(0);

            var resultObject = Assert.IsType<BadRequestObjectResult>(result);
            var badRequestObjectResult = result as BadRequestObjectResult;
        }




        private static void AssertAreEqualByJson(object expected, object actual)
        {
            var expectedJson = JsonConvert.SerializeObject(expected);
            var actualJson = JsonConvert.SerializeObject(actual);

            Assert.Equal(expectedJson, actualJson);
        }

        private OfficesDetailViewModel GetAsDetailViewModel(Office expectedEntity)
        {
            return fixture.Build<OfficesDetailViewModel>()
                .With(entity => entity.Id, expectedEntity.Id)
                .With(entity => entity.RegionName, expectedEntity.Region.Name)
                .With(entity => entity.ParishName, expectedEntity.Parish.Name)
                .With(entity => entity.OfficeType, expectedEntity.OfficeType.Name)
                .With(entity => entity.InventoryFulfillmentCenter, expectedEntity.InventoryFulfillmentCenter)
                .With(entity => entity.OfficeName, expectedEntity.OfficeName)
                .With(entity => entity.OfficeNumber, expectedEntity.OfficeNumber)
                .With(entity => entity.PhysicalAddress1, expectedEntity.PhysicalAddress1)
                .With(entity => entity.PhysicalAddress2, expectedEntity.PhysicalAddress2)
                .With(entity => entity.PhysicalCity, expectedEntity.PhysicalCity)
                .With(entity => entity.PhysicalState, expectedEntity.PhysicalState)
                .With(entity => entity.PhysicalZip, expectedEntity.PhysicalZip)
                .With(entity => entity.PhysicalZip4, expectedEntity.PhysicalZip4)
                .With(entity => entity.MailingRecipient, expectedEntity.MailingRecipient)
                .With(entity => entity.MailingAddress1, expectedEntity.MailingAddress1)
                .With(entity => entity.MailingAddress2, expectedEntity.MailingAddress2)
                .With(entity => entity.MailingCity, expectedEntity.MailingCity)
                .With(entity => entity.MailingState, expectedEntity.MailingState)
                .With(entity => entity.MailingZip, expectedEntity.MailingZip)
                .With(entity => entity.MailingZip4, expectedEntity.MailingZip4)
                .With(entity => entity.OfficeManager, expectedEntity.OfficeManager)
                .With(entity => entity.RegionalManager, expectedEntity.RegionalManager)
                .With(entity => entity.HoursOperation, expectedEntity.HoursOperation)
                .With(entity => entity.DaysOperation, expectedEntity.DaysOperation)
                .With(entity => entity.CapabilityRoles, expectedEntity.CapabilityRoles)
                .With(entity => entity.MapDirections, expectedEntity.MapDirections)
                .With(entity => entity.RoadSkillsSchedule, expectedEntity.RoadSkillsSchedule)
                .With(entity => entity.OfficeTotalOperators, expectedEntity.OfficeTotalOperators)
                .With(entity => entity.Status, expectedEntity.Status)
                .With(entity => entity.EftCode, expectedEntity.EftCode)
                .With(entity => entity.PhoneNumbers, expectedEntity.PhoneNumbers)
                .Create();
        }

        private OfficesBriefModel GetAsIndexViewModel(Office expectedEntity)
        {
            return fixture.Build<OfficesBriefModel>()
                .With(entity => entity.Id, expectedEntity.Id)
                .With(entity => entity.ParishId, expectedEntity.Parish.Id)
                .With(entity => entity.ParishName, expectedEntity.Parish.Name)
                .With(entity => entity.OfficeName, expectedEntity.OfficeName)
                .With(entity => entity.OfficeNumber, expectedEntity.OfficeNumber)
                .With(entity => entity.PhysicalAddress1, expectedEntity.PhysicalAddress1)
                .With(entity => entity.PhysicalAddress2, expectedEntity.PhysicalAddress2)
                .With(entity => entity.PhysicalCity, expectedEntity.PhysicalCity)
                .With(entity => entity.PhysicalState, expectedEntity.PhysicalState)
                .With(entity => entity.PhysicalZip, expectedEntity.PhysicalZip)
                .With(entity => entity.PhysicalZip4, expectedEntity.PhysicalZip4)
                .With(entity => entity.PhoneNumbers, expectedEntity.PhoneNumbers)
                .Create();
        }
    }
}