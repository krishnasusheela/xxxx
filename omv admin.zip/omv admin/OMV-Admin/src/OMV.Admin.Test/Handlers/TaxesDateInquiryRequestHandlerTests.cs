﻿using AutoFixture;
using Moq;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;
using OMV.Admin.Infrastructure.Handlers;
using OMV.Admin.Infrastructure.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace OMV.Admin.Test.Handlers
{
    public class TaxesDateInquiryRequestHandlerTests
        : IDisposable
    {
        private Fixture fixture;
        private TaxesDateInquiryRequestHandler handler;
        private Mock<ITaxTableService> serviceMock;

        public TaxesDateInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<ITaxTableService>();
            handler = new TaxesDateInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandleReturnsExpected()
        {
            var expected = fixture.Create<Domicile>();
            var request = new TaxesDateInquiryRequest
            {
                DomicileId = expected.Id,
                Date = DateTimeOffset.Now.Date
            };

            serviceMock
                .Setup(m => m.GetDomicileByIdAndDate(
                    It.Is<int>(p => p == expected.Id),
                    It.Is<DateTimeOffset>(p => p == DateTimeOffset.Now.Date)))
                .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
