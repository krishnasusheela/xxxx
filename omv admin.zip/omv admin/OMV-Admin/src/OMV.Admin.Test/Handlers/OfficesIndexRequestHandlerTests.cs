﻿using System;
using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Configurations;
using OMV.Admin.Infrastructure.Requests;
using System.Net.Http;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using Xunit;
using OMV.Admin.Infrastructure.Handlers;

namespace OMV.Admin.Test.Handlers
{
    public class OfficesIndexRequestHandlerTests : IDisposable
    {
        private Fixture fixture;
        private OfficesInquiryRequestHandler handler;

        public OfficesIndexRequestHandlerTests()
        {
            fixture = new Fixture();


            WebApiServer apiOptions = new WebApiServer();
            apiOptions.OMVOfficeListingApi = @"http://S-DMWS-OMV01:51001";

            var webApiServerMock = new Mock<IOptions<WebApiServer>>();
            webApiServerMock.Setup(x => x.Value).Returns(apiOptions);

            handler = new OfficesInquiryRequestHandler(webApiServerMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

    }
}