﻿using System;

namespace OMV.Admin.Test.Handlers
{
    public class RoleCreateRequestHandlerTests : IDisposable
    {
        // Added this so that it would build, not sure how this ended up here without it
        public void Dispose()
        {
        }
    }
}
