﻿using AutoFixture;
using OMV.Admin.Infrastructure.Handlers;
using System;

namespace OMV.Admin.Test.Handlers
{
    public class RolesInquiryRequestHandlerTests : IDisposable
    {
        private RolesInquiryRequestHandler handler;
        private Fixture fixture;

        public RolesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
        }

        public void Dispose()
        {
            handler = null;
            fixture = null;
        }
    }
}
