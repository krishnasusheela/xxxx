﻿using AutoFixture;
using Moq;
using OMV.Admin.Core.Entities;
using OMV.Admin.Core.Interfaces;
using OMV.Admin.Infrastructure.Handlers;
using OMV.Admin.Infrastructure.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace OMV.Admin.Test.Handlers
{
    public class TaxesInquiryRequestHandlerTests
        : IDisposable
    {
        private Fixture fixture;
        private TaxesInquiryRequestHandler handler;
        private Mock<ITaxTableService> serviceMock;

        public TaxesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<ITaxTableService>();
            handler = new TaxesInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandleReturnsExpected()
        {
            var expected = fixture.Create<Domicile>();
            var request = new TaxesInquiryRequest
            {
                DomicileCode = expected.CombinedCode
            };

            serviceMock
                .Setup(m => m.GetDomicileByCode(
                    It.Is<string>(p => p == expected.CombinedCode)))
                .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
