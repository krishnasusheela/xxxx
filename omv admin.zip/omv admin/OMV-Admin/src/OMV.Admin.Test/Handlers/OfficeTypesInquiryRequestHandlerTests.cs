﻿using AutoFixture;
using OMV.Admin.Infrastructure.Handlers;
using System;
using Moq;
using Xunit;
using System.Threading.Tasks;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Core.Interfaces;
using System.Collections.Generic;

namespace OMV.Admin.Test.Handlers
{

    public class OfficeTypesInquiryRequestHandlerTests : IDisposable
    {
        private OfficeTypesInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IOfficeTypesService> serviceMock;

        public OfficeTypesInquiryRequestHandlerTests()
        {
            this.fixture = new Fixture();
            this.serviceMock = new Mock<IOfficeTypesService>();
            this.handler = new OfficeTypesInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            serviceMock = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandleReturnsExpectedRole()
        {
            var expected = fixture.Create<IEnumerable<OfficeType>>();
            var request = new OfficeTypesInquiryRequest();

            serviceMock
                .Setup(m => m.OfficeTypesInquiry())
                .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
