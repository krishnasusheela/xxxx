﻿using AutoFixture;
using Moq;
using Xunit;
using OMV.Admin.Infrastructure.Handlers;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using OMV.Admin.Core.Entities;
using MediatR;
using OMV.Admin.Infrastructure.Requests;
using OMV.Admin.Core.Interfaces;

namespace OMV.Admin.Test.Handlers
{
    public class ProgramFunctionsInquiryRequestHandlerTests : IDisposable
    {
        private Fixture fixture;
        private ProgramFunctionsInquiryRequestHandler handler;
        private Mock<IProgramFunctionsService> serviceMock;
        private Mock<IMediator> mediatorMock;

        public ProgramFunctionsInquiryRequestHandlerTests()
        {
            this.fixture = new Fixture();
            this.serviceMock = new Mock<IProgramFunctionsService>();
            this.mediatorMock = new Mock<IMediator>();
            this.handler = new ProgramFunctionsInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            serviceMock = null;
            mediatorMock = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandleReturnsExpectedProgramFunctionCollection()
        {
            var expected = fixture.Create<IEnumerable<ProgramFunction>>();
            var request = new ProgramFunctionsInquiryRequest();

            serviceMock
                .Setup(m => m.ProgramFunctionsInquiry())
                .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.IsAssignableFrom<IEnumerable<ProgramFunction>>(result);
            Assert.Equal(expected, result);
        }
    }
}
