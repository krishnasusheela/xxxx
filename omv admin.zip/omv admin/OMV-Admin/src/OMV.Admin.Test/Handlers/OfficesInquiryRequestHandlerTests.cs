﻿using System;
using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using OMV.Admin.Core.Entities;
using OMV.Admin.Infrastructure.Configurations;
using OMV.Admin.Infrastructure.Requests;
using System.Net.Http;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using Xunit;
using OMV.Admin.Infrastructure.Handlers;

namespace OMV.Admin.Test.Handlers
{
    public class OfficesInquiryRequestHandlerTests : IDisposable
    {
        private Fixture fixture;
        private OfficesInquiryRequestHandler handler;

        public OfficesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();


            WebApiServer apiOptions = new WebApiServer();
            apiOptions.OMVOfficeListingApi = @"http://S-DMWS-OMV01:51001";

            var webApiServerMock = new Mock<IOptions<WebApiServer>>();
            webApiServerMock.Setup(x => x.Value).Returns(apiOptions);

            handler = new OfficesInquiryRequestHandler(webApiServerMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandleReturnsExpected()
        {
            var expected = fixture.Create<Office>();
            var request = fixture.Build<OfficesInquiryRequest>()
                .With(req => req.Id, expected.Id)
                .Create();

            // ** Mock HTTP Client Instead...  ??
            //    Hacked to Mock the Handler as a placeholder for discussion  [that will still Pass Assert Test]
            expected.Id = 1;
            request.Id = 1;

            var mockHandler = new Mock<IRequestHandler<OfficesInquiryRequest, Office>>();
            mockHandler.Setup(m => m.Handle(
                    It.IsAny<OfficesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);
            // ** Mock HTTP Client Instead...  ??

            var actual = await mockHandler.Object.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.IsType<Office>(actual);
            AssertAreEqualByJson(expected, actual);
        }




        private static void AssertAreEqualByJson(object expected, object actual)
        {
            var expectedJson = JsonConvert.SerializeObject(expected);
            var actualJson = JsonConvert.SerializeObject(actual);

            Assert.Equal(expectedJson, actualJson);
        }
    }
}