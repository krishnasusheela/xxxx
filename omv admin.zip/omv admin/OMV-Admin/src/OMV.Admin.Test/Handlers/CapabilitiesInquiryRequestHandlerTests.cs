﻿using AutoFixture;
using Moq;
using Xunit;
using OMV.Admin.Infrastructure.Configurations;
using OMV.Admin.Infrastructure.Handlers;
using System;
using Microsoft.Extensions.Options;
using System.Threading.Tasks;
using System.Net.Http;
using System.Collections.Generic;
using OMV.Admin.Core.Entities;
using MediatR;
using OMV.Admin.Infrastructure.Requests;
using System.Threading;
using OMV.Admin.Core.Interfaces;

namespace OMV.Admin.Test.Handlers
{
    public class CapabilitiesInquiryRequestHandlerTests : IDisposable
    {
        private Fixture fixture;
        private CapabilitiesInquiryRequestHandler handler;
        private Mock<ICapabilitiesService> serviceMock;
        private Mock<IMediator> mediatorMock;

        public CapabilitiesInquiryRequestHandlerTests()
        {
            this.fixture = new Fixture();
            this.serviceMock = new Mock<ICapabilitiesService>();
            this.mediatorMock = new Mock<IMediator>();
            this.handler = new CapabilitiesInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            serviceMock = null;
            mediatorMock = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandleReturnsExpectedCapabilityCollection()
        {
            var expected = fixture.Create<IEnumerable<Capability>>();
            var request = new CapabilitiesInquiryRequest();
            
            serviceMock
                .Setup(m => m.CapabilitiesInquiry())
                .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.IsAssignableFrom<IEnumerable<Capability>>(result);
            Assert.Equal(expected, result);
        }
    }
}
