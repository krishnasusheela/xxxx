﻿using System;
using System.Threading.Tasks;
using OMV.Admin.Core.Entities;
using System.Collections.Generic;


namespace OMV.Admin.Core.Interfaces
{
    public interface IRolesService
    {
        Task<IEnumerable<Role>> RolesInquiry();
        Task<Role> RoleInquiry(int id);
    }
}
