﻿using OMV.Admin.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.Admin.Core.Interfaces
{
    public interface IProgramFunctionsService
    {
        Task<IEnumerable<ProgramFunction>> ProgramFunctionsInquiry();
    }
}
