﻿using System;
using System.Threading.Tasks;
using OMV.Admin.Core.Entities;

namespace OMV.Admin.Core.Interfaces
{
    public interface ITaxTableService
    {
        Task<Domicile> GetDomicileByCode(string domicileCode);
        Task<Domicile> GetDomicileByIdAndDate(int id, DateTimeOffset date);
    }
}
