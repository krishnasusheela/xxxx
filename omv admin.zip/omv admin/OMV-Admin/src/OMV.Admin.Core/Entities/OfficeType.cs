﻿using System;

namespace OMV.Admin.Core.Entities
{
    public class OfficeType
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public Boolean IsValidForRole { get; set; }
    }
}
