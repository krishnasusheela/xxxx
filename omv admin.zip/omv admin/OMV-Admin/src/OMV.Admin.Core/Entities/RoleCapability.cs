﻿using System;

namespace OMV.Admin.Core.Entities
{
    public class RoleCapability
    {
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? ExpireDate { get; set; }
        public Capability Capability { get; set; }
    }
}
