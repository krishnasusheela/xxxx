﻿using System;
using System.Collections.Generic;

namespace OMV.Admin.Core.Entities
{
    public class Role
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string PublicDescription { get; set; }
        public Boolean IsPublic { get; set; }
        public ProgramFunction ProgramFunction { get; set; }
        public OfficeType OfficeType { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? ExpireDate { get; set; }
        public IEnumerable<RoleCapability> RoleCapabilities { get; set; }
    }
}
