﻿using System;
using System.Collections.Generic;

namespace OMV.Admin.Core.Entities
{
    public class Capability
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? ExpireDate { get; set; }
        public IEnumerable<OfficeType> OfficeTypes { get; set; }
        public ProgramFunction ProgramFunction { get; set; }
    }
}
