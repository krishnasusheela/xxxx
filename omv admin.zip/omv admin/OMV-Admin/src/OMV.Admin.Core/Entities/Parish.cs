﻿namespace OMV.Admin.Core.Entities
{
    public class Parish
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}