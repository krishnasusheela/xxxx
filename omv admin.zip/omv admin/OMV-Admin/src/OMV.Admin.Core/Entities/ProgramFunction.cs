﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMV.Admin.Core.Entities
{
    public class ProgramFunction
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
