﻿namespace OMV.Admin.Core.Entities
{
    public class PhoneNumber
    {
        public int Id { get; set; }
        public string Number { get; set; }
        public string PhoneNumberExtension { get; set; }
        public PhoneNumberType PhoneNumberType  { get; set; }

        public string DisplayedPhoneNumber()
        {
            if (string.IsNullOrEmpty(Number))
                return "";
            else if (string.IsNullOrEmpty(PhoneNumberExtension))
                return Number;
            else
                return Number + " x" + PhoneNumberExtension;
        }
    }
}
