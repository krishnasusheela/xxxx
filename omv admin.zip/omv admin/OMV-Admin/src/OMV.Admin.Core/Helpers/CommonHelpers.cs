﻿using System;

namespace OMV.Admin.Core.Helpers
{
    public static class CommonHelpers
    {
        public static string ToDisplayDateString(this DateTimeOffset DateTimeOffset)
        {
            return DateTimeOffset.ToString("MM/dd/yyyy");
        }

        public static string ToDisplayDateString(this DateTimeOffset? DateTimeOffset)
        {
            return DateTimeOffset?.ToString("MM/dd/yyyy") ?? "";
        }
    }
}
