﻿using OMV.Admin.Core.Entities;

namespace OMV.Admin.Core.Helpers
{
    public static class CapabilityHelpers
    {
        public static string DisplayedEffectiveDate(
            this Capability capability)
        {
            return capability.EffectiveDate.ToDisplayDateString();
        }

        public static string DisplayedExpireDate(
            this Capability capability)
        {
            return capability.ExpireDate.ToDisplayDateString();
        }
    }
}
