﻿using OMV.Admin.Core.Entities;

namespace OMV.Admin.Core.Helpers
{
    public static class RoleHelpers
    {
        public static string DisplayedEffectiveDate(
            this Role role)
        {
            return role.EffectiveDate.ToDisplayDateString();
        }

        public static string DisplayedExpireDate(
            this Role role)
        {
            return role.ExpireDate.ToDisplayDateString();
        }
    }
}
