﻿using OMV.Admin.Core.Entities;
using System;

namespace OMV.Admin.Core.Helpers
{
    public static class RoleCapabilityHelpers
    {
        public static string DisplayedEffectiveDate(
            this RoleCapability roleCapability)
        {
            return roleCapability.EffectiveDate.ToDisplayDateString();
        }

        public static string DisplayedExpireDate(
            this RoleCapability roleCapability)
        {
            return roleCapability.ExpireDate.ToDisplayDateString();
        }

        public static bool IsRoleCapabilityActive(
            this RoleCapability roleCapability)
        {
            return ((roleCapability.EffectiveDate <= DateTimeOffset.Now) && ((!roleCapability.ExpireDate.HasValue)||(DateTimeOffset.Now <= roleCapability.ExpireDate)));
        }
    }
}
