﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class DomicileParishInquiryRequest
        : IRequest<ParishDomicile>
    {
        public int ParishId { get; set; }
    }
}
