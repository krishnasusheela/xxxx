﻿using MediatR;
using ParishTaxTable.Admin.Models;
using System.Collections.Generic;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class DomicilesInquiryRequest
        : IRequest<IEnumerable<Domicile>>
    {

    }
}
