﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class DispersionDeleteRequest
        : IRequest<Dispersion>
    {
        public int Id { get; set; }
    }
}