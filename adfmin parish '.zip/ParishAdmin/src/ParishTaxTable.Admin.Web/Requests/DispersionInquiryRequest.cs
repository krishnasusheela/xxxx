﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class DispersionInquiryRequest
        : IRequest<Dispersion>
    {
        public int Id { get; set; }
    }
}
