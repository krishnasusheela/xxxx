﻿using MediatR;
using ParishTaxTable.Admin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class DomicileCodeInquiryRequest
        : IRequest<Domicile>
    {
        public string DomicileCode { get; set; }
    }
}
