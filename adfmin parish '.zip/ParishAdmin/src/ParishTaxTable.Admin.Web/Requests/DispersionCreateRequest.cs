﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class DispersionCreateRequest
        : IRequest<Dispersion>
    {
        public Dispersion Dispersion { get; set; }
        public int? InvalidatedId { get; set; }
    }
}
