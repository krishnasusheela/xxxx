﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class ApiPttGetRequest
        : IRequest<string>
    {
        public string Url { get; set; }
    }
}
