﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class ContactUpdateRequest
        : IRequest<Contact>
    {
        public Contact Contact { get; set; }
    }
}
