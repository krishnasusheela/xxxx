﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class ContactInquiryRequest
        : IRequest<Contact>
    {
        public int Id { get; set; }
    }
}