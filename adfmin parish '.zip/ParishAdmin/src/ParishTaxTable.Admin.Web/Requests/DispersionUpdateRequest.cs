﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class DispersionUpdateRequest
        : IRequest<Dispersion>
    {
        public Dispersion dispersion { get; set; }
    }
}
