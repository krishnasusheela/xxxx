﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class JurisdictionUpdateRequest
        : IRequest<Jurisdiction>
    {
        public Jurisdiction Jurisdiction { get; set; }
    }
}
