﻿using MediatR;
using ParishTaxTable.Admin.Models;
using System;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class DomicileInquiryRequest
        : IRequest<Domicile>
    {
        public int Id { get; set; }
        public DateTimeOffset? SearchDate { get; set; }
    }
}
