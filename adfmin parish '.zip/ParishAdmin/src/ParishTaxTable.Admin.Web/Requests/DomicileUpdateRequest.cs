﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
     public class DomicileUpdateRequest
        : IRequest<Domicile>
    {
        public Domicile domicile { get; set; }
    }
}
