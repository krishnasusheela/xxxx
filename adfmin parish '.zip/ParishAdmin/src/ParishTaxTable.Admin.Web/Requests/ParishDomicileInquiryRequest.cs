﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class ParishDomicileInquiryRequest
        : IRequest<ParishDomicile>
    {
        public int Id { get; set; }
    }
}
