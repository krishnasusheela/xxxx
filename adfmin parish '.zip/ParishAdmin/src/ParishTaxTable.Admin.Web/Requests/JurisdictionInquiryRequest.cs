﻿using MediatR;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Requests
{
    public class JurisdictionInquiryRequest
        : IRequest<Jurisdiction>
    {
        public int Id { get; set; }
    }
}