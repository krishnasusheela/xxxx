﻿using ParishTaxTable.Admin.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ParishTaxTable.Admin.Web.Helpers
{
    public static class DispersionHelpers
    {
        public static IEnumerable<Dispersion> GetCurrentDispersions(
            this IEnumerable<Dispersion> dispersions, DateTimeOffset? searchDate = null)
        {
            if (searchDate == null)
            {
                return dispersions
                .Where(y =>
                    y.EffectiveDate <= DateTimeOffset.Now
                    && (y.TermDate == null || y.TermDate >= DateTime.Now)
                    && !y.IsInvalidDispersion);
            }

            return dispersions
                .Where(y =>
                    y.EffectiveDate <= searchDate
                    && (y.TermDate == null || y.TermDate >= searchDate)
                    && !y.IsInvalidDispersion);
        }

        public static IEnumerable<Dispersion> GetFutureDispersions(
            this IEnumerable<Dispersion> dispersions, DateTimeOffset? searchDate = null)
        {
            if (searchDate == null)
            {
                return dispersions
                .Where(y => y.EffectiveDate > DateTimeOffset.Now
                    && !y.IsInvalidDispersion);
            }
            return dispersions
                .Where(y => y.EffectiveDate > searchDate
                    && !y.IsInvalidDispersion);
        }
        public static IEnumerable<Dispersion> GetInvalidDispersions(this IEnumerable<Dispersion> dispersions)
        {
            return dispersions
                .Where(y =>
                    y.IsInvalidDispersion);
        }

        public static bool IsHistorical(this Dispersion dispersion)
        {
            return dispersion.TermDate != null &&
                   dispersion.TermDate < DateTimeOffset.Now.Date;
        }
    }
}
