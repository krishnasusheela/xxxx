﻿using System;
using MediatR;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using ParishTaxTable.Admin.Web.Interfaces;
using ParishTaxTable.Admin.Web.Requests;
using System.Collections;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Helpers
{
    public class CommonRequestHelpers : ICommonRequestHelpers
    {
        private readonly IMediator mediator;

        public CommonRequestHelpers(IMediator mediator)
        {
            this.mediator = mediator;
        }

        public async Task<IList<SelectListItem>> ParishSelectListItems()
        {
            try
            {
                var parishes = await mediator.Send(new ParishesInquiryRequest());
                return parishes
                    .ToSelectListItems()
                    .ToList();
            }
            catch (Exception)
            {
                return new List<SelectListItem>();
            }
        }
      
        public async Task<string> JurisdictionName(int id)
        {

            var jurisdiction = await mediator.Send(new JurisdictionInquiryRequest() { Id = id });
            return jurisdiction.Name;
        }
        public async Task<string> DomicileName(int id)
        {
            var domicile = await mediator.Send(new DomicileInquiryRequest() { Id = id });
            return domicile.DisplayedDomicileCode;
        }
        public async Task<string> ParishName(int id)
        {
            var parish = await mediator.Send(new ParishInquiryRequest() { Id = id });
            return parish.Name;
        }
        public async Task<int> ParishIdFromDomicileId(int id)
        {
            var domicile = await mediator.Send(new DomicileInquiryRequest() { Id = id });
            return domicile.ParishId;
        }

        public async Task<IList<SelectListItem>> JurisdictionSelectListItems(int id)
        {
            try
            {
                var jurisdictions = await mediator.Send(new ParishJurisdictionInquiryRequest() { Id = id });
                return jurisdictions.Jurisdictions
                    .GetActiveJurisdictions()
                    .ToSelectListItems()
                    .ToList();
            }
            catch (Exception)
            {
                return new List<SelectListItem>();
            }
        }

        public async Task<IList<SelectListItem>> DomicileSelectListItems(int id)
        {
            try
            {
                var domiciles = await mediator.Send(new ParishDomicileInquiryRequest() { Id = id });
                return domiciles.Domiciles
                    .GetActiveOrFutureDomiciles()
                    .ToSelectListItems()
                    .ToList();
            }
            catch (Exception)
            {
                return new List<SelectListItem>();
            }
        }
        
    }
}
