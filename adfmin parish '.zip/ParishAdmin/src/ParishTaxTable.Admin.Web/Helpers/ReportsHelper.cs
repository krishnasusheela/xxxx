﻿using Microsoft.AspNetCore.Mvc.Rendering;
using ParishTaxTable.Admin.Models;
using System.Collections.Generic;

namespace ParishTaxTable.Admin.Web.Helpers
{
    public class ReportsHelper
    {
        public static IEnumerable<ReportDescription> GetReportDescriptions()
        {
            return new List<ReportDescription>()
            {
                new ReportDescription
                {
                    ReportId = 1,
                    ReportName = "Contact List Report",
                    ReportLink = "http://ssrs-dev/ReportServer/Pages/ReportViewer.aspx?%2fParishTaxTable%2fReports%2fContactList&rs:Command=Render&rs:Embed=true"
                },
                new ReportDescription
                {
                    ReportId = 2,
                    ReportName = "Collection and Dispersion Rates by Parish",
                    ReportLink = "http://ssrs-dev/ReportServer/Pages/ReportViewer.aspx?%2fParishTaxTable%2fReports%2fCollection+and+Dispersion+Rates+by+Parish&rs:Command=Render&rs:Embed=true"
                }
            };
        }

        public static List<SelectListItem> GetReportsAsSelectionList(IEnumerable<ReportDescription> reportDescriptions)
        {
            List<SelectListItem> items = new List<SelectListItem>();
            foreach (ReportDescription description in reportDescriptions)
            {
                SelectListItem item = new SelectListItem();
                item.Text = description.ReportName;
                item.Value = description.ReportId.ToString();

                items.Add(item);
            }

            return items;
        }
    }
}
