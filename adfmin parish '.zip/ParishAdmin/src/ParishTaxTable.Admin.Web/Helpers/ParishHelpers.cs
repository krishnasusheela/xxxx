﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Helpers
{
    public static class ParishHelpers
    {
        public static IEnumerable<SelectListItem> ToSelectListItems(this IEnumerable<Parish> parishes)
        {
            return parishes
                .OrderBy(x => x.Id)
                .Select(rcd => new SelectListItem
                {
                    Value = rcd.Id.ToString(),
                    Text = rcd.Name
                });
        }  
        
        public static IEnumerable<int> GetJurisdictionIdsOfParish(this ParishDomicile parish)
        {
            return parish
                .Domiciles
                .SelectMany(p => p.Dispersions)
                .Select(q => q.Jurisdiction.Id)
                .Distinct();
        }
    }
}
