﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Helpers
{
    public static class FormattingHelpers
    {
        public static decimal GetDecimalPercentage(this string rate)
        {
            if (Decimal.TryParse(rate.Replace("%", string.Empty), out decimal decimalRate))
            {
                decimalRate = decimalRate / 100;

                return decimalRate;
            }
            else
            {
                throw new InvalidOperationException(rate + " is not a valid percentage");
            }
        }

        public static string GetStringPercentage(this decimal rate) => (rate * 100.0m).ToString("#0.00");

    }
}
