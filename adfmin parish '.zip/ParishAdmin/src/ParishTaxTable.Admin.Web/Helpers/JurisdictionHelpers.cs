﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Helpers
{
    public static class JurisdictionHelpers
    {
        public static IEnumerable<Jurisdiction> GetActiveJurisdictions(
            this IEnumerable<Jurisdiction> jurisdictions)
        {
            return jurisdictions.Where(y => y.RetireDate == null);
        }
        public static bool AnyActive(
            this IEnumerable<Jurisdiction> jurisdictions)
        {
            return (jurisdictions != null && jurisdictions.GetActiveJurisdictions().Any());
        }

        public static IEnumerable<Jurisdiction> GetInactiveJurisdictions(this IEnumerable<Jurisdiction> jurisdictions)
        {
            return jurisdictions.Where(y => y.RetireDate != null);
        }
        public static bool AnyInactive(
            this IEnumerable<Jurisdiction> jurisdictions)
        {
            return (jurisdictions != null && jurisdictions.GetInactiveJurisdictions().Any());
        }

        public static IEnumerable<SelectListItem> ToSelectListItems(this IEnumerable<Jurisdiction> jurisdictions)
        {
            return jurisdictions
                .OrderBy(x => x.Name)
                .Select(rcd => new SelectListItem
                {
                    Value = rcd.Id.ToString(),
                    Text = rcd.Name
                });
        }
    }

}