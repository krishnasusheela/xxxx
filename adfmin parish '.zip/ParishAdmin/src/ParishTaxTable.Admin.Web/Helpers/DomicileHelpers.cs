﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Helpers
{
    public static class DomicileHelpers
    {
        public static IEnumerable<SelectListItem> ToSelectListItems(this IEnumerable<Domicile> domiciles)
        {
            return domiciles
                .OrderBy(x => x.Id)
                .Select(rcd => new SelectListItem
                {
                    Value = rcd.Id.ToString(),
                    Text = rcd.DisplayedDomicileCode
                });
        }

        public static IEnumerable<Domicile> GetActiveDomiciles(
            this IEnumerable<Domicile> domiciles)
        {
            return domiciles.Where(y =>
                y.EffectiveDate <= DateTimeOffset.Now
                && (y.TermDate == null || y.TermDate >= DateTime.Now));
        }

        public static IEnumerable<Domicile> GetActiveOrFutureDomiciles(
            this IEnumerable<Domicile> domiciles)
        {
            return domiciles.Where(y =>
                (y.TermDate == null || y.TermDate >= DateTime.Now));
        }
    }
}
