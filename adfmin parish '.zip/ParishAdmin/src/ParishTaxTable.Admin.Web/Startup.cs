﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ParishTaxTable.Admin.Web.Configurations;
using ParishTaxTable.Admin.Web.Helpers;
using ParishTaxTable.Admin.Web.Interfaces;
using ParishTaxTable.Admin.Infrastructure.Services.Taxes;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using System;

namespace ParishTaxTable.Admin.Web
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMediatR(
                typeof(Startup)
                .GetTypeInfo()
                .Assembly);

            services.Configure<WebApiServer>(Configuration.GetSection("WebApiServer"));
            services.AddHttpClient<IJurisdictionService, JurisdictionService>(client =>
                client.BaseAddress = new Uri(Configuration["WebApiServer:ParishTaxTableApi"]));
            services.AddHttpClient<IDispersionService, DispersionService>(client =>
                client.BaseAddress = new Uri(Configuration["WebApiServer:ParishTaxTableApi"]));
            services.AddHttpClient<IParishService, ParishService>(client =>
                client.BaseAddress = new Uri(Configuration["WebApiServer:ParishTaxTableApi"]));
            services.AddHttpClient<IContactService, ContactService>(client =>
               client.BaseAddress = new Uri(Configuration["WebApiServer:ParishTaxTableApi"]));
            services.AddHttpClient<IDomicileService, DomicileService>(client =>
               client.BaseAddress = new Uri(Configuration["WebApiServer:ParishTaxTableApi"]));
            services.AddHttpClient<IApiPttService, ApiPttService>(client =>
                client.BaseAddress = new Uri(Configuration["WebApiServer:ParishTaxTableApi"]));

            services.AddTransient<ICommonRequestHelpers, CommonRequestHelpers>();

            services
                .AddMvc()
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
