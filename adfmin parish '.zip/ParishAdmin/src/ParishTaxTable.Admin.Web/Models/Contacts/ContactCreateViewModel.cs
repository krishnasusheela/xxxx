﻿using Microsoft.AspNetCore.Mvc.Rendering;
using ParishTaxTable.Admin.Models;
using System.Collections.Generic;

namespace ParishTaxTable.Admin.Web.Models.Contacts
{
    public class ContactCreateViewModel
    {
        public Contact Contact { get; set; }
        public string ParishId { get; set; }
        public IEnumerable<Parish> Parishes { get; set; }
    }
}


