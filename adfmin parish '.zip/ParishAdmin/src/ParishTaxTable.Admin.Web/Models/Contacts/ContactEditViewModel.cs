﻿using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Models.Contacts
{
    public class ContactEditViewModel
    {
        public Contact Contact { get; set; }
        public Parish Parish { get; set; }
    }
}


