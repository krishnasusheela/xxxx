﻿using System.Collections.Generic;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Models.Jurisdictions
{
    public class JurisdictionCreateViewModel
    {
        public Jurisdiction Jurisdiction { get; set; }
        public int ParishId { get; set; }
        public int DomicileId { get; set; }
        public IEnumerable<Parish> Parishes { get; set; }
        public IEnumerable<JurisdictionType> JurisdictionTypes { get; set; }
        public bool DispersionCreate { get; set; }
    }
}
