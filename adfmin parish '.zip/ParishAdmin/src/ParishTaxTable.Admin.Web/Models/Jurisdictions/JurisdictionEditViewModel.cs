﻿using System.Collections;
using System.Collections.Generic;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Models.Jurisdictions
{
    public class JurisdictionEditViewModel
    {
        public Jurisdiction Jurisdiction { get; set; }
        public Parish Parish { get; set; }
        public IEnumerable<JurisdictionType> JurisdictionTypes { get; set; }
    }
}


