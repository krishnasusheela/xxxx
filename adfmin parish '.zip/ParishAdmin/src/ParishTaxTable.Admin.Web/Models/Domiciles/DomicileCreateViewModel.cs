﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using ParishTaxTable.Admin.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ParishTaxTable.Admin.Web.Models.Domiciles
{
    public class DomicileCreateViewModel
    {
        public int Id { get; set; }



        [Range(1, int.MaxValue, ErrorMessage = "Parish is Required")]
        [Display(Name = "Parish")]
        public int ParishId { get; set; }

        [Required]
        [Display(Name = "Domicile Name")]
        public string Name { get; set; }
        
        [Required]
        [Display(Name = "Domicile Code")]
        [RegularExpression("^[0-9]{2}$", ErrorMessage = "The Domicile Code must be a 2 digit number [zero padded]")]
        public string DomicileCode { get; set; }
        
        [Required]
        [Display(Name = "Effective Date")]
        [DisplayFormat(DataFormatString = "yyyy-MM-dd", ApplyFormatInEditMode = true)]
        public DateTimeOffset? EffectiveDate { get; set; }

        [Display(Name = "Expiration Date")]
        [DisplayFormat(DataFormatString = "yyyy-MM-dd", ApplyFormatInEditMode = true)]
        public DateTimeOffset? TermDate { get; set; }
        


        public IEnumerable<SelectListItem> ParishSelectListItems { get; set; }



        [JsonIgnore]
        public string DisplayedEffectiveDate => EffectiveDate?.ToString("yyyy-MM-dd");
        [JsonIgnore]
        public string DisplayedTermDate => TermDate?.ToString("yyyy-MM-dd");
    }
}
