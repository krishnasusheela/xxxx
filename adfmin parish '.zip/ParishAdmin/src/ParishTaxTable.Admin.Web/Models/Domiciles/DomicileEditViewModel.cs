﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using ParishTaxTable.Admin.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ParishTaxTable.Admin.Web.Models.Domiciles
{
    public class DomicileEditViewModel
    {
        public int Id { get; set; }



        [Display(Name = "Domicile Name")]
        public string Name { get; set; }

        [Display(Name = "Expiration Date")]
        [DisplayFormat(DataFormatString = "yyyy-MM-dd", ApplyFormatInEditMode = true)]
        public DateTimeOffset? TermDate { get; set; }



        public int ParishId { get; set; }

        public string CollectionRate { get; set; }
        public string ParishCollectionRate { get; set; }
        public string MunicipalityCollectionRate { get; set; }
        public string VendorCompensation { get; set; }
        public string DomicileCode { get; set; }
        public DateTimeOffset? EffectiveDate { get; set; }


        
        public string CombinedCode { get; set; }



        [JsonIgnore]
        public string DisplayedEffectiveDate => EffectiveDate?.ToString("yyyy-MM-dd");
        [JsonIgnore]
        public string DisplayedTermDate => TermDate?.ToString("yyyy-MM-dd");
        [JsonIgnore]
        public string DisplayedDomicileCode => CombinedCode + " - " + Name;
    }
}
