﻿using ParishTaxTable.Admin.Models;
using System.Collections.Generic;

namespace ParishTaxTable.Admin.Web.Models.Domiciles
{
    public class DomicilesViewModel
    {
        public IEnumerable<Domicile> Domiciles { get; set; }
    }
}
