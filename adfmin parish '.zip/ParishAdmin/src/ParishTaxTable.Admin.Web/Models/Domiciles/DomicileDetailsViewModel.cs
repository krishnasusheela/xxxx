﻿using ParishTaxTable.Admin.Models;
using System;
using System.Collections.Generic;

namespace ParishTaxTable.Admin.Web.Models.Domiciles
{
    public class DomicileDetailsViewModel
    {
        public Domicile Domicile { get; set; }
        
        public IEnumerable<Dispersion> InUseDispersions { get; set; }
        public IEnumerable<Dispersion> FutureDispersions { get; set; }
        public IEnumerable<Dispersion> InvalidDispersions { get; set; }

        public DateTimeOffset? SearchDate { get; set; }
        public string InputDate { get; set; }
        public string ErrorMessage { get; set; }

        public string DisplayedSearchDate => SearchDate?.ToString("yyyy-MM-dd");
    }
}
