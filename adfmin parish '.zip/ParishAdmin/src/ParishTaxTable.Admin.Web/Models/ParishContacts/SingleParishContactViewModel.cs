﻿using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Models.ParishContacts
{
    public class SingleParishContactViewModel
    {
        public ParishContact ParishContact { get; set; }
    }
}
