﻿using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Models.ParishDomiciles
{
    public class SingleParishDomicileViewModel
    {
        public ParishDomicile ParishDomicile { get; set; }
    }
}
