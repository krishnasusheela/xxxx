﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Models.Dispersions
{
    public class DispersionViewModel
    {
        //Common

        [Display(Name = "Parish")]
        [Range(1, int.MaxValue, ErrorMessage = "Parish is Required")]
        public int ParishId { get; set; }

        [Display(Name = "Jurisdiction")]
        [Range(1, int.MaxValue, ErrorMessage = "Jurisdiction is Required")]
        public int JurisdictionId { get; set; }

        [Display(Name = "Domicile")]
        [Range(1, int.MaxValue, ErrorMessage = "Domicile is Required")]
        public int DomicileId { get; set; }

        [Required]
        [Display(Name = "Distribution Rate")]
        [RegularExpression("^\\d{0,2}(\\.\\d{0,2})?(( %)|[%])?$", ErrorMessage = "Distribution Rate is a percentage with upto 2 decimal points. The % is optional.  Examples: 1, 3%, 2.12, 4.01 %")]
        public string DistributionRate { get; set; }

        [Required]
        [Display(Name = "Vendor Compensation")]
        [RegularExpression("^\\d{0,2}(\\.\\d{0,2})?(( %)|[%])?$", ErrorMessage = "Vendor Compensation is a percentage with upto 2 decimal points. The % is optional.  Examples: 1, 3%, 2.12, 4.12 %")]
        public string VendorCompensation { get; set; }

        [Required]
        [Display(Name = "Effective Date")]
        public DateTimeOffset? EffectiveDate { get; set; }

        [Display(Name = "Expiration Date")]
        public DateTimeOffset? TermDate { get; set; }

        public string DisplayedEffectiveDate => EffectiveDate?.ToString("yyyy-MM-dd");

        public string DisplayedTermDate => TermDate?.ToString("yyyy-MM-dd");

        public bool IsTermed => TermDate < DateTimeOffset.Now.Date;


        //Edit
        [ReadOnly(true)]
        public Dispersion OriginalDispersion { get; set; }
        public bool InUseCheck { get; set; }
        public int DispersionId { get; set; }
        public string JurisdictionName { get; set; }
        public string DomicileName { get; set; }
        public string ParishName { get; set; }

        //Create
        public string EventCommand { get; set; }
        public IList<SelectListItem> ParishSelectListItems { get; set; }
        public IList<SelectListItem> JurisdictionSelectListItems { get; set; }
        public IList<SelectListItem> DomicileSelectListItems { get; set; }
    }
}
