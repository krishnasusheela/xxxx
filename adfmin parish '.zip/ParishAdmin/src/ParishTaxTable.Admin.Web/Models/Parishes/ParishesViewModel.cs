﻿using ParishTaxTable.Admin.Models;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ParishTaxTable.Admin.Web.Models.Parishes
{
    public class ParishesViewModel
    {
        public IEnumerable<Parish> Parishes { get; set; }
        public IEnumerable<Domicile> Domiciles { get; set; }
        [StringLength(4)]
        [Display(Name = "Domicile Code")]
        [RegularExpression(@"^\d{4}$", ErrorMessage = "Domicile code must be 4 digits.")]
        public string DomicileCode { get; set; }
    }
}
