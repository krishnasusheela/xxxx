﻿using ParishTaxTable.Admin.Models;

namespace ParishTaxTable.Admin.Web.Models.Parishes
{
    public class SingleParishViewModel
    {
        public Parish Parish { get; set; }
    }
}
