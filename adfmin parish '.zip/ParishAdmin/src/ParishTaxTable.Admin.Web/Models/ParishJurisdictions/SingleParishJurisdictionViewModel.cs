﻿using ParishTaxTable.Admin.Models;
using System.Collections.Generic;

namespace ParishTaxTable.Admin.Web.Models.ParishJurisdictions
{
    public class SingleParishJurisdictionViewModel
    {
        public ParishJurisdiction ParishJurisdiction { get; set; }
        public List<int> InUseJurisdictionIds { get; set; }
    }
}
