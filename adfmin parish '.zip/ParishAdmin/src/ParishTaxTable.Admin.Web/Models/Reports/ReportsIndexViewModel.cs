﻿using Microsoft.AspNetCore.Mvc.Rendering;
using ParishTaxTable.Admin.Models;
using System.Collections.Generic;

namespace ParishTaxTable.Admin.Web.Models.Reports
{
    public class ReportsIndexViewModel
    {
        public IEnumerable<ReportDescription> Reports { get; set; }
    }
}
