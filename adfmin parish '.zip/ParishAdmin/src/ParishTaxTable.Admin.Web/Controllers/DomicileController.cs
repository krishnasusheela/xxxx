﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;
using ParishTaxTable.Admin.Web.Models.Domiciles;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using ParishTaxTable.Admin.Web.Helpers;
using ParishTaxTable.Admin.Web.Interfaces;
using Microsoft.AspNetCore.Http;

namespace ParishTaxTable.Admin.Web.Controllers
{

    public class DomicileController
        : Controller
    {
        private readonly IMediator mediator;
        private readonly ICommonRequestHelpers commonRequestHelpers;

        public DomicileController(
            IMediator mediator, ICommonRequestHelpers commonRequestHelpers)
        {
            this.mediator = mediator;
            this.commonRequestHelpers = commonRequestHelpers;
        }

        public async Task<IActionResult> Index()
        {
            var result = await mediator.Send(
                new DomicilesInquiryRequest());

            var viewModel = new DomicilesViewModel
            {
                Domiciles = result
            };

            return View(viewModel);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id, [FromQuery] string searchDate)
        {
            string errorMessage = "";
            DateTimeOffset? nullableParsedSearchDate = new DateTimeOffset?();
            
            if (DateTimeOffset.TryParse(searchDate, out DateTimeOffset parsedSearchDate))
            {
                nullableParsedSearchDate = parsedSearchDate;
            }
            else if (searchDate != null)
            {
                errorMessage = "Invalid search date.";
            }

            var result = await mediator.Send(
               new DomicileInquiryRequest { Id = id, SearchDate = nullableParsedSearchDate });

            if (result == null)
            {
                result = await mediator.Send(
                    new DomicileInquiryRequest { Id = id, SearchDate = null });
                errorMessage = "No active domicile for given date.";
                nullableParsedSearchDate = null;
            }

            var viewModel = new DomicileDetailsViewModel
            {
                InputDate = searchDate,
                Domicile = result,
                FutureDispersions = result.Dispersions.GetFutureDispersions(nullableParsedSearchDate),
                InUseDispersions = result.Dispersions.GetCurrentDispersions(nullableParsedSearchDate),
                InvalidDispersions = result.Dispersions.GetInvalidDispersions(),
                SearchDate = nullableParsedSearchDate,
                ErrorMessage = errorMessage
            };

            return View(viewModel);
        }


        [HttpPost]
        public IActionResult Details(DomicileDetailsViewModel domicileDetailsViewModel)
        {
            return RedirectToAction("Details", "Domicile", new { id = domicileDetailsViewModel.Domicile.Id, searchDate = domicileDetailsViewModel.InputDate });
        }

        public async Task<IActionResult> Edit(int id)
        {
            var result = await mediator.Send(
                new DomicileInquiryRequest { Id = id });

            var viewModel = new DomicileEditViewModel
            {
                Id = result.Id,
                ParishId = result.ParishId,
                CombinedCode = result.CombinedCode,
                CollectionRate = result.CollectionRate.GetStringPercentage(),
                VendorCompensation = result.VendorCompensation.GetStringPercentage(),
                DomicileCode = result.DomicileCode,
                Name = result.Name,
                EffectiveDate = result.EffectiveDate,
                TermDate = result.TermDate,
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, DomicileEditViewModel updatedDomicileView)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Domicile updatedDomicile = new Domicile
                    {
                        Id = updatedDomicileView.Id,
                        ParishId = updatedDomicileView.ParishId,
                        CombinedCode = updatedDomicileView.CombinedCode,
                        CollectionRate = updatedDomicileView.CollectionRate.GetDecimalPercentage(),
                        VendorCompensation = updatedDomicileView.VendorCompensation.GetDecimalPercentage(),
                        DomicileCode = updatedDomicileView.DomicileCode,
                        Name = updatedDomicileView.Name,
                        EffectiveDate = updatedDomicileView.EffectiveDate.Value,
                        TermDate = updatedDomicileView.TermDate
                    };

                    var result = await mediator.Send(new DomicileUpdateRequest { domicile = updatedDomicile });

                    return RedirectToAction("Details", new { id = updatedDomicile.Id });
                }
                catch (InvalidOperationException e)
                {
                    ModelState.AddModelError(string.Empty, e.Message);
                }
                catch
                {
                    return RedirectToAction("Details", new { id = updatedDomicileView.Id });
                }
            }

            return View(updatedDomicileView);
        }

        [HttpGet]
        public async Task<IActionResult> Create(int parishId)
        {

            var viewModel = new DomicileCreateViewModel
            {
                ParishId = parishId,
                ParishSelectListItems = await commonRequestHelpers.ParishSelectListItems(),              
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DomicileCreateViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var result = await mediator.Send(new DomicileCreateRequest()
                    {
                        Domicile = new Domicile()
                        {
                            Id = 0,
                            ParishId = viewModel.ParishId,
                            CollectionRate = 0,
                            VendorCompensation = 0,
                            DomicileCode = viewModel.DomicileCode,
                            Name = viewModel.Name,
                            EffectiveDate = viewModel.EffectiveDate.GetValueOrDefault(),
                            TermDate = viewModel.TermDate,
                        }
                    });
                    return RedirectToAction("Details", "Domicile", new { id = result.Id });
                }
                catch (InvalidOperationException e)
                {
                    ModelState.AddModelError(string.Empty, e.Message);
                }
            }

            viewModel.ParishSelectListItems = await commonRequestHelpers.ParishSelectListItems();

            return View(viewModel);
        }
    }
}
