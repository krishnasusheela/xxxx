﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Admin.Web.Requests;
using ParishTaxTable.Admin.Web.Models.ParishDomiciles;
using System.Threading.Tasks;
using System.Linq;
using System;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ParishTaxTable.Admin.Web.Controllers
{
    public class ParishDomicileController : Controller
    {
        private readonly IMediator mediator;

        public ParishDomicileController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        public async Task<IActionResult> Details(int id)
        {
            var result = await mediator.Send(new ParishDomicileInquiryRequest { Id = id });
            result.Domiciles = result.Domiciles.OrderBy(x => x.DomicileCode);

            var viewModel = new SingleParishDomicileViewModel
            {
                ParishDomicile = result
            };         
            return View(viewModel);
        }
    }
}
