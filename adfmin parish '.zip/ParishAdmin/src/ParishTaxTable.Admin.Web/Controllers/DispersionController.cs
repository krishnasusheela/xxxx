﻿using System;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Helpers;
using ParishTaxTable.Admin.Web.Requests;
using ParishTaxTable.Admin.Web.Interfaces;
using ParishTaxTable.Admin.Web.Models.Dispersions;

namespace ParishTaxTable.Admin.Web.Controllers
{
    public class DispersionController : Controller
    {
        private readonly IMediator mediator;
        private readonly ICommonRequestHelpers commonRequestHelpers;

        public DispersionController(
            IMediator mediator, ICommonRequestHelpers commonRequestHelpers)
        {
            this.mediator = mediator;
            this.commonRequestHelpers = commonRequestHelpers;
        }
        public async Task<IActionResult> Edit(int id)
        {

            var dispersionToEdit = await mediator.Send(new DispersionInquiryRequest { Id = id });

            var parishId = await commonRequestHelpers.ParishIdFromDomicileId(dispersionToEdit.DomicileId);

            var viewModel = new DispersionViewModel()
            {
                OriginalDispersion = dispersionToEdit,
                InUseCheck = dispersionToEdit.EffectiveDate <= DateTimeOffset.Now,
                DispersionId = dispersionToEdit.Id,
                DistributionRate = dispersionToEdit.DistributionRate.GetStringPercentage(),
                DomicileId = dispersionToEdit.DomicileId,
                EffectiveDate = dispersionToEdit.EffectiveDate,
                JurisdictionId = dispersionToEdit.JurisdictionId,
                TermDate = dispersionToEdit.TermDate,
                VendorCompensation = dispersionToEdit.VendorCompensation.GetStringPercentage(),
                JurisdictionName = await commonRequestHelpers.JurisdictionName(dispersionToEdit.JurisdictionId),
                DomicileName = await commonRequestHelpers.DomicileName(dispersionToEdit.DomicileId),
                ParishId = parishId,
                ParishName = await commonRequestHelpers.ParishName(parishId)

            };

            return View(viewModel);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(DispersionViewModel dispersionViewModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var dispersion = dispersionViewModel.OriginalDispersion;

                    dispersion.VendorCompensation = dispersionViewModel.VendorCompensation.GetDecimalPercentage();
                    dispersion.DistributionRate = dispersionViewModel.DistributionRate.GetDecimalPercentage();
                    dispersion.EffectiveDate = dispersionViewModel.EffectiveDate.GetValueOrDefault();
                    dispersion.TermDate = dispersionViewModel.TermDate;

                    var result = await mediator.Send(new DispersionUpdateRequest { dispersion = dispersion });

                    return RedirectToAction("Details", "Domicile", new { id = dispersionViewModel.DomicileId });
                }
                catch (InvalidOperationException e)
                {
                    ModelState.AddModelError(string.Empty, e.Message);
                }
            }

            return View(dispersionViewModel);
        }

        [HttpGet]
        public async Task<IActionResult> Create(int domicileId, int parishId, int jurisdictionId)
        {
            var viewModel = new DispersionViewModel
            {
                ParishId = parishId,
                DomicileId = domicileId,
                JurisdictionId = jurisdictionId,
                ParishSelectListItems = await commonRequestHelpers.ParishSelectListItems(),
                JurisdictionSelectListItems = await commonRequestHelpers.JurisdictionSelectListItems(parishId),
                DomicileSelectListItems = await commonRequestHelpers.DomicileSelectListItems(parishId)
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DispersionViewModel dispersionViewModel)
        {
            if (ModelState.IsValid && dispersionViewModel.EventCommand == "Create")
            {
                try
                {
                    var parishes = await mediator.Send(new DispersionCreateRequest()
                    {
                        Dispersion = new Dispersion()
                        {
                            Id = 0,
                            DomicileId = dispersionViewModel.DomicileId,
                            DistributionRate = dispersionViewModel.DistributionRate.GetDecimalPercentage(),
                            JurisdictionId = dispersionViewModel.JurisdictionId,
                            EffectiveDate = dispersionViewModel.EffectiveDate.GetValueOrDefault(),
                            TermDate = dispersionViewModel.TermDate,
                            VendorCompensation = dispersionViewModel.VendorCompensation.GetDecimalPercentage(),
                            IsInvalidDispersion = false
                        }
                    });
                    return RedirectToAction("Details", "Domicile", new { id = dispersionViewModel.DomicileId });
                }
                catch (InvalidOperationException e)
                {
                    ModelState.AddModelError(string.Empty, e.Message);
                }
            }

            dispersionViewModel.ParishSelectListItems = await commonRequestHelpers.ParishSelectListItems();
            dispersionViewModel.JurisdictionSelectListItems = await commonRequestHelpers.JurisdictionSelectListItems(dispersionViewModel.ParishId);
            dispersionViewModel.DomicileSelectListItems = await commonRequestHelpers.DomicileSelectListItems(dispersionViewModel.ParishId);

            if (dispersionViewModel.EventCommand != "Create")
                ModelState.Clear();
            dispersionViewModel.EventCommand = "";

            return View(dispersionViewModel);
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id, int domicileId)
        {
            var deletedContact = await mediator.Send(new DispersionDeleteRequest
            {
                Id = id
            });

            return RedirectToAction("Details", "Domicile", new { id = domicileId });
        }


        public async Task<IActionResult> Replace(int id, DateTimeOffset? originalTermDate)
        {
            var dispersionToReplace = await mediator.Send(new DispersionInquiryRequest { Id = id });

            var parishId = await commonRequestHelpers.ParishIdFromDomicileId(dispersionToReplace.DomicileId);

            var viewModel = new DispersionReplaceViewModel()
            {
                InvalidatedId = id,
                ParishId = parishId,
                DomicileId = dispersionToReplace.DomicileId,
                DistributionRate = dispersionToReplace.DisplayedDistributionRate,
                EffectiveDate = dispersionToReplace.EffectiveDate,
                JurisdictionId = dispersionToReplace.JurisdictionId,
                TermDate = originalTermDate,
                VendorCompensation = dispersionToReplace.DisplayedVendorCompensation,
                ParishSelectListItems = await commonRequestHelpers.ParishSelectListItems(),
                JurisdictionSelectListItems = await commonRequestHelpers.JurisdictionSelectListItems(parishId),
                DomicileSelectListItems = await commonRequestHelpers.DomicileSelectListItems(parishId),
                OriginalTermDate = originalTermDate
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Replace(DispersionReplaceViewModel dispersionReplaceViewModel, bool additionalReplaceDispersion)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await mediator.Send(new DispersionCreateRequest()
                    {
                        Dispersion = new Dispersion()
                        {
                            Id = 0,
                            DomicileId = dispersionReplaceViewModel.DomicileId,
                            DistributionRate = dispersionReplaceViewModel.DistributionRate.GetDecimalPercentage(),
                            JurisdictionId = dispersionReplaceViewModel.JurisdictionId,
                            EffectiveDate = dispersionReplaceViewModel.EffectiveDate.GetValueOrDefault(),
                            TermDate = dispersionReplaceViewModel.TermDate,
                            VendorCompensation = dispersionReplaceViewModel.VendorCompensation.GetDecimalPercentage(),
                            IsInvalidDispersion = false
                        },
                        InvalidatedId = dispersionReplaceViewModel.InvalidatedId
                    });
                    if (additionalReplaceDispersion)
                        return RedirectToAction("Replace", "Dispersion", new { id = dispersionReplaceViewModel.InvalidatedId, originalTermDate = dispersionReplaceViewModel.OriginalTermDate });

                    return RedirectToAction("Details", "Domicile", new { id = dispersionReplaceViewModel.DomicileId });
                }
                catch (InvalidOperationException e)
                {
                    ModelState.AddModelError(string.Empty, e.Message);
                }
            }
            return View(dispersionReplaceViewModel);
        }

        [HttpGet]
        public async Task<IActionResult> Invalidate(int id, bool replaceDispersion)
        {
            var dispersionToInvalidate = await mediator.Send(new DispersionInquiryRequest { Id = id });

            var originalTermDate = dispersionToInvalidate.TermDate;

            dispersionToInvalidate.IsInvalidDispersion = true;
            if (!dispersionToInvalidate.IsHistorical())
            {
                dispersionToInvalidate.TermDate = DateTimeOffset.Now.Date;
            }

            try
            {
                await mediator.Send(new DispersionUpdateRequest { dispersion = dispersionToInvalidate });

                if (replaceDispersion == true)
                    return RedirectToAction("Replace", "Dispersion", new { id = id, originalTermDate = originalTermDate });

            }
            catch (InvalidOperationException e)
            {
                ModelState.AddModelError(string.Empty, e.Message);
            }
            return RedirectToAction("Details", "Domicile", new { id = dispersionToInvalidate.DomicileId });
        }

        [HttpPost]
        public async Task<IActionResult> UpdateReplaceSelects(DispersionReplaceViewModel dispersionReplaceViewModel)
        {
            dispersionReplaceViewModel.DomicileSelectListItems =
                await commonRequestHelpers.DomicileSelectListItems(dispersionReplaceViewModel.ParishId);
            dispersionReplaceViewModel.JurisdictionSelectListItems =
                await commonRequestHelpers.JurisdictionSelectListItems(dispersionReplaceViewModel.ParishId);

            ModelState.Clear();

            return PartialView("_ReplaceForm", dispersionReplaceViewModel);
        }

    }
}
