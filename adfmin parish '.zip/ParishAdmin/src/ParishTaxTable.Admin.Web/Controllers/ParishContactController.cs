﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Admin.Web.Models.ParishContacts;
using ParishTaxTable.Admin.Web.Requests;
using System.Linq;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Controllers
{
    public class ParishContactController : Controller
    {
        private readonly IMediator mediator;

        public ParishContactController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        public async Task<IActionResult> Details(int id)
        {
            var result = await mediator.Send(new ParishContactInquiryRequest { Id = id });
            result.Contacts = result.Contacts.OrderBy(x => x.EftCode);

            var viewModel = new SingleParishContactViewModel
            {
                ParishContact = result
            };
            return View(viewModel);
        }
    }
}