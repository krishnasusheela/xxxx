﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Controllers.Api
{
    [Route("api/[controller]")]
    public class ParishesController
        : Controller
    {
        private readonly IMediator mediator;

        public ParishesController(
           IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet("{id}/NextDomicileCode")]
        public async Task<IActionResult> GetNextDomicileCode(int id)
        {
            try
            {
                var url = "/Parishes/" + id + "/NextDomicileCode";
                var result = await mediator.Send(new ApiPttGetRequest() { Url = url });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
