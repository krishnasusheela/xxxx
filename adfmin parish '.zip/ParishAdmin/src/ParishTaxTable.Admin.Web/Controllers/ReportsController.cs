﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Admin.Web.Interfaces;
using ParishTaxTable.Admin.Web.Models.Reports;
using ParishTaxTable.Admin.Web.Requests;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Controllers
{

    public class ReportsController
        : Controller
    {
        private readonly IMediator mediator;
        private readonly ICommonRequestHelpers commonRequestHelpers;

        public ReportsController(
            IMediator mediator, ICommonRequestHelpers commonRequestHelpers)
        {
            this.mediator = mediator;
            this.commonRequestHelpers = commonRequestHelpers;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var reportDescriptions = await mediator.Send(new ReportsIndexRequest());

            var viewModel = new ReportsIndexViewModel
            {
                Reports = reportDescriptions
            };

            return View(viewModel);
        }
    }
}
