﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Admin.Web.Requests;
using ParishTaxTable.Admin.Web.Models.Parishes;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Controllers
{
    public class ParishController
        : Controller
    {
        private readonly IMediator mediator;

        public ParishController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        public async Task<IActionResult> Index()
        {
            var parishes = await mediator.Send(new ParishesInquiryRequest());
            var domiciles = await mediator.Send(new DomicilesInquiryRequest());
            var viewModel = new ParishesViewModel
            {
                Parishes = parishes,
                Domiciles = domiciles
            };

            return View(viewModel);
        }

        public async Task<IActionResult> Details(int id)
        {
            var parish = await mediator.Send(new ParishInquiryRequest { Id = id });
            var viewModel = new SingleParishViewModel
            {
                Parish = parish
            };

            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> DomicileByCode(ParishesViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var result = await mediator.Send
                (new DomicileCodeInquiryRequest { DomicileCode = viewModel.DomicileCode });

                if (result != null)
                {
                    return RedirectToAction("Details", "Domicile", new { id = result.Id });
                }
            }

            viewModel.Parishes = await mediator.Send(new ParishesInquiryRequest());
            viewModel.Domiciles = await mediator.Send(new DomicilesInquiryRequest());

            return View("Index", viewModel);
        }
    }
}
