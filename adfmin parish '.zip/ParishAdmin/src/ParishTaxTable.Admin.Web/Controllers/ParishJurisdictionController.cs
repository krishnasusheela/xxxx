﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Admin.Web.Requests;
using ParishTaxTable.Admin.Web.Models.ParishJurisdictions;
using System.Threading.Tasks;
using System.Linq;
using ParishTaxTable.Admin.Web.Interfaces;
using ParishTaxTable.Admin.Web.Helpers;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ParishTaxTable.Admin.Web.Controllers
{
    public class ParishJurisdictionController : Controller
    {
        private readonly IMediator mediator;
        private readonly ICommonRequestHelpers commonRequestHelpers;

        public ParishJurisdictionController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        public async Task<IActionResult> Details(int id)
        {
            var result = await mediator.Send(new ParishJurisdictionInquiryRequest { Id = id });
            var parish = await mediator.Send(new ParishDomicileInquiryRequest { Id = id });

            var jurisdictions = parish
                .GetJurisdictionIdsOfParish()
                .ToList();

            var viewModel = new SingleParishJurisdictionViewModel
            {
                ParishJurisdiction = result,
                InUseJurisdictionIds = jurisdictions                
            };

            return View(viewModel);
        }
    }
}
