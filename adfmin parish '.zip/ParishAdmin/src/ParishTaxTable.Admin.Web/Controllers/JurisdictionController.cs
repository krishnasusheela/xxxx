﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Admin.Web.Requests;
using ParishTaxTable.Admin.Web.Models.Jurisdictions;
using System.Threading.Tasks;
using System;

namespace ParishTaxTable.Admin.Web.Controllers
{
    public class JurisdictionController
        : Controller
    {
        private readonly IMediator mediator;

        public JurisdictionController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> Create(int parishId, int domicileId, bool fromDisperionController)
        {

            var parishes = await mediator.Send(new ParishesInquiryRequest());
            var jurisdictionTypes = await mediator.Send(new JurisdictionTypesInquiryRequest());

            var viewModel = new JurisdictionCreateViewModel
            {
                Parishes = parishes,
                JurisdictionTypes = jurisdictionTypes,
                ParishId = parishId,
                DomicileId = domicileId,
                DispersionCreate = fromDisperionController
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(JurisdictionCreateViewModel createJurisdictionModel)
        {

            if (ModelState.IsValid)
            {
                var jurisdiction = await mediator.Send(new JurisdictionCreateRequest()
                {
                    Jurisdiction = createJurisdictionModel.Jurisdiction
                });

                if (createJurisdictionModel.DispersionCreate)
                    return RedirectToAction("Create", "Dispersion",
                        new
                        {
                            domicileId = createJurisdictionModel.DomicileId,
                            parishId = createJurisdictionModel.ParishId,
                            jurisdictionId = jurisdiction.Id
                        });
                return RedirectToAction("Details", "ParishJurisdiction",
                    new { id = createJurisdictionModel.Jurisdiction.ParishId });
            }
            else
            {
                var parishes = await mediator.Send(new ParishesInquiryRequest());
                var jurisdictionTypes = await mediator.Send(new JurisdictionTypesInquiryRequest());

                createJurisdictionModel.Parishes = parishes;
                createJurisdictionModel.JurisdictionTypes = jurisdictionTypes;

                return View(createJurisdictionModel);
            }
        }

        [HttpGet]       
        public async Task<IActionResult> Retire(int id)
        {
            var jurisdiction = await mediator.Send(new JurisdictionInquiryRequest { Id = id });
            jurisdiction.RetireDate = DateTimeOffset.Now;
            
            await mediator.Send(new JurisdictionUpdateRequest
            {
                Jurisdiction = jurisdiction
            });                          
                                                  
            return RedirectToAction("Details", "ParishJurisdiction", new { id = jurisdiction.ParishId });
        }
     
        [HttpGet] 
        public async Task<IActionResult> Reactivate(int id)
        {
            var jurisdiction = await mediator.Send(new JurisdictionInquiryRequest { Id = id });
            jurisdiction.RetireDate = null;

            await mediator.Send(new JurisdictionUpdateRequest
            {
                Jurisdiction = jurisdiction
            });

            return RedirectToAction("Details", "ParishJurisdiction", new { id = jurisdiction.ParishId });
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var jurisdiction = await mediator.Send(new JurisdictionInquiryRequest { Id = id });
            var parish = await mediator.Send(new ParishInquiryRequest { Id = jurisdiction.ParishId });
            var jurisdictionTypes = await mediator.Send(new JurisdictionTypesInquiryRequest());

            var viewModel = new JurisdictionEditViewModel
            {
                Jurisdiction = jurisdiction,
                Parish = parish,
                JurisdictionTypes = jurisdictionTypes
            };
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, JurisdictionEditViewModel editJurisdictionModel)
        {
            if (ModelState.IsValid)
            {
                var parishes = await mediator.Send(new JurisdictionUpdateRequest()
                {
                    Jurisdiction = editJurisdictionModel.Jurisdiction
                });

                return RedirectToAction("Details", "ParishJurisdiction", new { id = editJurisdictionModel.Jurisdiction.ParishId });
            }
            else
            {
                editJurisdictionModel.Parish = await mediator.Send(new ParishInquiryRequest { Id = editJurisdictionModel.Jurisdiction.ParishId });
                editJurisdictionModel.JurisdictionTypes = await mediator.Send(new JurisdictionTypesInquiryRequest());


                return View(editJurisdictionModel);
            }
        }
    }
}
