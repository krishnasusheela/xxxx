﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Models.Contacts;
using ParishTaxTable.Admin.Web.Requests;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Controllers
{
    public class ContactController
        : Controller
    {
        private readonly IMediator mediator;

        public ContactController(
            IMediator mediator)
        {
            this.mediator = mediator;
        }
        public async Task<IActionResult> Details(int id)
        {
            var contactResult = await mediator.Send(new ContactInquiryRequest { Id = id });
            var parishResult = await mediator.Send(new ParishInquiryRequest { Id = contactResult.ParishId });

            var viewModel = new ContactDetailsViewModel
            {
                Contact = contactResult,
                Parish = parishResult
            };
            return View(viewModel);

        }

        [HttpGet]
        public async Task<IActionResult> Create(string parishId)
        {
            var parishes = await mediator.Send(new ParishesInquiryRequest());

            var viewModel = new ContactCreateViewModel
            {
                Parishes = parishes,
                ParishId = parishId
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ContactCreateViewModel contactCreateViewModel)
        {
            if (ModelState.IsValid)
            {
                var parishes = await mediator.Send(new ContactCreateRequest()
                {
                    Contact = contactCreateViewModel.Contact
                });

                return RedirectToAction("Details", "ParishContact", new { id = contactCreateViewModel.Contact.ParishId });
            }
            else
            {
                var parishes = await mediator.Send(new ParishesInquiryRequest());

                contactCreateViewModel.Parishes = parishes;

                return View(contactCreateViewModel);
            }
        }

        [HttpGet]
        public async Task<IActionResult> Retire(int id)
        {
            var deletedContact = await mediator.Send(new ContactRetireRequest
            {
                Id = id
            });

            return RedirectToAction("Details", "ParishContact", new { id = deletedContact.ParishId });            
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var contactResult = await mediator.Send(new ContactInquiryRequest { Id = id });
            var parishResult = await mediator.Send(new ParishInquiryRequest { Id = contactResult.ParishId });

            var viewModel = new ContactEditViewModel
            {
                Contact = contactResult,
                Parish = parishResult
            };
            return View(viewModel);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ContactEditViewModel contactEditViewModel)
        {
            if (ModelState.IsValid)
            {
                var parishes = await mediator.Send(new ContactUpdateRequest()
                {
                    Contact = contactEditViewModel.Contact
                });

                return RedirectToAction("Details", "ParishContact", new { id = contactEditViewModel.Contact.ParishId });
            }
            else
            {
                return View(contactEditViewModel);
            }
        }
    }
}