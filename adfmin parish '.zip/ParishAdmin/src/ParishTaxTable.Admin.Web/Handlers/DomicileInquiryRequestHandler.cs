﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class DomicileInquiryRequestHandler
      : IRequestHandler<DomicileInquiryRequest,Domicile>
    {
        private readonly IDomicileService service;

        public DomicileInquiryRequestHandler(IDomicileService service)
        {
            this.service = service;
        }

        public async Task<Domicile> Handle(
            DomicileInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await service.DomicileInquiry(
                request.Id,
                request.SearchDate);
        }
    }   
}
