﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class DomicileCreateRequestHandler
        : IRequestHandler<DomicileCreateRequest, Domicile>
    {
        private readonly IDomicileService service;

        public DomicileCreateRequestHandler(IDomicileService service)
        {
            this.service = service;
        }
        public async Task<Domicile> Handle(
            DomicileCreateRequest request,
            CancellationToken cancellationToken)
        {
            return await service.DomicileCreate(
                 request.Domicile);
        }
    }
}
