﻿using MediatR;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;
using System.Threading;
using System.Threading.Tasks;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;

namespace ParishTaxTable.Admin.Web.Handlers
{

    public class ParishDomicileInquiryRequestHandler
        : IRequestHandler<ParishDomicileInquiryRequest, ParishDomicile>
    {
        private readonly IParishService service;

        public ParishDomicileInquiryRequestHandler(IParishService service)
        {
            this.service = service;
        }

        public async Task<ParishDomicile> Handle(
            ParishDomicileInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await service.ParishDomicileInquiry(
                request.Id);
        }
    }
}
