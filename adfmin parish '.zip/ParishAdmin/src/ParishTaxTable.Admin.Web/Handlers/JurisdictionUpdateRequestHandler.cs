﻿using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Configurations;
using ParishTaxTable.Admin.Web.Requests;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class JurisdictionUpdateRequestHandler
        : IRequestHandler<JurisdictionUpdateRequest, Jurisdiction>
    {
        private readonly IJurisdictionService service;

        public JurisdictionUpdateRequestHandler(IJurisdictionService service)
        {
            this.service = service;
        }

        public async Task<Jurisdiction> Handle(
            JurisdictionUpdateRequest request,
            CancellationToken cancellationToken)
        {
            return await service.JurisdictionUpdate(
                request.Jurisdiction);
        }
    }
}
