﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Web.Requests;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class DispersionCreateRequestHandler
        : IRequestHandler<DispersionCreateRequest, Dispersion>
    {
        private readonly IDispersionService service;

        public DispersionCreateRequestHandler(IDispersionService service)
        {
            this.service = service;
        }

        public async Task<Dispersion> Handle(
            DispersionCreateRequest request,
            CancellationToken cancellationToken)
        {

            if (request.InvalidatedId.HasValue)
            {

                return await service.DispersionReplace(
                    request.Dispersion,request.InvalidatedId.Value);

            }
            else {

                return await service.DispersionCreate(
                    request.Dispersion);

            }
      
        }
    }
}
