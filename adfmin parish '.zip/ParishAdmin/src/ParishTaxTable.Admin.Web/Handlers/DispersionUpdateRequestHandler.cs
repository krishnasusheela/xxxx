﻿using MediatR;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using System.Threading;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class DispersionUpdateRequestHandler
        : IRequestHandler<DispersionUpdateRequest, Dispersion>
    {
        private readonly IDispersionService service;

        public DispersionUpdateRequestHandler(IDispersionService service)
        {
            this.service = service;
        }

        public async Task<Dispersion> Handle(
            DispersionUpdateRequest request,
            CancellationToken cancellationToken)
        {

            return await service.DispersionUpdate(
                    request.dispersion);
        }
    }
}
