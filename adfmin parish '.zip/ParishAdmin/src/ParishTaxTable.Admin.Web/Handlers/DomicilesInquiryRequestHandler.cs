﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Configurations;
using ParishTaxTable.Admin.Web.Requests;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class DomicilesInquiryRequestHandler
       : IRequestHandler<DomicilesInquiryRequest, IEnumerable<Domicile>>
    {
        private readonly IDomicileService service;

        public DomicilesInquiryRequestHandler(IDomicileService service)
        {
            this.service = service;
        }

        public async Task<IEnumerable<Domicile>> Handle(
            DomicilesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await service.DomicilesInquiry();
        }
    }
}
