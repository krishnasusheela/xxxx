﻿using MediatR;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Handlers.Api
{
    public class ApiPttGetRequestHandler
        :IRequestHandler<ApiPttGetRequest, string>
    {
        private readonly IApiPttService service;

        public ApiPttGetRequestHandler(IApiPttService service)
        {
            this.service = service;
        }

        public async Task<string> Handle(
            ApiPttGetRequest request,
            CancellationToken cancellationToken)
        {
            return await service.ApiInquiry(request.Url);
        }
    }
}
