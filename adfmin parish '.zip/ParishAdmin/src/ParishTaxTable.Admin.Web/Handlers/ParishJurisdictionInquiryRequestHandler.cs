﻿using MediatR;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;
using System.Threading;
using System.Threading.Tasks;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;

namespace ParishTaxTable.Admin.Web.Handlers
{

    public class ParishJurisdictionInquiryRequestHandler
        : IRequestHandler<ParishJurisdictionInquiryRequest, ParishJurisdiction>
    {
        private readonly IParishService service;

        public ParishJurisdictionInquiryRequestHandler(IParishService service)
        {
            this.service = service;
        }
        public async Task<ParishJurisdiction> Handle(
            ParishJurisdictionInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await service.ParishJurisdictionInquiry(
                request.Id);
        }
    }
}
