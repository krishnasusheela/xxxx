﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class JurisdictionCreateRequestHandler
        : IRequestHandler<JurisdictionCreateRequest, Jurisdiction>
    {
        private readonly IJurisdictionService service;

        public JurisdictionCreateRequestHandler(IJurisdictionService service)
        {
            this.service = service;
        }

        public async Task<Jurisdiction> Handle(
            JurisdictionCreateRequest request,
            CancellationToken cancellationToken)
        {
            return await service.JurisdictionCreate(
                request.Jurisdiction);
        }
    }
}
