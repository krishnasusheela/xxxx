﻿using MediatR;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class ParishesInquiryRequestHandler
        : IRequestHandler<ParishesInquiryRequest, IEnumerable<Parish>>
    {
        private readonly IParishService service;

        public ParishesInquiryRequestHandler(IParishService service)
        {
            this.service = service;
        }

        public async Task<IEnumerable<Parish>> Handle(
            ParishesInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await service.ParishesInquiry();
        }
    }
}
