﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Configurations;
using ParishTaxTable.Admin.Web.Requests;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class JurisdictionTypesInquiryRequestHandler
        : IRequestHandler<JurisdictionTypesInquiryRequest, IEnumerable<JurisdictionType>>
    {
        private readonly IJurisdictionService service;

        public JurisdictionTypesInquiryRequestHandler(IJurisdictionService service)
        {
            this.service = service;
        }

        public async Task<IEnumerable<JurisdictionType>> Handle(
            JurisdictionTypesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await service.JurisdictionTypesInquiry();
        }
    }
}
