﻿using MediatR;
using Microsoft.Extensions.Options;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Configurations;
using ParishTaxTable.Admin.Web.Helpers;
using ParishTaxTable.Admin.Web.Requests;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class ReportsIndexRequestHandler
        : IRequestHandler<ReportsIndexRequest, IEnumerable<ReportDescription>>
    {
        private readonly WebApiServer webApiServer;

        public ReportsIndexRequestHandler(IOptions<WebApiServer> webApiServer)
        {
            this.webApiServer = webApiServer.Value;
        }

        public async Task<IEnumerable<ReportDescription>> Handle(
            ReportsIndexRequest request,
            CancellationToken cancellationToken)
        {
            IEnumerable<ReportDescription> reportDescriptions = ReportsHelper.GetReportDescriptions();

            return reportDescriptions;
        }
    }
}
