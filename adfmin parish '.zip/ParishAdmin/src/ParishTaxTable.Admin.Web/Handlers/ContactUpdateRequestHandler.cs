﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;


namespace ParishTaxTable.Admin.Web.Handlers
{
    public class ContactUpdateRequestHandler
        : IRequestHandler<ContactUpdateRequest, Contact>
    {
        private readonly IContactService service;

        public ContactUpdateRequestHandler(IContactService service)
        {
            this.service = service;
        }

        public async Task<Contact> Handle(
            ContactUpdateRequest request,
            CancellationToken cancellationToken)
        {
            return await service.ContactUpdate(
                request.Contact);
        }
    }
}
