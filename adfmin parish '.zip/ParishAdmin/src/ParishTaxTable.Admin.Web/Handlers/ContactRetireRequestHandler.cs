﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class ContactRetireRequestHandler
        : IRequestHandler<ContactRetireRequest, Contact>
    {
        private readonly IContactService service;

        public ContactRetireRequestHandler(IContactService service)
        {
            this.service = service;
        }

        public async Task<Contact> Handle(
            ContactRetireRequest request,
            CancellationToken cancellationToken)
        {
            return await service.ContactRetire(request.Id);
        }
    }
}