﻿using MediatR;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using System.Threading;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class DispersionInquiryRequestHandler
        : IRequestHandler<DispersionInquiryRequest, Dispersion>
    {
        private readonly IDispersionService service;

        public DispersionInquiryRequestHandler(IDispersionService service)
        {
            this.service = service;
        }

        public async Task<Dispersion> Handle(
            DispersionInquiryRequest request,
            CancellationToken cancellationToken)
        {

            return await service.DispersionInquiry(
                request.Id);
        }
    }
}
