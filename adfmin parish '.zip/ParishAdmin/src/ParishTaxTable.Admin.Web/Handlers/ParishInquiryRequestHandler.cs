﻿using MediatR;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Requests;
using System.Threading;
using System.Threading.Tasks;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;

namespace ParishTaxTable.Admin.Web.Handlers
{
    public class ParishInquiryRequestHandler
        : IRequestHandler<ParishInquiryRequest, Parish>
    {
        private readonly IParishService service;

        public ParishInquiryRequestHandler(IParishService service)
        {
            this.service = service;
        }

        public async Task<Parish> Handle(
            ParishInquiryRequest request, 
            CancellationToken cancellationToken)
        {
            return await service.ParishInquiry(
                request.Id);
        }        
    }
}
