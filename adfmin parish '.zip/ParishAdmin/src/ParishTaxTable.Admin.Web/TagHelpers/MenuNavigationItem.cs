﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.TagHelpers;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Linq;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Web.TagHelpers
{
    [HtmlTargetElement("menunavitem")]
    [HtmlTargetElement(Attributes = nameof(Icon))]
    public class MenuNavigationItem
        : AnchorTagHelper
    {
        public MenuNavigationItem(
            IHtmlGenerator generator)
            : base(generator)
        {

        }
        
        public string Icon { get; set; }

        public async override Task ProcessAsync(
            TagHelperContext context, 
            TagHelperOutput output)
        {
            await base.ProcessAsync(context, output);

            var content = await output.GetChildContentAsync();
            var title = content.GetContent();
            var hrefAttr = output.Attributes.FirstOrDefault(a => a.Name == "href");

            output.TagName = "li";
            output.Attributes.Add("class", "nav-item");

            var anchor = new TagBuilder("a");
            anchor.AddCssClass("nav-link");
            if(ShouldBeActive())
            {
                anchor.AddCssClass("active");
            }            
            if(hrefAttr != null)
            {
                anchor.MergeAttribute("href", hrefAttr.Value.ToString());
                output.Attributes.Remove(hrefAttr);
            }
            anchor.InnerHtml.AppendHtml(CreateIcon(Icon));
            anchor.InnerHtml.Append(" ");
            anchor.InnerHtml.Append(title);

            output.Content.AppendHtml(anchor); 
        }

        private bool ShouldBeActive()
        {
            var currentController = ViewContext.RouteData.Values["Controller"].ToString();
            if(!string.IsNullOrWhiteSpace(Controller) 
                && currentController.ToLower() == Controller.ToLower())
            {
                return true;
            }
            return false;
        }

        private TagBuilder CreateIcon(string iconName)
        {
            var icon = new TagBuilder("i");
            icon.AddCssClass("fas");
            icon.AddCssClass(iconName);

            var span = new TagBuilder("span");
            span.AddCssClass("icon");
            span.InnerHtml.AppendHtml(icon);

            return span;
        }
    }
}
