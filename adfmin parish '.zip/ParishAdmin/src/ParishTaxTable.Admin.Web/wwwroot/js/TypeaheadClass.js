class Typeahead {

    constructor(inputName, choicesList, errorMessage) {
        if (!inputName || !choicesList) return false;
        let self = this; // js hax0rz
        this.inputName = inputName; // required
        this.choicesList = choicesList; // required
        this.errorMessage = errorMessage;
        this.input = document.getElementsByName(inputName)[0];
        this.resultsCSSClass = "";
        this.selectedResult = -1;
        // default functions to be overwritten
        this.match = function (choice) {
            // default: "name contains" logic
            return (choice[1].indexOf(this.input.value.toString().toUpperCase()) != -1);
        };
        this.render = function (result) {
            // default: display name (and bold typed text)
            let html = "<span class='name'>";
            let needle = this.input.value.toString().toUpperCase();
            html += result[1].toString().substring(0, result[1].indexOf(needle));
            html += '<strong>' + result[1].toString().substr(result[1].indexOf(needle), (needle.length)) + '</strong>';
            html += result[1].toString().substr(result[1].indexOf(needle) + needle.length);
            html += "</span>";
            return html;
        };

        this.input.addEventListener("input", function (e) {
            self.update();
        });
        this.input.addEventListener("keydown", function (e) {
            if (e.keyCode == 40) { // key: ARROW DOWN
                let results = document.getElementById(self.inputName + "ResultsList");
                if (results) {
                    self.selectedResult++;
                    self.setActive();
                }
            } else if (e.keyCode == 38) { // key: ARROW UP
                let results = document.getElementById(self.inputName + "ResultsList");
                if (results) {
                    e.preventDefault();
                    self.selectedResult--;
                    self.setActive();
                }
            } else if (e.keyCode == 13) { // key: ENTER 
                e.preventDefault();
                let results = document.getElementById(self.inputName + "ResultsList");
                if (results) {
                    self.input.value = results.children[self.selectedResult].getElementsByTagName('input')[0].value;
                    self.submit();
                }
            }
        });

    }

    setActive() { 
        let results = document.getElementById(this.inputName + "ResultsList").children;
        if (results.length > 0) {
            if (this.selectedResult < 0) this.selectedResult = 0;
            if (this.selectedResult > (results.length - 1)) this.selectedResult = (results.length - 1);
        }
        for (let i = 0; i < results.length; i++) {
            if (i == this.selectedResult) {
                results[i].classList.add("result-active");
            } else {
                results[i].classList.remove("result-active");
            }
        }
    }

    update() { // update the list of choices using the search function
        let self = this;
        this.close()
        this.setError('');
        if (this.input.value == '') { return false; }
        let resultsListContainer = null;
        for (let i = 0; i < this.choicesList.length; i++) {
            if (this.match(this.choicesList[i])) {
                if (resultsListContainer == null) {
                    resultsListContainer = document.createElement("DIV");
                    resultsListContainer.setAttribute('class', 'resultslist');
                    resultsListContainer.setAttribute('id', this.inputName + 'ResultsList');
                    this.input.parentNode.parentNode.appendChild(resultsListContainer);
                }
                let result = document.createElement("DIV");
                result.setAttribute("class", "result")
                if (this.resultsCSSClass) result.classList.add(this.resultsCSSClass);
                result.innerHTML = this.render(this.choicesList[i]);
                result.innerHTML += '<input type="hidden" value="' + this.choicesList[i][0] + '">';
                result.addEventListener("click", function () {
                    self.input.value = this.getElementsByTagName('input')[0].value;
                    self.submit();
                });
                resultsListContainer.appendChild(result);
            }
        }
        if (resultsListContainer == null) {
            this.setError(this.errorMessage);
        } else {
            this.selectedResult = 0;
            this.setActive();
        }
    }

    close() {
        let resultsList = document.getElementById(this.inputName + "ResultsList");
        if (resultsList != null) {
            let previousResults = resultsList.children;
            while (previousResults.length > 0)
                previousResults[0].parentNode.removeChild(previousResults[0]);
            resultsList.parentNode.removeChild(resultsList);
        }
    }

    setError(text) {
        document.getElementById(this.inputName + "-Error").innerHTML = text;
    }

    validate() {
        return (this.input.value != "" && document.getElementById(this.inputName + "-Error").innerHTML == "");
    }

    submit() {
        this.close();
        if (this.validate()) {
            this.input.form.submit();
        }
    }
}