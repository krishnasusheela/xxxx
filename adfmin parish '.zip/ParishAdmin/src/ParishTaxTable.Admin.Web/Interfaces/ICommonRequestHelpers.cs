﻿using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ParishTaxTable.Admin.Web.Interfaces
{
    public interface ICommonRequestHelpers
    {
        Task<IList<SelectListItem>> ParishSelectListItems();
        Task<IList<SelectListItem>> DomicileSelectListItems(int id);
        Task<IList<SelectListItem>> JurisdictionSelectListItems(int id);
        Task<string> JurisdictionName(int id);
        Task<string> DomicileName(int id);
        Task<string> ParishName(int id);
        Task<int> ParishIdFromDomicileId(int id);
      
    }
}
