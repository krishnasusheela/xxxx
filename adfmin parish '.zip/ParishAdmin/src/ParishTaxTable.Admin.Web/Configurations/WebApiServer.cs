﻿namespace ParishTaxTable.Admin.Web.Configurations
{
    public class WebApiServer
    {
        public string ParishTaxTableApi { get; set; }
    }
}
