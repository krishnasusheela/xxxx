﻿using Newtonsoft.Json;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Infrastructure.Services.Taxes
{
    public class DomicileService : IDomicileService
    {
        private readonly HttpClient client;

        public DomicileService(HttpClient client)
        {
            this.client = client;
        }

        public async Task<Domicile> DomicileCreate(Domicile domicileToCreate)
        {
            var uri = "/api/Domiciles/";

            var jsonDomicile = JsonConvert.SerializeObject(domicileToCreate);
            var content = new StringContent(jsonDomicile.ToString(), Encoding.UTF8, "application/json");

            var response = await client.PostAsync(uri, content);

            if (!response.IsSuccessStatusCode)
            {
                var postresponse = await response.Content.ReadAsStringAsync();
                if (!string.IsNullOrEmpty(postresponse))
                    throw new InvalidOperationException(postresponse);
            }

            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var domicile = JsonConvert.DeserializeObject<Domicile>(stringResult);

            return domicile;
        }

        public async Task<Domicile> DomicileUpdate(Domicile domicileToUpdate)
        {
            var uri = $"/api/Domiciles/{domicileToUpdate.Id}";

            var jsonDomicile = JsonConvert.SerializeObject(domicileToUpdate);
            var content = new StringContent(jsonDomicile.ToString(), Encoding.UTF8, "application/json");

            var response = await client.PutAsync(uri, content);

            if (!response.IsSuccessStatusCode)
            {
                var postresponse = await response.Content.ReadAsStringAsync();
                if (!string.IsNullOrEmpty(postresponse))
                    throw new InvalidOperationException(postresponse);
            }

            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var domicile = JsonConvert.DeserializeObject<Domicile>(stringResult);

            return domicile;
        }

        public async Task<IEnumerable<Domicile>> DomicilesInquiry()
        {
            var uri = $"/api/Domiciles";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var domiciles = JsonConvert.DeserializeObject<List<Domicile>>(stringResult);

            return domiciles;
        }
        
        public async Task<Domicile> DomicileInquiry(int id , DateTimeOffset? date)
        {
            var uri = date.HasValue
                ? $"/api/Domiciles/{id}?date={date.Value}"
                : $"/api/Domiciles/{id}";
            
            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var domicile = JsonConvert.DeserializeObject<Domicile>(stringResult);

            return domicile;
        }

        public async Task<Domicile> DomicileCodeInquiry(string domicileCode)
        {
            var uri = $"/api/DomicileCodes/{domicileCode}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var domicile = JsonConvert.DeserializeObject<Domicile>(stringResult);

            return domicile;
        }

    }
}
