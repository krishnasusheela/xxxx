﻿using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Infrastructure.Services.Taxes
{
    public class ApiPttService
        :IApiPttService
    {
        private readonly HttpClient client;

        public ApiPttService(HttpClient client)
        {
            this.client = client;
        }

        public async Task<string> ApiInquiry(string url)
        {
            var uri = $"/api" + url;
            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();

            return stringResult;
        }
    }
}
