﻿using Newtonsoft.Json;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Infrastructure.Services.Taxes
{
    public class ContactService : IContactService
    {
        private readonly HttpClient client;

        public ContactService(HttpClient client)
        {
            this.client = client;
        }

        public async Task<Contact> ContactCreate(Contact contactToCreate)
        {
            var uri = "/api/Contacts/";

            var jsonContact = JsonConvert.SerializeObject(contactToCreate);
            var content = new StringContent(jsonContact.ToString(), Encoding.UTF8, "application/json");

            var response = await client.PostAsync(uri, content);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var contact = JsonConvert.DeserializeObject<Contact>(stringResult);

            return contact;
        }

        public async Task<Contact> ContactInquiry(int id)
        {
            var uri = $"/api/Contacts/{id}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var contact = JsonConvert.DeserializeObject<Contact>(stringResult);

            return contact;
        
        }
        public async Task<Contact> ContactRetire(int id)
        {
            var uri = $"/api/Contacts/{id}";


            var jsonContact = JsonConvert.SerializeObject(id);
            var content = new StringContent(jsonContact.ToString(), Encoding.UTF8, "application/json");

            var response = await client.DeleteAsync(uri, default(CancellationToken));
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var contact = JsonConvert.DeserializeObject<Contact>(stringResult);

            return contact;

        }
        public async Task<Contact> ContactUpdate(Contact contactToUpdate)
        {
            var uri = $"/api/Contacts/{contactToUpdate.Id}";


            var jsonContact = JsonConvert.SerializeObject(contactToUpdate);
            var content = new StringContent(jsonContact.ToString(), Encoding.UTF8, "application/json");

            var response = await client.PutAsync(uri, content);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var contact = JsonConvert.DeserializeObject<Contact>(stringResult);

            return contact;

        }
    }
}
