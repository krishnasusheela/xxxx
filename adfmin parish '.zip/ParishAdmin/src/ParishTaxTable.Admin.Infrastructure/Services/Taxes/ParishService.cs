﻿using Newtonsoft.Json;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Infrastructure.Services.Taxes
{
    public class ParishService
        : IParishService
    {
        private readonly HttpClient client;

        public ParishService(HttpClient client)
        {
            this.client = client;
        }

        public async Task<ParishContact> ParishContactInquiry(int id)
        {
            var uri = $"/api/ParishContacts/{id}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var parishContact = JsonConvert.DeserializeObject<ParishContact>(stringResult);

            return parishContact;
        }

        public async Task<ParishDomicile> ParishDomicileInquiry(int id)
        {
            var uri = $"/api/ParishDomiciles/{id}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var parishDomicile = JsonConvert.DeserializeObject<ParishDomicile>(stringResult);

            return parishDomicile;
        }

        public async Task<IEnumerable<Parish>> ParishesInquiry()
        {
            var uri = $"/api/Parishes";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var parishes = JsonConvert.DeserializeObject<IEnumerable<Parish>>(stringResult);

            return parishes;
        }

        public async Task<Parish> ParishInquiry(int id)
        {
            var uri = $"/api/Parishes/{id}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var parish = JsonConvert.DeserializeObject<Parish>(stringResult);

            return parish;
        }

        public async Task<ParishJurisdiction> ParishJurisdictionInquiry(int id)
        {
            var uri = $"/api/ParishJurisdictions/{id}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var parishJurisdiction = JsonConvert.DeserializeObject<ParishJurisdiction>(stringResult);

            return parishJurisdiction;
        }
    }
}
