﻿using Newtonsoft.Json;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Infrastructure.Services.Taxes
{
    public class JurisdictionService : IJurisdictionService
    {
        private readonly HttpClient client;

        public JurisdictionService(HttpClient client)
        {
            this.client = client;
        }

        public async Task<Jurisdiction> JurisdictionCreate(Jurisdiction jurisdictionToCreate)
        {
            var uri = "/api/Jurisdictions/";

            var jsonJurisdiction = JsonConvert.SerializeObject(jurisdictionToCreate);
            var content = new StringContent(jsonJurisdiction.ToString(), Encoding.UTF8, "application/json");


            var response = await client.PostAsync(uri, content);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var jurisdiction = JsonConvert.DeserializeObject<Jurisdiction>(stringResult);

            return jurisdiction;
        }
        public async Task<Jurisdiction> JurisdictionUpdate(Jurisdiction jurisdictionToUpdate)
        {
            var uri = $"/api/Jurisdictions/{jurisdictionToUpdate.Id}";

            var jsonJurisdiction = JsonConvert.SerializeObject(jurisdictionToUpdate);
            var content = new StringContent(jsonJurisdiction.ToString(), Encoding.UTF8, "application/json");

            var response = await client.PutAsync(uri, content);
            if(!response.IsSuccessStatusCode)
            {
                var postresponse = await response.Content.ReadAsStringAsync();
                if (!string.IsNullOrEmpty(postresponse))
                    throw new InvalidOperationException(postresponse);
            }
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var jurisdiction = JsonConvert.DeserializeObject<Jurisdiction>(stringResult);

            return jurisdiction;
        }

        public async Task<Jurisdiction> JurisdictionInquiry(int id)
        {
            var uri = $"/api/Jurisdictions/{id}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var jurisdiction = JsonConvert.DeserializeObject<Jurisdiction>(stringResult);

            return jurisdiction;
        }

        public async Task<IEnumerable<JurisdictionType>> JurisdictionTypesInquiry()
        {
            var uri = $"/api/jurisdictiontypes/";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var jurisdictionTypes = JsonConvert.DeserializeObject<List<JurisdictionType>>(stringResult);

            return jurisdictionTypes;
        }

    }
}
