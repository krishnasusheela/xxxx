﻿using Newtonsoft.Json;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace ParishTaxTable.Admin.Infrastructure.Services.Taxes
{
    public class DispersionService : IDispersionService
    {
        private readonly HttpClient client;

        public DispersionService(HttpClient client)
        {
            this.client = client;
        }

        public async Task<Dispersion> DispersionCreate(Dispersion dispersionToCreate)
        {

            var uri = "/api/Dispersions/";

            var jsonDispersion = JsonConvert.SerializeObject(dispersionToCreate);
            var content = new StringContent(jsonDispersion.ToString(), Encoding.UTF8, "application/json");

            var response = await client.PostAsync(uri, content);
            if (!response.IsSuccessStatusCode)
            {
                var postresponse = await response.Content.ReadAsStringAsync();
                if (!string.IsNullOrEmpty(postresponse))
                    throw new InvalidOperationException(postresponse);
            }
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var dispersion = JsonConvert.DeserializeObject<Dispersion>(stringResult);

            return dispersion;
        }

        public async Task<Dispersion> DispersionReplace(Dispersion dispersionToCreate, int invalidatedId)
        {

            var uri = $"/api/Dispersions?invalidatedID={invalidatedId}";

            var jsonDispersion = JsonConvert.SerializeObject(dispersionToCreate);
            var content = new StringContent(jsonDispersion.ToString(), Encoding.UTF8, "application/json");

            var response = await client.PostAsync(uri, content);
            if (!response.IsSuccessStatusCode)
            {
                var postresponse = await response.Content.ReadAsStringAsync();
                if (!string.IsNullOrEmpty(postresponse))
                    throw new InvalidOperationException(postresponse);
            }
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var dispersion = JsonConvert.DeserializeObject<Dispersion>(stringResult);

            return dispersion;
        }

        public async Task<Dispersion> DispersionUpdate(Dispersion dispersionToUpdate)
        {
            var uri = $"/api/Dispersions/{dispersionToUpdate.Id}";

            var jsonDispersion = JsonConvert.SerializeObject(dispersionToUpdate);
            var content = new StringContent(jsonDispersion.ToString(), Encoding.UTF8, "application/json");

            var response = await client.PutAsync(uri, content);
            if (!response.IsSuccessStatusCode)
            {
                var postresponse = await response.Content.ReadAsStringAsync();
                if (!string.IsNullOrEmpty(postresponse))
                    throw new InvalidOperationException(postresponse);
            }
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var dispersion = JsonConvert.DeserializeObject<Dispersion>(stringResult);

            return dispersion;
        }

        public async Task<Dispersion> DispersionDelete(int id)
        {
            var uri = $"/api/Dispersions/{id}";

            var response = await client.DeleteAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var dispersion = JsonConvert.DeserializeObject<Dispersion>(stringResult);

            return dispersion;
        }

        public async Task<Dispersion> DispersionInquiry(int id)
        {
            var uri = $"/api/Dispersions/{id}";

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            var dispersion = JsonConvert.DeserializeObject<Dispersion>(stringResult);

            return dispersion;
        }
    }
}
