﻿using ParishTaxTable.Admin.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Core.Interfaces.Taxes
{
    public interface IParishService
    {
        Task<ParishContact> ParishContactInquiry(int id);
        Task<ParishDomicile> ParishDomicileInquiry(int id);
        Task<ParishJurisdiction> ParishJurisdictionInquiry(int id);
        Task<Parish> ParishInquiry(int id);
        Task<IEnumerable<Parish>> ParishesInquiry();
    }
}
