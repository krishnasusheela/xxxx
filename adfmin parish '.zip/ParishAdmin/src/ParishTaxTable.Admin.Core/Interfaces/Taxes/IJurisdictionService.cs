﻿using ParishTaxTable.Admin.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Core.Interfaces.Taxes
{
    public interface IJurisdictionService
    {
        Task<Jurisdiction> JurisdictionCreate(Jurisdiction jurisdictionToCreate);
        Task<Jurisdiction> JurisdictionUpdate(Jurisdiction jurisdictionToUpdate);
        Task<Jurisdiction> JurisdictionInquiry(int id);
        Task<IEnumerable<JurisdictionType>> JurisdictionTypesInquiry();
    }
}
