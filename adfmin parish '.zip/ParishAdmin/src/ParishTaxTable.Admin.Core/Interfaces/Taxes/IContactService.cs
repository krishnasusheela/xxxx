﻿using ParishTaxTable.Admin.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Core.Interfaces.Taxes
{
    public interface IContactService
    {
        Task<Contact> ContactCreate(Contact ContactToCreate);
        Task<Contact> ContactUpdate(Contact ContactToUpdate);
        Task<Contact> ContactRetire(int id);
        Task<Contact> ContactInquiry(int id);
        
    }


}