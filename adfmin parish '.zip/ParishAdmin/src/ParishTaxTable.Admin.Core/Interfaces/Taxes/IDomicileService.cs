﻿using ParishTaxTable.Admin.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Core.Interfaces.Taxes
{
    public interface IDomicileService
    {
        Task<Domicile> DomicileCreate(Domicile DomicileToCreate);
        Task<Domicile> DomicileUpdate(Domicile DomicileToUpdate);
        Task<IEnumerable<Domicile>> DomicilesInquiry();
        Task<Domicile> DomicileInquiry(int id, DateTimeOffset? date);
        Task<Domicile> DomicileCodeInquiry(string domicileCode);
    }
}
