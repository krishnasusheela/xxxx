﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Core.Interfaces.Taxes
{
    public interface IApiPttService
    {
        Task<string> ApiInquiry(string url);
    }
}
