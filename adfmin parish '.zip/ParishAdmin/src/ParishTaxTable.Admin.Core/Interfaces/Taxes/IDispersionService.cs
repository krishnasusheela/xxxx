﻿using ParishTaxTable.Admin.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ParishTaxTable.Admin.Core.Interfaces.Taxes
{
    public interface IDispersionService
    {
        Task<Dispersion> DispersionCreate(Dispersion dispersionToCreate);
        Task<Dispersion> DispersionReplace(Dispersion dispersionToCreate, int invalidatedId);
        Task<Dispersion> DispersionUpdate(Dispersion dispersionToUpdate);
        Task<Dispersion> DispersionInquiry(int id);
        Task<Dispersion> DispersionDelete(int id);
    }
}
