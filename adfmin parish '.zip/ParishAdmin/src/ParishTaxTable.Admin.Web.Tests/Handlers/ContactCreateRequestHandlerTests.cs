﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class ContactCreateRequestHandlerTests
        : IDisposable
    {
        private Fixture fixture;
        private ContactCreateRequestHandler handler;
        private Mock<IContactService> serviceMock;

        public ContactCreateRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IContactService>();
            handler = new ContactCreateRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreateSuccessfully()
        {
            Assert.NotNull(handler);
        }
        [Fact]
        public async Task HandlerRequestExpected()
        {
            var expected = fixture.Create<Contact>();
            var request = new ContactCreateRequest
            {
                Contact = expected
            };
            serviceMock
                    .Setup(m => m.ContactCreate(
                        It.Is<Contact>(p => p == expected)))
                        .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));
            Assert.Equal(expected, result);
        }


    }
}
