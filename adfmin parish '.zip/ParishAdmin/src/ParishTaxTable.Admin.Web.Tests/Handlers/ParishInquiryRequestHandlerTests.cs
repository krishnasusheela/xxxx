﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class ParishInquiryRequestHandlerTests
        : IDisposable
    {

        private Fixture fixture;
        private ParishInquiryRequestHandler handler;
        private Mock<IParishService> serviceMock;

        public ParishInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IParishService>();
            handler = new ParishInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Parish>();
            var request = new ParishInquiryRequest
            {
                Id = expected.Id
            };
            serviceMock
                .Setup(m => m.ParishInquiry(
                    It.Is<int>(p => p == expected.Id)))
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
