﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class JurisdictionTypesInquiryRequestHandlerTests
       : IDisposable
    {

        private Fixture fixture;
        private JurisdictionTypesInquiryRequestHandler handler;
        private Mock<IJurisdictionService> serviceMock;

        public JurisdictionTypesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IJurisdictionService>();
            handler = new JurisdictionTypesInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.CreateMany<JurisdictionType>();
            var request = new JurisdictionTypesInquiryRequest();

            serviceMock
                .Setup(m => m.JurisdictionTypesInquiry())
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
