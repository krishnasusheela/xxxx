﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Web.Handlers.Api;
using ParishTaxTable.Admin.Web.Tests.TestHelpers;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class ApiPttGetRequestHandlerTests
        : IDisposable
    {
        private ApiPttGetRequestHandler handler;
        private Mock<IApiPttService> service;

        public ApiPttGetRequestHandlerTests()
        {
            service = new Mock<IApiPttService>();
            handler = new ApiPttGetRequestHandler(
                service.Object);
        }

        public void Dispose()
        {
            handler = null;
            service = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = "10";
            service
                .Setup(m => m.ApiInquiry("/Parishes/1/NextDomicileCode"))
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new Requests.ApiPttGetRequest() { Url = "/Parishes/1/NextDomicileCode" },
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenServiceThrowsException()
        {

            service
                .Setup(m => m.ApiInquiry("/Parishes/0/NextDomicileCode"))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new Requests.ApiPttGetRequest() { Url = "/Parishes/0/NextDomicileCode" },
                    default(System.Threading.CancellationToken)));
        }
    }
}
