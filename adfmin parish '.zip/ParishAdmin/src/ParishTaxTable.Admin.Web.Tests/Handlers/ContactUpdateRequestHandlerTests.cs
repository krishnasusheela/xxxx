﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class ContactUpdateRequestHandlerTests
       : IDisposable
    {

        private Fixture fixture;
        private ContactUpdateRequestHandler handler;
        private Mock<IContactService> serviceMock;

        public ContactUpdateRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IContactService>();
            handler = new ContactUpdateRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Contact>();
            var request = new ContactUpdateRequest
            {
                Contact = expected
            };
            serviceMock
                .Setup(m => m.ContactUpdate(
                    It.Is<Contact>(p => p == expected)))
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
