﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class ParishesInquiryRequestHandlerTests
        : IDisposable
    {

        private Fixture fixture;
        private ParishesInquiryRequestHandler handler;
        private Mock<IParishService> serviceMock;

        public ParishesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IParishService>();
            handler = new ParishesInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.CreateMany<Parish>();
            var request = new ParishesInquiryRequest();
            serviceMock
                .Setup(m => m.ParishesInquiry())
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
