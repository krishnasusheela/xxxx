﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class DomicilesInquiryRequestHandlerTests
    : IDisposable
    {

        private Fixture fixture;
        private DomicilesInquiryRequestHandler handler;
        private Mock<IDomicileService> serviceMock;

        public DomicilesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IDomicileService>();
            handler = new DomicilesInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.CreateMany<Domicile>();
            var request = new DomicilesInquiryRequest();

            serviceMock
                .Setup(m => m.DomicilesInquiry())
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
