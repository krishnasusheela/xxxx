﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class ParishDomicileInquiryRequestHandlerTests
        : IDisposable
    {

        private Fixture fixture;
        private ParishDomicileInquiryRequestHandler handler;
        private Mock<IParishService> serviceMock;

        public ParishDomicileInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IParishService>();
            handler = new ParishDomicileInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<ParishDomicile>();
            var request = new ParishDomicileInquiryRequest
            {
                Id = expected.Id
            };
            serviceMock
                .Setup(m => m.ParishDomicileInquiry(
                    It.Is<int>(p => p == expected.Id)))
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
