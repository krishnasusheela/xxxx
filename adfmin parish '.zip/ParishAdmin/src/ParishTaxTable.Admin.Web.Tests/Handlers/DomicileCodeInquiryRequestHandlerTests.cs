﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class DomicileCodeInquiryRequestHandlerTests
        : IDisposable
    {
        private Fixture fixture;
        private DomicileCodeInquiryRequestHandler handler;
        private Mock<IDomicileService> serviceMock;

        public DomicileCodeInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IDomicileService>();
            handler = new DomicileCodeInquiryRequestHandler(serviceMock.Object);
        }
        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Domicile>();

            var request = new DomicileCodeInquiryRequest
            {
                DomicileCode = expected.DomicileCode
            };

            serviceMock
                .Setup(m => m.DomicileCodeInquiry(
                    It.Is<string>(p => p == expected.DomicileCode)))
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
