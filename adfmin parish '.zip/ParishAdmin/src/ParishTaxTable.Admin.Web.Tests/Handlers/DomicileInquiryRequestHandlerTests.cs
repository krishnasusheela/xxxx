﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;


namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class DomicileInquiryRequestHandlerTests
     : IDisposable
    {

        private Fixture fixture;
        private DomicileInquiryRequestHandler handler;
        private Mock<IDomicileService> serviceMock;

        public DomicileInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IDomicileService>();
            handler = new DomicileInquiryRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Domicile>();
            var expectedDate = fixture.Create<DateTimeOffset>();

            var request = new DomicileInquiryRequest
            {
                Id = expected.Id,
                SearchDate = expectedDate

            };
            serviceMock
                .Setup(m => m.DomicileInquiry(
                    It.Is<int>(p => p == expected.Id),
                    It.Is<DateTimeOffset>(t => t == expectedDate)))
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }    
    }  
}
