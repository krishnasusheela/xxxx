﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class JurisdictionUpdateRequestHandlerTests
       : IDisposable
    {

        private Fixture fixture;
        private JurisdictionUpdateRequestHandler handler;
        private Mock<IJurisdictionService> serviceMock;

        public JurisdictionUpdateRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IJurisdictionService>();
            handler = new JurisdictionUpdateRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Jurisdiction>();
            var request = new JurisdictionUpdateRequest
            {
                Jurisdiction = expected
            };
            serviceMock
                .Setup(m => m.JurisdictionUpdate(
                    It.Is<Jurisdiction>(p => p == expected)))
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
