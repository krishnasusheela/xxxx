﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class DomicileUpdateRequestHandlerTests
      : IDisposable
    {

        private Fixture fixture;
        private DomicileUpdateRequestHandler handler;
        private Mock<IDomicileService> serviceMock;

        public DomicileUpdateRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IDomicileService>();
            handler = new DomicileUpdateRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Domicile>();
            var request = new DomicileUpdateRequest
            {
                domicile = expected
            };
            serviceMock
                .Setup(m => m.DomicileUpdate(
                    It.Is<Domicile>(p => p == expected)))
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
