﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class DispersionCreateRequestHandlerTests
       : IDisposable
    {

        private Fixture fixture;
        private DispersionCreateRequestHandler handler;
        private Mock<IDispersionService> serviceMock;

        public DispersionCreateRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IDispersionService>();
            handler = new DispersionCreateRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Dispersion>();
            var request = new DispersionCreateRequest
            {
                Dispersion = expected
            };
            serviceMock
                .Setup(m => m.DispersionCreate(
                    It.Is<Dispersion>(p => p == expected)))
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }

        [Fact]
        public async Task HandlerWithInvalidatedIdReturnsExpected()
        {
            var expected = fixture.Create<Dispersion>();
            var request = new DispersionCreateRequest
            {
                Dispersion = expected,
                InvalidatedId = expected.Id
            };
            serviceMock
                .Setup(m => m.DispersionReplace(
                    expected, expected.Id
                    ))
                .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }

    }
}
