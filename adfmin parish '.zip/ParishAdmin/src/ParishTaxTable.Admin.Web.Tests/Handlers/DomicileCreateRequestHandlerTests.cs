﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class DomicileCreateRequestHandlerTests
           : IDisposable
    {

        private Fixture fixture;
        private DomicileCreateRequestHandler handler;
        private Mock<IDomicileService> serviceMock;

        public DomicileCreateRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IDomicileService>();
            handler = new DomicileCreateRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Domicile>();
            var request = new DomicileCreateRequest
            {
                Domicile = expected
            };
            serviceMock
                .Setup(m => m.DomicileCreate(
                    It.Is<Domicile>(p => p == expected)))
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}


