﻿using AutoFixture;
using Moq;
using ParishTaxTable.Admin.Core.Interfaces.Taxes;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Handlers;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Handlers
{
    public class ContactRetireRequestHandlerTests
       : IDisposable
    {

        private Fixture fixture;
        private ContactRetireRequestHandler handler;
        private Mock<IContactService> serviceMock;

        public ContactRetireRequestHandlerTests()
        {
            fixture = new Fixture();
            serviceMock = new Mock<IContactService>();
            handler = new ContactRetireRequestHandler(serviceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            serviceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Contact>();
            var request = new ContactRetireRequest
            {
                Id = expected.Id
            };
            serviceMock
                .Setup(m => m.ContactRetire(
                    It.Is<int>(p => p == expected.Id)))
                    .ReturnsAsync(expected);

            var result = await handler.Handle(
                request,
                default(System.Threading.CancellationToken));

            Assert.Equal(expected, result);
        }
    }
}
