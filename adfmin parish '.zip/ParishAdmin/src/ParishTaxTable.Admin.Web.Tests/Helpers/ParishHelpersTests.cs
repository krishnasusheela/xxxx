﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoFixture;
using Microsoft.AspNetCore.Mvc.Rendering;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Helpers;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Helpers
{
    public class ParishHelpersTests : IDisposable
    {
        private Fixture fixture;

        public ParishHelpersTests()
        {
            this.fixture = new Fixture();
        }

        public void Dispose()
        {
            fixture = null;
        }

        [Fact]
        public void ToSelectListItemsReturnsSelectListItems()
        {
            var parishes = fixture.Create<IEnumerable<Parish>>();

            var expected = parishes
                .OrderBy(x => x.Id)
                .Select(rcd => new SelectListItem
                {
                    Value = rcd.Id.ToString(),
                    Text = rcd.Name
                });
            var actual = parishes.ToSelectListItems();

            Assert.Equal(expected.FirstOrDefault().Value, actual.FirstOrDefault().Value);
            Assert.Equal(expected.LastOrDefault().Value, actual.LastOrDefault().Value);
        }

        [Fact]
        public void GetJurisdictionIdsReturnsJurisdictionIdsFromParishDomicile()
        {
            var parishDomicile = fixture.Create<ParishDomicile>();

            var expected = parishDomicile
                .Domiciles
                .SelectMany(q => q.Dispersions)
                .Select(x => x.Jurisdiction.Id)
                .Distinct();

            var actual = parishDomicile.GetJurisdictionIdsOfParish();

            Assert.Equal(
                expected,
                actual);
        }
    }
}
