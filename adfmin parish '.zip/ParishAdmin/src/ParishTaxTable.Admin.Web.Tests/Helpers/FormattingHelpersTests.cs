﻿using System;
using System.Collections.Generic;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Helpers;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Helpers
{
    public class FormattingHelperTests
    {
        [Theory]
        [InlineData("12.34%", .1234)]
        [InlineData("12.34", .1234)]
        [InlineData(".1234%", .001234)]
        [InlineData("0%", 0)]
        [InlineData("99", .99)]
        [InlineData("99%", .99)]
        [InlineData("99 %", .99)]
        [InlineData(".99", .0099)]
        [InlineData(".99%", .0099)]
        [InlineData(".99 %", .0099)]
        public void GetDecimalPercentageConvertsCorrectly(string input, decimal output)
        {
            var percentage = input.GetDecimalPercentage();
            Assert.Equal(output, percentage);
        }

        [Theory]
        [InlineData("12.3.4")]
        [InlineData("a")]
        public void GetDecimalPercentageThrowsInvalidOperationExceptionOnIncorrectPercentageString(string input)
        {
            Assert.Throws<InvalidOperationException>(() =>
                input.GetDecimalPercentage());
        }



        [Theory]
        [InlineData(.1234, "12.34")]
        [InlineData(.99, "99.00")]
        [InlineData(.0099, "0.99")]
        public void GetStringPercentageConvertsCorrectly(decimal input, string output)
        {
            var percentage = input.GetStringPercentage();
            Assert.Equal(output, percentage);
        }
    }
}
