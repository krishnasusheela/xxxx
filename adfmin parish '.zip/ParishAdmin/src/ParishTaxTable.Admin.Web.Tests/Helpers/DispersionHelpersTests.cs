﻿using System;
using System.Collections.Generic;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Helpers;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Helpers
{
    public class DispersionHelpersTests
    {
        [Fact]
        public void GetCurrentDispersionsDoesNotReturnResultsWhenDispersionsAreInvalid()
        {
            var dispersions = new List<Dispersion>
            {
                new Dispersion
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = null,
                    IsInvalidDispersion = true
                }
            };

            var currentDispersions = dispersions.GetCurrentDispersions();

            Assert.Empty(currentDispersions);
        }

        [Fact]
        public void GetFutureDispersionsDoesNotReturnResultsWhenDispersionsAreInvalid()
        {
            var dispersions = new List<Dispersion>
            {
                new Dispersion
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(10),
                    TermDate = null,
                    IsInvalidDispersion = true
                }
            };

            var futureDispersions = dispersions.GetFutureDispersions();

            Assert.Empty(futureDispersions);
        }

        [Fact]
        public void GetCurrentDispersionsReturnsResultsWhenDispersionsAreValid()
        {
            var dispersions = new List<Dispersion>
            {
                new Dispersion
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = null,
                    IsInvalidDispersion = false
                }
            };

            var currentDispersions = dispersions.GetCurrentDispersions();

            Assert.Equal(
                dispersions,
                currentDispersions);
        }

        [Fact]
        public void GetFutureDispersionsReturnsResultsWhenDispersionsAreValid()
        {
            var dispersions = new List<Dispersion>
            {
                new Dispersion
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(10),
                    TermDate = null,
                    IsInvalidDispersion = false
                }
            };

            var futureDispersions = dispersions.GetFutureDispersions();
            
            Assert.Equal(
                dispersions,
                futureDispersions);
        }

        [Fact]
        public void GetInvalidDispersionsReturnsResultsWhenDispersionsAreInvalid()
        {
            var dispersions = new List<Dispersion>
            {
                new Dispersion
                {
                    IsInvalidDispersion = true
                }
            };

            var invalidDispersions = dispersions.GetInvalidDispersions();

            Assert.Equal(
                dispersions,
                invalidDispersions);
        }

        [Fact]
        public void GetInvalidDispersionsDoesNotReturnResultsWhenDispersionsAreValid()
        {
            var dispersions = new List<Dispersion>
            {
                new Dispersion
                {
                    IsInvalidDispersion = false
                }
            };

            var invalidDispersions = dispersions.GetInvalidDispersions();

            Assert.Empty(invalidDispersions);
        }
        
        [Fact]
        public void IsHistoricalReturnsFalseWhenTermDateIsNull()
        {
            var dispersion = new Dispersion
            {
                TermDate = null
            };

            Assert.False(dispersion.IsHistorical());
        }
        [Fact]
        public void IsHistoricalReturnsFalseWhenTermDateIsInTheFuture()
        {
            var dispersion = new Dispersion
            {
                TermDate = DateTimeOffset.Now.AddDays(10)
            };

            Assert.False(dispersion.IsHistorical());
        }
        [Fact]
        public void IsHistoricalReturnsTrueWhenTermDateIsInThePast()
        {
            var dispersion = new Dispersion
            {
                TermDate = DateTimeOffset.Now.AddDays(-10)
            };

            Assert.True(dispersion.IsHistorical());
        }
    }
}
