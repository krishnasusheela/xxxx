﻿using System;
using System.Collections.Generic;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Helpers;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Helpers
{
    public class JurisdictionHelpersTests
    {

        [Fact]
        public void GetActiveJurisdictionsReturnsEmptyListWhenAllJurisdictionsHaveARetireDate()
        {
            var jurisdictions = new List<Jurisdiction>
            {
                new Jurisdiction
                {
                    RetireDate = DateTimeOffset.Now.AddDays(-5)
                }
            };

            var currentJurisdictions = jurisdictions.GetActiveJurisdictions();

            Assert.Empty(currentJurisdictions);
        }

        [Fact]
        public void GetActiveJurisdictionsReturnsResultsWhenAllJurisdictionsTheyAllHaveNullRetireDate()
        {
            var jurisdictions = new List<Jurisdiction>
            {
                new Jurisdiction
                {
                    RetireDate = null
                }
            };

            var currentJurisdictions = jurisdictions.GetActiveJurisdictions();

            Assert.Equal(
                jurisdictions,
                currentJurisdictions);
        }
        [Fact]
        public void GetInactiveJurisdictionsReturnsResultsWhenAllJurisdictionsHaveARetireDate()
        {
            var jurisdictions = new List<Jurisdiction>
            {
                new Jurisdiction
                {
                    RetireDate = DateTimeOffset.Now.AddDays(-5)
                }
            };

            var currentJurisdictions = jurisdictions.GetInactiveJurisdictions();
            Assert.Equal(
                jurisdictions,
                currentJurisdictions);
        }

        [Fact]
        public void GetInactiveJurisdictionsReturnsEmptyListWhenAllJurisdictionsTheyAllHaveNullRetireDate()
        {
            var jurisdictions = new List<Jurisdiction>
            {
                new Jurisdiction
                {
                    RetireDate = null
                }
            };

            var currentJurisdictions = jurisdictions.GetInactiveJurisdictions();

            Assert.Empty(currentJurisdictions);
        }
    }
}
