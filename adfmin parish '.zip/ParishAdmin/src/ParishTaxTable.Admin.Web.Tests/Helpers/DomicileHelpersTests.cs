﻿using System;
using System.Collections.Generic;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Helpers;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Helpers
{
    public class DomicileHelpersTests
    {
        [Fact]
        public void GetActiveDomicilesDoesNotReturnInactiveDomiciles()
        {
            var domiciles = new List<Domicile>
            {
                new Domicile
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = DateTimeOffset.Now.AddDays(-5)
                },
                new Domicile
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(10),
                    TermDate = null
                }
            };

            var currentDomiciles = domiciles.GetActiveDomiciles();

            Assert.Empty(currentDomiciles);
        }

        [Fact]
        public void GetActiveDomicilesDoesReturnActiveDomiciles()
        {
            var domiciles = new List<Domicile>
            {
                new Domicile
                {
                    EffectiveDate = DateTimeOffset.Now.AddDays(-10),
                    TermDate = DateTimeOffset.Now.AddDays(10)
                }
            };

            var currentDomiciles = domiciles.GetActiveDomiciles();

            Assert.Equal(currentDomiciles, domiciles);
        }
    }
}
