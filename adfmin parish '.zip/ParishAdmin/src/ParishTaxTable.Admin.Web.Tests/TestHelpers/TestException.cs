﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParishTaxTable.Admin.Web.Tests.TestHelpers
{
    class TestException
        : Exception
    {
    }
}
