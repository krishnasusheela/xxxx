﻿using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Controllers;
using ParishTaxTable.Admin.Web.Helpers;
using ParishTaxTable.Admin.Web.Interfaces;
using ParishTaxTable.Admin.Web.Models.Domiciles;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Api.Tests.Controllers
{
    public class DomicileControllerTests
        : IDisposable
    {
        private Fixture fixture;
        private DomicileController controller;

        private Mock<IMediator> mediatorMock;
        private ICommonRequestHelpers commonRequestHelpers;

        public DomicileControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();
            commonRequestHelpers = new CommonRequestHelpers(null);

            controller =
                new DomicileController(
                    mediatorMock.Object, commonRequestHelpers
                    );
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task DetailsReturnsExpectedResultForSpecificDomicileWithDateParameter()
        {
            var expected = fixture.Create<DomicileDetailsViewModel>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileInquiryRequest>(g => g.Id == expected.Domicile.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Domicile);

            var result =
                await controller.Details(expected.Domicile.Id, expected.SearchDate.ToString());

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<DomicileDetailsViewModel>(viewResult.Model);
        }

        [Fact]
        public async Task DetailsReturnsExpectedResulForSpecificDomicileWithoutDateParameter()
        {
            var expected = fixture.Create<DomicileDetailsViewModel>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileInquiryRequest>(g => g.Id == expected.Domicile.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Domicile);

            var result =
                await controller.Details(expected.Domicile.Id, expected.InputDate);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<DomicileDetailsViewModel>(viewResult.Model);
        }

        [Fact]
        public void PostDetailsRedirectsToDomicileDetailsAction()
        {
            var expected = fixture.Create<DomicileDetailsViewModel>();

            var result = controller.Details(expected);

            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Details", viewResult.ActionName);
            Assert.Equal("Domicile", viewResult.ControllerName);
        }

        [Fact]
        public async Task OnEditGetEntityByIdReturnsExpectedResultForSpecificDomicile()
        {
            var domicileChangesForUpdate = fixture.Create<Domicile>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileInquiryRequest>(g => g.Id == domicileChangesForUpdate.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(domicileChangesForUpdate);

            var result =
                await controller.Edit(domicileChangesForUpdate.Id);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<DomicileEditViewModel>(viewResult.Model);
        }

        [Fact]
        public async Task OnEditUpdateEntityByIdReturnsExpectedResultForSpecificDomicile()
        {
            var collectionRate = fixture.Create<decimal>();
            var vendorComp = fixture.Create<decimal>();
            var domicileChangesForUpdate = fixture.Build<DomicileEditViewModel>()
                .With(x => x.CollectionRate, collectionRate.ToString())
                .With(x => x.VendorCompensation, vendorComp.ToString())
                .Create();

            var expectedDomicile = fixture.Build<Domicile>()
                .With(x => x.Id, domicileChangesForUpdate.Id)
                .With(x => x.Name, domicileChangesForUpdate.Name)
                .With(x => x.TermDate, domicileChangesForUpdate.TermDate)
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileUpdateRequest>(g => g.domicile == expectedDomicile),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expectedDomicile);

            var result =
                await controller.Edit(domicileChangesForUpdate.Id, domicileChangesForUpdate);

            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal(viewResult.RouteValues["id"], expectedDomicile.Id);
        }
    }
}
