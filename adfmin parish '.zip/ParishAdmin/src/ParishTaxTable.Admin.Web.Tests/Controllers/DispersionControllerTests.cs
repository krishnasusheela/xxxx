﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Moq;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Controllers;
using ParishTaxTable.Admin.Web.Interfaces;
using ParishTaxTable.Admin.Web.Models.Dispersions;
using ParishTaxTable.Admin.Web.Requests;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Controllers
{
    public class DispersionControllerTests
        : IDisposable
    {
        private Fixture fixture;
        private DispersionController controller;
        private Mock<IMediator> mediatorMock;
        private Mock<ICommonRequestHelpers> commonRequestHelpers;

        public DispersionControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();
            commonRequestHelpers = new Mock<ICommonRequestHelpers>();

            controller =
                new DispersionController(
                    mediatorMock.Object,
                    commonRequestHelpers.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
            commonRequestHelpers = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }


        [Fact]
        public async Task InvalidateWithoutReplacementreturnsExpectedResult()
        {
            var expected = fixture.Build<Dispersion>()
                .With(x => x.IsInvalidDispersion, false)
                .Create();
            var expectedTermDate = expected.TermDate;
            var replaceDispersion = false;

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
            .ReturnsAsync(expected);

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionUpdateRequest>(g => g.dispersion == expected),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result = await controller.Invalidate(expected.Id, replaceDispersion);

            var viewResult = Assert.IsType<RedirectToActionResult>(result);


            Assert.Equal("Details", viewResult.ActionName);
            Assert.Equal("Domicile", viewResult.ControllerName);
            Assert.Equal(expected.DomicileId, viewResult.RouteValues["id"]);
            Assert.True(expected.IsInvalidDispersion);
        }
        [Fact]
        public async Task InvalidateWithReplacementreturnsExpectedResult()
        {
            var expected = fixture.Build<Dispersion>()
                .With(x => x.IsInvalidDispersion, false)
                .Create();
            var expectedTermDate = expected.TermDate;
            var replaceDispersion = true;

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);
            
            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionUpdateRequest>(g => g.dispersion == expected),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result = await controller.Invalidate(expected.Id, replaceDispersion);

            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Replace", viewResult.ActionName);
            Assert.Equal("Dispersion", viewResult.ControllerName);
            Assert.Equal(expected.Id, viewResult.RouteValues["id"]);
            Assert.Equal(expectedTermDate, viewResult.RouteValues["originalTermDate"]);
            Assert.True(expected.IsInvalidDispersion);
        }

        [Fact]
        public async Task ReplaceHttpGetReturnsExpectedResult()
        {
            var expected = fixture.Build<Dispersion>()
                .With(x => x.IsInvalidDispersion, false)
                .Create();
            var expectedParishId = fixture.Create<int>();
            var expectedTermDate = fixture.Create<DateTimeOffset?>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DispersionInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);
            commonRequestHelpers
                .Setup((m => m.ParishIdFromDomicileId(
                    expected.DomicileId)))
                .ReturnsAsync(expectedParishId);

            var result = await controller.Replace(expected.Id, expectedTermDate);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<DispersionReplaceViewModel>(viewResult.Model);
            Assert.Equal(expected.Id, model.InvalidatedId);
            Assert.Equal(expectedTermDate, model.TermDate);
            Assert.Equal(expectedTermDate, model.OriginalTermDate);
            Assert.Equal(expectedParishId, model.ParishId);
            Assert.Equal(expected.DisplayedDistributionRate, model.DistributionRate);

        }

        [Fact]
        public async Task ReplaceHttpPostWithAdditionalReplacementsReturnsExpectedResult()
        {
            var expectedViewModel = fixture.Build<DispersionReplaceViewModel>()
                .With(x => x.DistributionRate, "5")
                .With(x => x.VendorCompensation, "5")
                .Create();
            var expectedDispersion = fixture.Build<Dispersion>()                
                .Create();
            var expectedParishId = fixture.Create<int>();
            var additionalReplacement = true;

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<DispersionCreateRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expectedDispersion);
            commonRequestHelpers
                .Setup((m => m.ParishIdFromDomicileId(
                    It.IsAny<int>())))
                .ReturnsAsync(expectedParishId);

            var result = await controller.Replace(expectedViewModel, additionalReplacement);

            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Replace", viewResult.ActionName);
            Assert.Equal("Dispersion", viewResult.ControllerName);
            Assert.Equal(expectedViewModel.InvalidatedId, viewResult.RouteValues["id"]);
            Assert.Equal(expectedViewModel.OriginalTermDate, viewResult.RouteValues["originalTermDate"]);
        }

        [Fact]
        public async Task ReplaceHttpPostWithoutAdditionalReplacementsReturnsExpectedResult()
        {
            var expectedViewModel = fixture.Build<DispersionReplaceViewModel>()
                .With(x => x.DistributionRate, "5")
                .With(x => x.VendorCompensation, "5")
                .Create();
            var expectedDispersion = fixture.Build<Dispersion>()
                .Create();
            var expectedParishId = fixture.Create<int>();
            var additionalReplacement = false;

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<DispersionCreateRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expectedDispersion);
            commonRequestHelpers
                .Setup((m => m.ParishIdFromDomicileId(
                    It.IsAny<int>())))
                .ReturnsAsync(expectedParishId);

            var result = await controller.Replace(expectedViewModel, additionalReplacement);

            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Details", viewResult.ActionName);
            Assert.Equal("Domicile", viewResult.ControllerName);
            Assert.Equal(expectedViewModel.DomicileId, viewResult.RouteValues["id"]);
        }

        [Fact]
        public async Task ReplaceHttpPostReturnsViewWithModelValidationErrorOnInvalidOperationException()
        {
            var expectedViewModel = fixture.Build<DispersionReplaceViewModel>()
                .With(x => x.DistributionRate, "5")
                .With(x => x.VendorCompensation, "5")
                .Create();
            var expectedDispersion = fixture.Build<Dispersion>()
                .Create();
            var expectedParishId = fixture.Create<int>();
            var additionalReplacement = fixture.Create<bool>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<DispersionCreateRequest>(),
                    default(System.Threading.CancellationToken)))
                .Throws<InvalidOperationException>();
            commonRequestHelpers
                .Setup((m => m.ParishIdFromDomicileId(
                    It.IsAny<int>())))
                .ReturnsAsync(expectedParishId);

            var result = await controller.Replace(expectedViewModel, additionalReplacement);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<DispersionReplaceViewModel>(viewResult.Model);
        }


        [Fact]
        public async Task UpdateReplaceSelectsReturnsExpectedResult()
        {
            var expectedViewModel = fixture.Create<DispersionReplaceViewModel>();
            var expectedDomicileSelectItemList = fixture.Create<IList<SelectListItem>>();
            var expectedJurisdictionSelectItemList = fixture.Create<IList<SelectListItem>>();


            commonRequestHelpers
                .Setup((m => m.DomicileSelectListItems(
                    It.IsAny<int>())))
                .ReturnsAsync(expectedDomicileSelectItemList);
            commonRequestHelpers
                .Setup((m => m.JurisdictionSelectListItems(
                    It.IsAny<int>())))
                .ReturnsAsync(expectedJurisdictionSelectItemList);

            var result = await controller.UpdateReplaceSelects(expectedViewModel);

            var viewResult = Assert.IsType<PartialViewResult>(result);
            var model = Assert.IsAssignableFrom<DispersionReplaceViewModel>(viewResult.Model);
            Assert.Equal(expectedDomicileSelectItemList,model.DomicileSelectListItems);
            Assert.Equal(expectedJurisdictionSelectItemList,model.JurisdictionSelectListItems);
        }
    }
}
