﻿using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Newtonsoft.Json;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Controllers;
using ParishTaxTable.Admin.Web.Helpers;
using ParishTaxTable.Admin.Web.Interfaces;
using ParishTaxTable.Admin.Web.Models.Domiciles;
using ParishTaxTable.Admin.Web.Models.Reports;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Api.Tests.Controllers
{
    public class ReportsControllerTests
        : IDisposable
    {
        private Fixture fixture;
        private ReportsController controller;

        private Mock<IMediator> mediatorMock;
        private ICommonRequestHelpers commonRequestHelpers;

        public ReportsControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();
            commonRequestHelpers = new CommonRequestHelpers(mediatorMock.Object);

            controller =
                new ReportsController(
                    mediatorMock.Object, commonRequestHelpers
                    );
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task Index_ReturnsReportDescriptions()
        {
            var expected = fixture.Create<ReportsIndexViewModel>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ReportsIndexRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Reports);

            var result = await controller.Index();

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<ReportsIndexViewModel>(viewResult.Model);
            Assert.IsAssignableFrom<IEnumerable<ReportDescription>>(model.Reports);
            AssertAreEqualByJson(expected.Reports, model.Reports);
        }




        private static void AssertAreEqualByJson(object expected, object actual)
        {
            var expectedJson = JsonConvert.SerializeObject(expected);
            var actualJson = JsonConvert.SerializeObject(actual);

            Assert.Equal(expectedJson, actualJson);
        }
    }
}
