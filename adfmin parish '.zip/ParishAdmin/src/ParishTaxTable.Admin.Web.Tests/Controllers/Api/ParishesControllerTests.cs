﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Controllers.Api;
using ParishTaxTable.Admin.Web.Requests;
using ParishTaxTable.Admin.Web.Tests.TestHelpers;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Controllers.Api
{
    public class ParishesControllerTests
        : IDisposable
    {
        private ParishesController controller;
        private Mock<IMediator> mediatorMock;

        public ParishesControllerTests()
        {
            mediatorMock = new Mock<IMediator>();

            controller =
                new ParishesController(
                    mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task GetNextDomicileCodeReturnsExpected()
        {
            var expected = "10";

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<ApiPttGetRequest>(g => g.Url == $"/Parishes/1/NextDomicileCode"),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.GetNextDomicileCode(1);

            var stringResult = Assert.IsType<OkObjectResult>(result);
            var obj = Assert.IsAssignableFrom<string>(stringResult.Value);

            Assert.Equal(obj, expected);
        }

        [Fact]
        public async Task GetNextDomicileCodeReturnsNoContentWhenMediatorReturnIsNull()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ApiPttGetRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((string)null);

            var result =
                await controller.GetNextDomicileCode(1);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetNextDomicileCodeReturnsBadRequestOnMediatorException()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.Is<ApiPttGetRequest>(g => g.Url == $"/Parishes/1/NextDomicileCode"),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.GetNextDomicileCode(1);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }
    }
}
