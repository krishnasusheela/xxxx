﻿using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Controllers;
using ParishTaxTable.Admin.Web.Models.Parishes;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Controllers
{
    public class ParishControllerTests
        : IDisposable
    {
        private Fixture fixture;
        private ParishController controller;
        private Mock<IMediator> mediatorMock;

        public ParishControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller =
                new ParishController(
                    mediatorMock.Object);
        }
        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task DomicileByCodeRedirectsToProperDomicile()
        {
            var domicile = fixture.Create<Domicile>();
            var expected = fixture.Build<ParishesViewModel>()
                    .With(x => x.DomicileCode, domicile.DomicileCode)
                    .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileCodeInquiryRequest>(x => x.DomicileCode == expected.DomicileCode),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(domicile);

            var result = await controller.DomicileByCode(expected);

            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Details", viewResult.ActionName);
            Assert.Equal("Domicile", viewResult.ControllerName);
        }

        [Fact]
        public async Task DomicileByCodeReloadsViewModelWhenDomicileIsNull()
        {
            var domicile = fixture.Create<Domicile>();
            var expected = fixture.Build<ParishesViewModel>()
                    .With(x => x.DomicileCode, domicile.DomicileCode)
                    .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<DomicileCodeInquiryRequest>(x => x.DomicileCode == expected.DomicileCode),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Domicile)null);

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Parishes);

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<DomicilesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Domiciles);

            var result = await controller.DomicileByCode(expected);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<ParishesViewModel>(viewResult.Model);
            Assert.Equal(expected.Parishes, model.Parishes);
            Assert.Equal(expected.Domiciles, model.Domiciles);
            Assert.Equal(expected.DomicileCode, model.DomicileCode);
        }

        [Fact]
        public async Task IndexReturnsExpectedResult()
        {
            var expected = fixture.Create<ParishesViewModel>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Parishes);

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<DomicilesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Domiciles);

            var result = await controller.Index();

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<ParishesViewModel>(viewResult.Model);
            Assert.Equal(expected.Parishes, model.Parishes);
            Assert.Equal(expected.Domiciles, model.Domiciles);
        }
    }
}
