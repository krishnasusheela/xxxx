﻿using AutoFixture;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ParishTaxTable.Admin.Models;
using ParishTaxTable.Admin.Web.Controllers;
using ParishTaxTable.Admin.Web.Interfaces;
using ParishTaxTable.Admin.Web.Models.Jurisdictions;
using ParishTaxTable.Admin.Web.Requests;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Controllers
{
    public class JurisdictionControllerTests
        : IDisposable
    {
        private Fixture fixture;
        private JurisdictionController controller;
        private Mock<IMediator> mediatorMock;

        public JurisdictionControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller =
                new JurisdictionController(
                    mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task PostCreateNewJurisdictionRedirectsToDispersionCreateSuccessfully()
        {
            var expectedJurisdiction = fixture.Build<Jurisdiction>()
                .With(x => x.Id, 0)
                .Create();

            var expected = fixture.Build<JurisdictionCreateViewModel>()
               .With(x => x.DispersionCreate, true)
               .With(x => x.Jurisdiction, expectedJurisdiction)
               .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<JurisdictionCreateRequest>(g => g.Jurisdiction == expected.Jurisdiction),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Jurisdiction);

            var result = await controller.Create(expected);

            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Create", viewResult.ActionName);
            Assert.Equal("Dispersion", viewResult.ControllerName);
        }

        [Fact]
        public async Task PostCreateNewJurisdictionRedirectsToParishJurisdictionDetailsSuccessfully()
        {
            var expectedJurisdiction = fixture.Build<Jurisdiction>()
                .With(x => x.Id, 0)
                .Create();

            var expected = fixture.Build<JurisdictionCreateViewModel>()
               .With(x => x.DispersionCreate, false)
               .With(x => x.Jurisdiction, expectedJurisdiction)
               .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<JurisdictionCreateRequest>(g => g.Jurisdiction == expected.Jurisdiction),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Jurisdiction);

            var result = await controller.Create(expected);

            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Details", viewResult.ActionName);
            Assert.Equal("ParishJurisdiction", viewResult.ControllerName);
        }

        [Fact]
        public async Task PostCreateNewJurisdictionReturnsViewModelWhenModelStateIsInvalid()
        {
            var expected = fixture.Create<JurisdictionCreateViewModel>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Parishes);

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<JurisdictionTypesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.JurisdictionTypes);

            controller.ModelState.AddModelError("fakeError", "fakeError");

            var result = await controller.Create(expected);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<JurisdictionCreateViewModel>(viewResult.Model);

            Assert.Equal(expected.Parishes, model.Parishes);
            Assert.Equal(expected.JurisdictionTypes, model.JurisdictionTypes);
        }

        [Fact]
        public async Task HttpGetCreateJurisdictionReturnsExpectedResult()
        {
            var expected = fixture.Build<JurisdictionCreateViewModel>()
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ParishesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.Parishes);

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<JurisdictionTypesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected.JurisdictionTypes);

            var result = await controller.Create(expected.ParishId, expected.DomicileId, expected.DispersionCreate);

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<JurisdictionCreateViewModel>(viewResult.Model);
            Assert.Equal(expected.Parishes, model.Parishes);
            Assert.Equal(expected.JurisdictionTypes, model.JurisdictionTypes);
            Assert.Equal(expected.ParishId, model.ParishId);
            Assert.Equal(expected.DomicileId, model.DomicileId);
            Assert.Equal(expected.DispersionCreate, model.DispersionCreate);


        }
    }
}
