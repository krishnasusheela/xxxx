﻿using AutoFixture;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using ParishTaxTable.Admin.Infrastructure.Services.Taxes;
using ParishTaxTable.Admin.Models;
using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Services.Taxes
{
    public class DispersionServiceTests
        : IDisposable
    {
        private Fixture fixture;
        private DispersionService service;
        private Mock<HttpMessageHandler> httpMock;
        private HttpClient clientMock;

        public DispersionServiceTests()
        {
            fixture = new Fixture();
            httpMock = new Mock<HttpMessageHandler>();
            clientMock = new HttpClient(httpMock.Object)
            {
                BaseAddress = new Uri("http://test.com/")
            };
            service = new DispersionService(clientMock);
        }
        public void Dispose()
        {
            fixture = null;
            httpMock = null;
            clientMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(service);
        }


        [Fact]
        public async void DispersionCreateReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionCreate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void DispersionCreateReturnsExceptionWithMessageWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("DANGER WILL ROBINSON!")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionCreate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "DANGER WILL ROBINSON!",
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public async void DispersionCreateDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionCreate(expected));

            Assert.Null(exception);
        }

        [Fact]
        public async void DispersionReplaceReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionReplace(expected,expected.Id));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void DispersionReplaceReturnsExceptionWithMessageWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("I'm sorry, Mario. The princess is in another castle.")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionReplace(expected, expected.Id));

            Assert.NotNull(exception);
            Assert.Equal(
                "I'm sorry, Mario. The princess is in another castle.",
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public async void DispersionReplaceDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionReplace(expected,expected.Id));

            Assert.Null(exception);
        }

        [Fact]
        public async void DispersionUpdateReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionUpdate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void DispersionUpdateReturnsExceptionWithMessageWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("I DRINK YOUR MILKSHAKE!!!")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionUpdate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "I DRINK YOUR MILKSHAKE!!!",
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public async void DispersionUpdateDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionUpdate(expected));

            Assert.Null(exception);
        }

        [Fact]
        public async void DispersionInquiryReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionInquiry(expected.Id));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void DispersionInquiryDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionInquiry(expected.Id));

            Assert.Null(exception);
        }

        [Fact]
        public async void DispersionDeleteReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionDelete(expected.Id));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void DispersionDeleteDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Dispersion>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DispersionDelete(expected.Id));

            Assert.Null(exception);
        }
    }
}
