﻿using AutoFixture;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using ParishTaxTable.Admin.Infrastructure.Services.Taxes;
using ParishTaxTable.Admin.Models;
using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Services.Taxes
{
    public class DomicileServiceTests
     : IDisposable
    {
        private Fixture fixture;
        private DomicileService service;
        private Mock<HttpMessageHandler> httpMock;
        private HttpClient clientMock;

        public DomicileServiceTests()
        {
            fixture = new Fixture();
            httpMock = new Mock<HttpMessageHandler>();
            clientMock = new HttpClient(httpMock.Object)
            {
                BaseAddress = new Uri("http://test.com/")
            };
            service = new DomicileService(clientMock);
        }
        public void Dispose()
        {
            fixture = null;
            httpMock = null;
            clientMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(service);
        }

        [Fact]
        public async void DomicileCreateReturnsExceptionWithMessageWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("Response status code does not indicate success: 400 (Bad Request).")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicileCreate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public async void DomicileCreateReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicileCreate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void DomicileCreateDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicileCreate(expected));

            Assert.Null(exception);
        }

        [Fact]
        public async void DomicileUpdateReturnsExceptionWithMessageWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("Response status code does not indicate success: 400 (Bad Request).")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicileUpdate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public async void DomicileUpdateReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content =new StringContent("")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicileUpdate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void DomicileUpdateDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicileUpdate(expected));

            Assert.Null(exception);
        }

        [Fact]
        public async void DomicileInquiryReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Domicile>();
            var expectedDate = fixture.Create<DateTimeOffset>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest

                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicileInquiry(expected.Id , expectedDate));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void DomicilesInquiryDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.CreateMany<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicilesInquiry());

            Assert.Null(exception);
        }

        [Fact]
        public async void DomicilesInquiryReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicilesInquiry());

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void DomicileInquiryDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Jurisdiction>();
            var expectedDate = fixture.Create<DateTimeOffset>();
            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicileInquiry(expected.Id,expectedDate));

            Assert.Null(exception);
        }

        [Fact]
        public async void DomicileByCodeRetunsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicileCodeInquiry(expected.CombinedCode));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void DomicileByCodeInquiryDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Domicile>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.DomicileCodeInquiry(expected.CombinedCode));

            Assert.Null(exception);
        }
    }

}
