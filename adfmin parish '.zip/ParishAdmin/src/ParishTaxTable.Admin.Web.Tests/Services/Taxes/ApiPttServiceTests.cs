﻿using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using ParishTaxTable.Admin.Infrastructure.Services.Taxes;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Services.Taxes
{
    public class ApiPttServiceTests
        : IDisposable
    {
        private ApiPttService service;
        private Mock<HttpMessageHandler> httpMock;
        private HttpClient clientMock;

        public ApiPttServiceTests()
        {
            httpMock = new Mock<HttpMessageHandler>();
            clientMock = new HttpClient(httpMock.Object)
            {
                BaseAddress = new Uri("http://test.com/")
            };
            service = new ApiPttService(clientMock);
        }

        public void Dispose()
        {
            httpMock = null;
            clientMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(service);
        }

        [Fact]
        public async void ApiInquiryReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.ApiInquiry("/api/Parishes/0/NextDomicileCode"));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void ApiInquiryDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent("{ NextDomicileCode: 11 }")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.ApiInquiry("/api/Parishes/1/NextDomicileCode"));

            Assert.Null(exception);
        }
    }
}
