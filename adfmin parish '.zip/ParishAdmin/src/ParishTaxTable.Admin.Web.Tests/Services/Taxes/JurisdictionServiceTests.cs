﻿using AutoFixture;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using ParishTaxTable.Admin.Infrastructure.Services.Taxes;
using ParishTaxTable.Admin.Models;
using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace ParishTaxTable.Admin.Web.Tests.Services.Taxes
{
    public class JurisdictionServiceTests
        : IDisposable
    {
        private Fixture fixture;
        private JurisdictionService service;
        private Mock<HttpMessageHandler> httpMock;
        private HttpClient clientMock;

        public JurisdictionServiceTests()
        {
            fixture = new Fixture();
            httpMock = new Mock<HttpMessageHandler>();
            clientMock = new HttpClient(httpMock.Object)
            {
                BaseAddress = new Uri("http://test.com/")
            };
            service = new JurisdictionService(clientMock);
        }
        public void Dispose()
        {
            fixture = null;
            httpMock = null;
            clientMock = null;
            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(service);
        }

        [Fact]
        public async void JurisdictionCreateReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Jurisdiction>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.JurisdictionCreate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void JurisdictionCreateDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Jurisdiction>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.JurisdictionCreate(expected));

            Assert.Null(exception);
        }


        [Fact]
        public async void JurisdictionUpdateReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Jurisdiction>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.JurisdictionUpdate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void JurisdictionUpdateReturnsExceptionWithMessageWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Jurisdiction>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("DANGER WILL RED!")
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.JurisdictionUpdate(expected));

            Assert.NotNull(exception);
            Assert.Equal(
                "DANGER WILL RED!",
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public async void JurisdictionUpdateDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Jurisdiction>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.JurisdictionUpdate(expected));

            Assert.Null(exception);
        }


        [Fact]
        public async void JurisdictionInquiryReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.Create<Jurisdiction>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.JurisdictionInquiry(expected.Id));

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void JurisdictionTypesInquiryDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.CreateMany<JurisdictionType>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.JurisdictionTypesInquiry());

            Assert.Null(exception);
        }

        [Fact]
        public async void JurisdictionTypesInquiryReturnsExceptionWhenStatusCodeIsNotSuccess()
        {
            var expected = fixture.CreateMany<JurisdictionType>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.JurisdictionTypesInquiry());

            Assert.NotNull(exception);
            Assert.Equal(
                "Response status code does not indicate success: 400 (Bad Request).",
                exception.Message);
            Assert.IsType<HttpRequestException>(
                exception);
        }

        [Fact]
        public async void JurisdictionInquiryDoesNotReturnExceptionWhenStatusCodeIsSuccess()
        {
            var expected = fixture.Create<Jurisdiction>();

            httpMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(expected))
                });

            var exception = await Record.ExceptionAsync(async () =>
                await service.JurisdictionInquiry(expected.Id));

            Assert.Null(exception);
        }
    }
}
