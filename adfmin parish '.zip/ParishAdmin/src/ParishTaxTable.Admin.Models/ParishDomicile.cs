﻿using System;
using System.Collections.Generic;

namespace ParishTaxTable.Admin.Models
{
    public class ParishDomicile
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public IEnumerable<Domicile> Domiciles { get; set; }
    }
}
