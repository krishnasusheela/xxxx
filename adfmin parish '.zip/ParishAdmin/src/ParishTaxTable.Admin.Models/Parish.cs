﻿namespace ParishTaxTable.Admin.Models
{
    public class Parish
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
