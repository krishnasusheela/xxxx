﻿using System.ComponentModel.DataAnnotations;

namespace ParishTaxTable.Admin.Models
{
    public class JurisdictionType
    {
        [Display(Name = "Jurisdiction Type")]
        [Range(1, int.MaxValue, ErrorMessage = "Jurisdiction Type Required")]
        public int Id { get; set; }

        [Display(Name= "Type")]
        public string Name { get; set; }
    }
}
