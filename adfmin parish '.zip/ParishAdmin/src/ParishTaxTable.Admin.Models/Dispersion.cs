﻿using Newtonsoft.Json;
using System;

namespace ParishTaxTable.Admin.Models
{
    public class Dispersion
    {
        public int Id { get; set; }
        public int DomicileId { get; set; }
        public int JurisdictionId { get; set; }
        public decimal DistributionRate { get; set; }
        public decimal VendorCompensation { get; set; }
        public bool IsInvalidDispersion { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? TermDate { get; set; }
        public Jurisdiction Jurisdiction { get; set; }

        [JsonIgnore]
        public string DisplayedDistributionRate => DistributionRate.ToString("p2");

        [JsonIgnore]
        public string DisplayedVendorCompensation => VendorCompensation.ToString("p2");

        [JsonIgnore]
        public string DisplayedEffectiveDate => EffectiveDate.ToString("yyyy-MM-dd");

        [JsonIgnore]
        public string DisplayedTermDate => TermDate?.ToString("yyyy-MM-dd");
    }
}
