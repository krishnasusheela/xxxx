﻿using System.Collections.Generic;

namespace ParishTaxTable.Admin.Models
{
    public class ParishJurisdiction
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public IEnumerable<Jurisdiction> Jurisdictions { get; set; }
    }
}
