﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParishTaxTable.Admin.Models
{
    public class ReportDescription
    {
        public int ReportId { get; set; }
        
        public string ReportName { get; set; }
        public string ReportLink { get; set; }
    }
}
