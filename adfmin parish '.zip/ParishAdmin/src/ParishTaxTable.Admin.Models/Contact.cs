﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace ParishTaxTable.Admin.Models
{
    public class Contact
    {
        public int Id { get; set; }


        [Display(Name= "Parish")]
        [Range(1, int.MaxValue, ErrorMessage = "Parish Required")]
        public int ParishId { get; set; }

        [StringLength(100)]
        [Display(Name= "Non-Parish Taxing Authority")]       
        public string TaxingAuthority { get; set; }

        [Required]
        [RegularExpression(@"^\d{9}-\d{2}$$", ErrorMessage = "Invalid EFT / Vendor Id. Format: 123456789-12")]
        [StringLength(25)]
        [Display(Name="EFT / Vendor Id")]
        public string EftCode { get; set; }

        [Required]
        [Display(Name= "Name")]       
        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(100)]
        [Display(Name= "Email")]       
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [Display(Name= "Recipient")]       
        [StringLength(100)]
        public string MailTo { get; set; }

        [Required]
        [Display(Name = "Address")]
        [StringLength(100)]
        public string Address1 { get; set; }

        [Display(Name = "Address (Line2)")]
        [StringLength(100)]
        public string Address2 { get; set; }

        [Required]
        [Display(Name = "City")]
        [StringLength(100)]
        public string City { get; set; }

        [Required]
        [Display(Name = "State")]
        [StringLength(2)]
        public string State { get; set; }

        [Required]
        [Display(Name = "Zip Code")]
        [StringLength(5)]
        [RegularExpression(@"^\d{5}$", ErrorMessage = "Invalid Zip Code")]
        public string Zip { get; set; }

        [StringLength(4, ErrorMessage = "There cannot be more than four characters in the Zip Code-4 field.")]
        [Display(Name = "Zip Code-4")]
        [RegularExpression(@"^\d{4}$", ErrorMessage = "Invalid Zip Code-4")]
        public string Zip4 { get; set; }

        [StringLength(15)]
        [Display(Name = "Phone Number")]
        public string ContactPhoneNumber { get; set; }

        [StringLength(10)]
        [Display(Name = "Phone Number's Extension")]
        public string ContactPhoneNumberExtension { get; set; }

        [StringLength(15)]
        [Display(Name = "Alternative Phone Number")]
        public string ContactPhoneNumberAlt { get; set; }

        [StringLength(10)]
        [Display(Name = "Alternative Phone Number's Extension")]
        public string ContactPhoneNumberAltExtension { get; set; }

        [StringLength(15)]
        [Display(Name = "Fax Number")]
        public string FaxPhoneNumber { get; set; }

        [Display(Name = "Tax Agreement Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? AgreementDate { get; set; }

        public DateTimeOffset CreateDate { get; set; }
        public DateTimeOffset? RetireDate { get; set; }

        [JsonIgnore]
        public string DisplayedContactPhoneNumber
        {
            get
            {
                if (String.IsNullOrEmpty(ContactPhoneNumber))
                    return "";
                else if (String.IsNullOrEmpty(ContactPhoneNumberExtension))
                    return ContactPhoneNumber;
                else
                    return ContactPhoneNumber + " x" + ContactPhoneNumberExtension;
            }
        }
        [JsonIgnore]
        public string DisplayedContactPhoneNumberAlt
        {
            get
            {
                if (String.IsNullOrEmpty(ContactPhoneNumberAlt))
                    return "";
                else if (String.IsNullOrEmpty(ContactPhoneNumberAltExtension))
                    return ContactPhoneNumberAlt;
                else
                    return ContactPhoneNumberAlt + " x" + ContactPhoneNumberAltExtension;
            }
        }
        [JsonIgnore]
        public string DisplayedAgreementDate => AgreementDate?.ToString("yyyy-MM-dd");

        [Display(Name = "City, State Zip Code")]
        [JsonIgnore]
        public string DisplayedCityStateZip
        {
            get
            {
                if (!String.IsNullOrEmpty(City) && !String.IsNullOrEmpty(Zip4))
                    return String.Format("{0}, {1}  {2}-{3}", City, State, Zip, Zip4);
                else
                if (!String.IsNullOrEmpty(City))
                    return String.Format("{0}, {1}  {2}", City, State, Zip);
                else
                    return "";
            }
        }

    }
}
