﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace ParishTaxTable.Admin.Models
{
    public class Domicile
    {
        public int Id { get; set; }
        public int ParishId { get; set; }
        public string CombinedCode { get; set; }
        public decimal CollectionRate { get; set; }
        public decimal ParishCollectionRate { get; set; }
        public decimal MunicipalityCollectionRate { get; set; }
        public decimal VendorCompensation { get; set; }
        public string ParishCode { get; set; }
        public string DomicileCode { get; set; }
        public string Name { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? TermDate { get; set; }
        public IEnumerable<Dispersion> Dispersions { get; set; }

        [JsonIgnore]
        public string DisplayedDomicileCode => CombinedCode + " - " + Name;
        [JsonIgnore]
        public string DisplayedCollectionRate => CollectionRate.ToString("p2");
        [JsonIgnore]
        public string DisplayedParishCollectionRate => ParishCollectionRate.ToString("p2");
        [JsonIgnore]
        public string DisplayedMunicipalityCollectionRate => MunicipalityCollectionRate.ToString("p2");
        [JsonIgnore]
        public string DisplayedVendorCompensation => VendorCompensation.ToString("p2");
        [JsonIgnore]
        public string DisplayedEffectiveDate => EffectiveDate.ToString("yyyy-MM-dd");
        [JsonIgnore]
        public string DisplayedTermDate => TermDate?.ToString("yyyy-MM-dd");
    }
}
