﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace ParishTaxTable.Admin.Models
{
    public class Jurisdiction
    {


        public int Id { get; set; }

        [Display(Name = "Parish")]
        [Range(1, int.MaxValue, ErrorMessage = "Parish is Required")]
        public int ParishId { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        [Required]
        public JurisdictionType JurisdictionType { get; set; }

        public DateTimeOffset CreateDate { get; set; }
        public DateTimeOffset? RetireDate { get; set; }

    }
}

