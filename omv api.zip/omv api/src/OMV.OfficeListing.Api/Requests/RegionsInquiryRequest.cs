﻿using System.Collections.Generic;
using MediatR;
using OMV.OfficeListing.Core.Entities;

namespace OMV.OfficeListing.Api.Requests
{
    public class RegionsInquiryRequest
         : IRequest<IEnumerable<Region>>
    {
    }
}
