﻿using MediatR;
using OMV.OfficeListing.Core.Entities;
using System.Collections.Generic;

namespace OMV.OfficeListing.Api.Requests
{
    public class ProgramFunctionsInquiryRequest
        : IRequest<IEnumerable<ProgramFunction>>
    {
    }
}
