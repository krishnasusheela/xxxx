﻿using MediatR;
using OMV.OfficeListing.Core.Entities;

namespace OMV.OfficeListing.Api.Requests
{
    public class RegionInquiryRequest : IRequest<Region>
    {
        public int Id { get; set; }
    }
}
