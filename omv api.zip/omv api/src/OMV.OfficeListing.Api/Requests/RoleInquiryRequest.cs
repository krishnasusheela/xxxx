﻿using MediatR;
using OMV.OfficeListing.Core.Entities;

namespace OMV.OfficeListing.Api.Requests
{
    public class RoleInquiryRequest : IRequest<Role>
    {
        public int Id { get; set; }
    }
}
