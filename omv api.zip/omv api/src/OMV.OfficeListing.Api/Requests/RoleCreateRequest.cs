﻿using MediatR;
using OMV.OfficeListing.Core.Entities;

namespace OMV.OfficeListing.Api.Requests
{
    public class RoleCreateRequest : IRequest<Role>
    {
        public RoleCreate Role { get; set; }
    }
}
