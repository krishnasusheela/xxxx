﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using OMV.OfficeListing.Api.Requests;

namespace OMV.OfficeListing.Api.Controllers
{
    [Route("api/[controller]")]
    public class RegionsController : Controller
    {
        private readonly IMediator mediator;

        public RegionsController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var regions = await mediator.Send(new RegionsInquiryRequest());
                if (regions == null || !regions.Any())
                    return NoContent();
                return Ok(regions);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var region = await mediator.Send(new RegionInquiryRequest() { Id = id });
                if (region == null)
                    return NoContent();
                return Ok(region);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
