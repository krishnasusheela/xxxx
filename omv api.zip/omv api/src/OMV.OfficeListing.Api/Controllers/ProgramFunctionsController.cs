﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using OMV.OfficeListing.Api.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Api.Controllers
{
    [Route("api/[controller]")]
    public class ProgramFunctionsController : Controller
    {
        private readonly IMediator mediator;

        public ProgramFunctionsController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var programFunctions = await mediator.Send(new ProgramFunctionsInquiryRequest());
                if (programFunctions == null || !programFunctions.Any())
                {
                    return NoContent();
                }
                return Ok(programFunctions);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
