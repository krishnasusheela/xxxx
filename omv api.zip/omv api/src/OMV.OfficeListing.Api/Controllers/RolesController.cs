﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;

namespace OMV.OfficeListing.Api.Controllers
{
    [Route("api/[controller]")]
    public class RolesController : Controller
    {
        private readonly IMediator mediator;

        public RolesController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        // GET api/values
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var roles = await mediator.Send(new RolesInquiryRequest());
                if (roles == null || !roles.Any())
                    return NoContent();
                return Ok(roles);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var role = await mediator.Send(new RoleInquiryRequest() { Id = id });
                if (role == null)
                    return NoContent();
                return Ok(role);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] RoleCreate role)
        {
            try
            {
                var result = await mediator.Send(new RoleCreateRequest() { Role = role });

                if (result == null)
                    return NoContent();

                return Ok(result);
            }
            catch (InvalidOperationException errorMessage)
            {
                return BadRequest(errorMessage.Message);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
