﻿using System;
using System.Collections.Generic;
using System.Linq;
using MediatR;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using OMV.OfficeListing.Api.Requests;

namespace OMV.OfficeListing.Api.Controllers
{
    [Route("api/[controller]")]
    public class PhoneNumberTypesController : Controller
    {
        private readonly IMediator mediator;

        public PhoneNumberTypesController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet]
        public async Task <IActionResult> Get()
        {
            try
            {
                var phoneNumberTypes = await mediator.Send(new PhoneNumberTypesInquiryRequest());
                if (phoneNumberTypes == null || !phoneNumberTypes.Any())
                    return NoContent();
                return Ok(phoneNumberTypes);
            }
            catch (Exception)
            {
                return BadRequest();
            }
           
        }
    }
}