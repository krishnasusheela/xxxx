﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using OMV.OfficeListing.Api.Requests;

namespace OMV.OfficeListing.Api.Controllers
{
    [Route("api/[controller]")]
    public class OfficesController: Controller
    {
        private readonly IMediator mediator;

        public OfficesController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var offices = await mediator.Send(new OfficesInquiryRequest());
                if (offices == null || !offices.Any())
                    return NoContent();
                return Ok(offices);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var office = await mediator.Send(new OfficeInquiryRequest() { Id = id });
                if (office == null)
                    return NoContent();
                return Ok(office);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
