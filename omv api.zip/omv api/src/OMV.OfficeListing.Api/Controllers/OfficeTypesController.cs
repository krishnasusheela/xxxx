﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using OMV.OfficeListing.Api.Requests;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Api.Controllers
{
    [Route("api/[controller]")]
    public class OfficeTypesController : Controller
    {
        private readonly IMediator mediator;

        public OfficeTypesController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var officeTypes = await mediator.Send(new OfficeTypesInquiryRequest());
                if (officeTypes == null || !officeTypes.Any())
                {
                    return NoContent();
                }
                return Ok(officeTypes);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}