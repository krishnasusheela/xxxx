﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using OMV.OfficeListing.Api.Requests;

namespace OMV.OfficeListing.Api.Controllers
{
    [Route("api/[controller]")]
    public class CapabilitiesController : Controller
    {
        private readonly IMediator mediator;
        
        public CapabilitiesController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var capabilities = await mediator.Send(new CapabilitiesInquiryRequest());
                if (capabilities == null || !capabilities.Any())
                    return NoContent();
                return Ok(capabilities);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var capability = await mediator.Send(new CapabilityInquiryRequest() { Id = id });
                if (capability == null)
                    return NoContent();
                return Ok(capability);
            }
            catch (Exception)
            {
                return BadRequest();
            }

        }
    }
}
