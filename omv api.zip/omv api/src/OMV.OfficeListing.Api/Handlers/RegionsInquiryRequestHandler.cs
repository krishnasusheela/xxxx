﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
namespace OMV.OfficeListing.Api.Handlers
{
    public class RegionsInquiryRequestHandler
     : IRequestHandler<RegionsInquiryRequest, IEnumerable<Region>>
    {
        private readonly IRegionDataService regionDataService;

        public RegionsInquiryRequestHandler(
            IRegionDataService regionDataService)
        {
            this.regionDataService = regionDataService;
        }

        public async Task<IEnumerable<Region>> Handle(
            RegionsInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await regionDataService.GetAllRegions();
        }
    }
}
