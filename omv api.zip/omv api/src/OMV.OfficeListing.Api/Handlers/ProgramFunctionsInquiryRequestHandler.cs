﻿using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Api.Handlers
{
    public class ProgramFunctionsInquiryRequestHandler
        : IRequestHandler<ProgramFunctionsInquiryRequest, IEnumerable<ProgramFunction>>
    {
        private readonly IProgramFunctionsDataService programFunctionsDataService;

        public ProgramFunctionsInquiryRequestHandler(
            IProgramFunctionsDataService programFunctionsDataService)
        {
            this.programFunctionsDataService = programFunctionsDataService;
        }

        public async Task<IEnumerable<ProgramFunction>> Handle(
            ProgramFunctionsInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await programFunctionsDataService.GetAllProgramFunctions();
        }
    }
}
