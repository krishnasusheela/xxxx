﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;

namespace OMV.OfficeListing.Api.Handlers
{
    public class OfficesInquiryRequestHandler : IRequestHandler<OfficesInquiryRequest, IEnumerable<Office>>
    {
        private readonly IOfficeDataService officeDataService;

        public OfficesInquiryRequestHandler(
           IOfficeDataService officeDataService)
        {
            this.officeDataService = officeDataService;
        }

        public async Task<IEnumerable<Office>> Handle(
            OfficesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await officeDataService.GetAllOffices();
        }
    }
}
