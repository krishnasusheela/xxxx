﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;

namespace OMV.OfficeListing.Api.Handlers
{
    public class RolesInquiryRequestHandler 
        : IRequestHandler<RolesInquiryRequest, IEnumerable<Role>>
    {
        private readonly IRoleDataService roleDataService;

        public RolesInquiryRequestHandler(
            IRoleDataService roleDataService)
        {
            this.roleDataService = roleDataService;
        }

        public async Task<IEnumerable<Role>> Handle(
            RolesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await roleDataService.GetAllRoles();
        }
    }
}
