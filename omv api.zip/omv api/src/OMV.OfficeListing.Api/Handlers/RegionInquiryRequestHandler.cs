﻿using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Api.Handlers
{
    public class RegionInquiryRequestHandler
        : IRequestHandler<RegionInquiryRequest, Region>
    {
        private readonly IRegionDataService regionDataService;

        public RegionInquiryRequestHandler(IRegionDataService regionDataService)
        {
            this.regionDataService = regionDataService;
        }

        public async Task<Region> Handle(
            RegionInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await regionDataService.GetRegionById(request.Id);
        }
    }
}
