﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;

namespace OMV.OfficeListing.Api.Handlers
{
    public class PhoneNumberTypesInquiryRequestHandler 
        : IRequestHandler<PhoneNumberTypesInquiryRequest, IEnumerable<PhoneNumberType>>
    {
        private readonly IPhoneNumberTypesDataService phoneNumberTypesDataService;

        public PhoneNumberTypesInquiryRequestHandler(
            IPhoneNumberTypesDataService phoneNumberTypesDataService)
        {
            this.phoneNumberTypesDataService = phoneNumberTypesDataService;
        }

        public async Task<IEnumerable<PhoneNumberType>> Handle(
            PhoneNumberTypesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await phoneNumberTypesDataService.GetAllPhoneNumberTypes();
        }
    }
}
