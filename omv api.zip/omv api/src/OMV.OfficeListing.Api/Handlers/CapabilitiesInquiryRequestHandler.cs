﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;

namespace OMV.OfficeListing.Api.Handlers
{
    public class CapabilitiesInquiryRequestHandler 
        : IRequestHandler<CapabilitiesInquiryRequest, IEnumerable<Capability>>
    {
        private readonly ICapabilityDataService capabilityDataService;

        public CapabilitiesInquiryRequestHandler(
           ICapabilityDataService capabilityDataService)
        {
            this.capabilityDataService = capabilityDataService;
        }

        public async Task<IEnumerable<Capability>> Handle(
            CapabilitiesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await capabilityDataService.GetAllCapabilities();
        }
    }
}
