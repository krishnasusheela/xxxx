﻿using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Api.Handlers
{
    public class RoleCreateRequestHandler
        : IRequestHandler<RoleCreateRequest, Role>
    {
        private readonly IRoleDataService roleDataService;

        public RoleCreateRequestHandler(
            IRoleDataService roleDataService)
        {
            this.roleDataService = roleDataService;
        }

        public async Task<Role> Handle(
            RoleCreateRequest request,
            CancellationToken cancellationToken)
        {
            return await roleDataService.CreateRole(request.Role);
        }
    }
}
