﻿using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Api.Handlers
{
    public class CapabilityInquiryRequestHandler 
        : IRequestHandler<CapabilityInquiryRequest, Capability>
    {
        private readonly ICapabilityDataService capabilityDataService;

        public CapabilityInquiryRequestHandler(ICapabilityDataService capabilityDataService)
        {
            this.capabilityDataService = capabilityDataService;
        }

        public async Task<Capability> Handle(
            CapabilityInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await capabilityDataService.GetCapabilityById(request.Id);
        }
    }
}
