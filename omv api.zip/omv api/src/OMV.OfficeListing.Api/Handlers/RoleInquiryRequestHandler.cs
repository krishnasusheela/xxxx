﻿using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Api.Handlers
{
    public class RoleInquiryRequestHandler 
        : IRequestHandler<RoleInquiryRequest, Role>
    {
        private readonly IRoleDataService roleDataService;

        public RoleInquiryRequestHandler (IRoleDataService roleDataService)
        {
            this.roleDataService = roleDataService;
        }

        public async Task<Role> Handle(
            RoleInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await roleDataService.GetRoleById(request.Id);
        }
    }
}
