﻿using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Api.Handlers
{
    public class OfficeInquiryRequestHandler
       : IRequestHandler<OfficeInquiryRequest, Office>
    {
        private readonly IOfficeDataService officeDataService;

        public OfficeInquiryRequestHandler(IOfficeDataService officeDataService)
        {
            this.officeDataService = officeDataService;
        }

        public async Task<Office> Handle(
            OfficeInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await officeDataService.GetOfficeById(request.Id);
        }
    }
}
