﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;

namespace OMV.OfficeListing.Api.Handlers
{
    public class OfficeTypesInquiryRequestHandler
         : IRequestHandler<OfficeTypesInquiryRequest, IEnumerable<OfficeType>>
    {
        private readonly IOfficeTypesDataService officeTypesDataService;

        public OfficeTypesInquiryRequestHandler(
            IOfficeTypesDataService officeTypesDataService)
        {
            this.officeTypesDataService = officeTypesDataService;
        }

        public async Task<IEnumerable<OfficeType>> Handle(
            OfficeTypesInquiryRequest request,
            CancellationToken cancellationToken)
        {
            return await officeTypesDataService.GetAllOfficeTypes();
        }
    }
}
