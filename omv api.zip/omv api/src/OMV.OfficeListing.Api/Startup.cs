﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using OMV.OfficeListing.Infrastructure.Interfaces.Rules;
using OMV.OfficeListing.Infrastructure.Models;
using OMV.OfficeListing.Infrastructure.Rules.Roles;
using OMV.OfficeListing.Infrastructure.Repositories;
using OMV.OfficeListing.Infrastructure.Services;

namespace OMV.OfficeListing.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMediatR(
                typeof(Startup).Assembly);

            services.AddDbContext<OfficeListingContext>(opt => opt.UseSqlServer(Configuration.GetConnectionString("DatabaseConnection")));

            services.AddScoped<IPhoneNumberTypeRepository, PhoneNumberTypeRepository>();
            services.AddScoped<ICapabilityRepository, CapabilityRepository>();
            services.AddScoped<IOfficeRepository, OfficeRepository>();
            services.AddScoped<IRegionRepository, RegionRepository>();
            services.AddScoped<IRoleRepository, RoleRepository>();
            services.AddScoped<IProgramFunctionRepository, ProgramFunctionRepository>();
            services.AddScoped<IOfficeTypeRepository, OfficeTypeRepository>();

            services.AddScoped<IRoleDataService, RoleDataService>();
            services.AddScoped<ICapabilityDataService, CapabilityDataService>();
            services.AddScoped<IRegionDataService, RegionDataService>();
            services.AddScoped<IOfficeDataService, OfficeDataService>();
            services.AddScoped<IOfficeTypesDataService, OfficeTypesDataService>();
            services.AddScoped<IPhoneNumberTypesDataService, PhoneNumberTypesDataService>();
            services.AddScoped<IProgramFunctionsDataService, ProgramFunctionsDataService>();

            services.AddTransient<IRoleCreateRules, RoleCreateRules>();

            services.AddTransient<ICreateRoleRule, CreatedRoleCannotHaveEffectiveDateInThePastRule>();
            services.AddTransient<ICreateRoleRule, CreatedRoleCannotHaveExpirationDateBeforeEffectiveDateRule>();
            services.AddTransient<ICreateRoleRule, AssignedCapabilityCannotHaveEffectiveDateInThePastOrNullRule>();
            services.AddTransient<ICreateRoleRule, AssignedCapabilityCannotHaveExpirationDateBeforeEffectiveDateOrNullRule>();

            services.AddAutoMapper();
            services.AddMvc();

        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseMvc();
        }
    }
}
