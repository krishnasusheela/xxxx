﻿using AutoMapper;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Infrastructure.Models;
using System.Linq;

namespace OMV.OfficeListing.Infrastructure.Mappings
{
    public class DataProfile
        : Profile
    {
        public DataProfile()
        {
            CreateMap<OfficeDto, Office>();
            CreateMap<RegionDto, Region>();
            CreateMap<ParishDto, Parish>();
            CreateMap<PhoneNumberDto, PhoneNumber>()
                .ForMember(
                    dest => dest.Number,
                    opt => opt.MapFrom(src => src.PhoneNumber));
            CreateMap<PhoneNumberTypeDto, PhoneNumberType>();
            CreateMap<RoleDto, Role>();
            CreateMap<Role, RoleDto>()
                .ForMember(
                    dest => dest.RoleCapabilities,
                    opt => opt.MapFrom(src => src.RoleCapabilities.Select(o => new RoleCapabilityDto
                    {
                        RoleId = src.Id,
                        CapabilityId = o.Capability.Id,
                        EffectiveDate = o.EffectiveDate,
                        ExpireDate = o.ExpireDate
                    })
                    .ToList()))
                .ForMember(
                    dest => dest.ProgramFunction,
                    opt => opt.Ignore())
                .ForMember(
                    dest => dest.OfficeType,
                    opt => opt.Ignore());
                
            CreateMap<RoleCreate, RoleDto>();

            CreateMap<CapabilityDto, Capability>()
                .ForMember(
                     dest => dest.OfficeTypes,
                     opt => opt.MapFrom(src => src.CapabilityOfficeTypes.Select(o => o.OfficeType)));
            CreateMap<Capability, CapabilityDto>()
                .ForMember(
                    dest => dest.ProgramFunction,
                    opt => opt.Ignore());
            CreateMap<OfficeTypeDto, OfficeType>();
            CreateMap<RoleCapabilityCreate, RoleCapabilityDto>();
            CreateMap<RoleCapability, RoleCapabilityDto>();
            CreateMap<ProgramFunctionDto, ProgramFunction>();
        }
    }
}
