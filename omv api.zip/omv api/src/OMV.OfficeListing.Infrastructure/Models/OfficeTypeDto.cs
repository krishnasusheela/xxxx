﻿using System;
using System.ComponentModel.DataAnnotations;

namespace OMV.OfficeListing.Infrastructure.Models
{
    public class OfficeTypeDto
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public Boolean IsValidForRole { get; set; }
    }
}
