using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OMV.OfficeListing.Infrastructure.Models
{
    [Table("ProgramFunctions")]
    public class ProgramFunctionDto
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
