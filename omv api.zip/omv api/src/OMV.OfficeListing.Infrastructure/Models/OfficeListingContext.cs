using Microsoft.EntityFrameworkCore;

namespace OMV.OfficeListing.Infrastructure.Models
{
    public class OfficeListingContext : DbContext
    {
        public OfficeListingContext(DbContextOptions<OfficeListingContext> options) : base(options)
        {
        }

        public DbSet<RoleDto> Roles { get; set; }
        public DbSet<CapabilityDto> Capabilities { get; set; }
        public DbSet<RoleCapabilityDto> RoleCapabilities { get; set; }
        public DbSet<OfficeDto> Offices { get; set; }
        public DbSet<ParishDto> Parishes { get; set; }
        public DbSet<RegionDto> Regions { get; set; }
        public DbSet<OfficeTypeDto> OfficeTypes { get; set; }
        public DbSet<CapabilityOfficeTypeDto> CapabilityOfficeTypes { get; set; }
        public DbSet<PhoneNumberDto> PhoneNumbers { get; set; }
        public DbSet<PhoneNumberTypeDto> PhoneNumberTypes { get; set; }
        public DbSet<ProgramFunctionDto> ProgramFunctions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CapabilityOfficeTypeDto>()
                .HasOne(co => co.Capability)
                .WithMany(c => c.CapabilityOfficeTypes)
                .HasForeignKey(co => co.CapabilityId);

            modelBuilder.Entity<RoleCapabilityDto>().HasKey(rc => new { rc.RoleId, rc.CapabilityId });
            modelBuilder.Entity<RoleCapabilityDto>()
                .HasOne(rc => rc.Role)
                .WithMany(r => r.RoleCapabilities)
                .HasForeignKey(rc => rc.RoleId);
            modelBuilder.Entity<RoleCapabilityDto>()
                .HasOne(rc => rc.Capability)
                .WithMany(c => c.RoleCapabilities)
                .HasForeignKey(rc => rc.CapabilityId);
        }
    }
}
