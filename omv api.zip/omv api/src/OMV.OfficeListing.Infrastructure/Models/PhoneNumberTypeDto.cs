﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OMV.OfficeListing.Infrastructure.Models
{
    public class PhoneNumberTypeDto
    {
        [Key]
        public int Id { get; set; }
        public string Type { get; set; }
        public IEnumerable<PhoneNumberDto> PhoneNumbers { get; set; }
    }
}
