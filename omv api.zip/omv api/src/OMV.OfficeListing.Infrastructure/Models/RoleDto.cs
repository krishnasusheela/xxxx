﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OMV.OfficeListing.Infrastructure.Models
{
    public class RoleDto
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string PublicDescription { get; set; }
        public Boolean IsPublic { get; set; }
        [ForeignKey("ProgramFunction")]
        public int ProgramFunctionId { get; set; }
        public ProgramFunctionDto ProgramFunction { get; set; }
        [ForeignKey("OfficeType")]
        public int OfficeTypeId { get; set; }
        public OfficeTypeDto OfficeType { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? ExpireDate { get; set; }
        public IEnumerable<RoleCapabilityDto> RoleCapabilities { get; set; }
    }
}
