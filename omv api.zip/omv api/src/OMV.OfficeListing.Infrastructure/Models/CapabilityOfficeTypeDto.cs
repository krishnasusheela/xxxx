﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OMV.OfficeListing.Infrastructure.Models
{
    [Table("CapabilitiesOfficeTypes")]
    public class CapabilityOfficeTypeDto
    {
        [Key]
        public int Id { set; get; }
        [ForeignKey("Capability")]
        public int CapabilityId { get; set; }
        [ForeignKey("OfficeType")]
        public int OfficeTypeId { get; set; }
        public CapabilityDto Capability { get; set; }
        public OfficeTypeDto OfficeType { get; set; }
    }
}
