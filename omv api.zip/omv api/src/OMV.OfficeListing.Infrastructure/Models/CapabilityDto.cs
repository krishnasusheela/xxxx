﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OMV.OfficeListing.Infrastructure.Models
{
    public class CapabilityDto
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? ExpireDate { get; set; }
        [ForeignKey("ProgramFunction")]
        public int ProgramFunctionId { get; set; }
        public ProgramFunctionDto ProgramFunction { get; set; }
        public IEnumerable<RoleCapabilityDto> RoleCapabilities { get; set; }
        public IEnumerable<CapabilityOfficeTypeDto> CapabilityOfficeTypes { get; set; }
    }
}
