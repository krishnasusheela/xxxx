﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OMV.OfficeListing.Infrastructure.Models
{
    public class OfficeDto
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey("Region")]
        public int RegionId { get; set; }
        [ForeignKey("Parish")]
        public int ParishId { get; set; }
        [ForeignKey("OfficeType")]
        public int OfficeTypeId { get; set; }
        public ParishDto Parish { get; set; }
        public RegionDto Region { get; set; }
        public OfficeTypeDto OfficeType { get; set; }
        public IEnumerable<PhoneNumberDto> PhoneNumbers { get; set; }
        public string InventoryFulfillmentCenter { get; set; }
        public string OfficeName { get; set; }
        public string OfficeNumber { get; set; }
        public string PhysicalAddress1 { get; set; }
        public string PhysicalAddress2 { get; set; }
        public string PhysicalCity { get; set; }
        public string PhysicalState { get; set; }
        public string PhysicalZip { get; set; }
        public string PhysicalZip4 { get; set; }
        public string MailingRecipient { get; set; }
        public string MailingAddress1 { get; set; }
        public string MailingAddress2 { get; set; }
        public string MailingCity { get; set; }
        public string MailingState { get; set; }
        public string MailingZip { get; set; }
        public string MailingZip4 { get; set; }
        public string OfficeManager { get; set; }
        public string RegionalManager { get; set; }
        public string HoursOperation { get; set; }
        public string DaysOperation { get; set; }
        public string CapabilityRoles { get; set; }
        public string MapDirections { get; set; }
        public string RoadSkillsSchedule { get; set; }
        public int? OfficeTotalOperators { get; set; }
        public string Status { get; set; }
        public string EftCode { get; set; }
    }
}
