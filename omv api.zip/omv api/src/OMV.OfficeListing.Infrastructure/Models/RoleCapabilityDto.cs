﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace OMV.OfficeListing.Infrastructure.Models
{
    [Table("RolesCapabilities")]
    public class RoleCapabilityDto
    {
        [ForeignKey("Role")]
        public int RoleId { get; set; }
        [ForeignKey("Capability")]
        public int CapabilityId { get; set; }
        public RoleDto Role { get; set; }
        public CapabilityDto Capability { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? ExpireDate { get; set; }
    }
}
