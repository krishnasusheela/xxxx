﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OMV.OfficeListing.Infrastructure.Models
{
    public class PhoneNumberDto
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey("Office")]
        public int OfficeId { get; set; }
        [ForeignKey("PhoneNumberType")]
        public int PhoneNumberTypeId { get; set; }
        public OfficeDto Office { get; set; }
        public PhoneNumberTypeDto PhoneNumberType { get; set; }
        public string PhoneNumber { get; set; }
        public string PhoneNumberExtension { get; set; }
    }
}
