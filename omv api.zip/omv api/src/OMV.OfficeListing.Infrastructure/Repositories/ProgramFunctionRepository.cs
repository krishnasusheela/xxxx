﻿using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using OMV.OfficeListing.Infrastructure.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Repositories
{
    public class ProgramFunctionRepository
        : IProgramFunctionRepository
    {
        private readonly OfficeListingContext context;

        public ProgramFunctionRepository(
            OfficeListingContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<ProgramFunctionDto>> Get()
        {
            return await context
                .ProgramFunctions
                .ToListAsync();
        }
    }
}
