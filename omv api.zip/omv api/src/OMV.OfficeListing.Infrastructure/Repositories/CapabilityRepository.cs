﻿using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using OMV.OfficeListing.Infrastructure.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Repositories
{
    public class CapabilityRepository
        : ICapabilityRepository
    {
        private readonly OfficeListingContext context;

        public CapabilityRepository(
            OfficeListingContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<CapabilityDto>> Get()
        {
            return await context.Capabilities
                .Include(x => x.ProgramFunction)
                .Include(p => p.CapabilityOfficeTypes)
                .ThenInclude(p => p.OfficeType)
                .Include(p => p.RoleCapabilities)
                .ThenInclude(p => p.Role)
                .ToListAsync();
        }

        public async Task<CapabilityDto> GetById(int id)
        {

            return await context.Capabilities
                .Include(x => x.ProgramFunction)
                .Include(p => p.CapabilityOfficeTypes)
                .ThenInclude(p => p.OfficeType)
                .Include(x => x.RoleCapabilities)
                .ThenInclude(x => x.Role)
                .SingleOrDefaultAsync(t => t.Id == id);
        }
    }
}
