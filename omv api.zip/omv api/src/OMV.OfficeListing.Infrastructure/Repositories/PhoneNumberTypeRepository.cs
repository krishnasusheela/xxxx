﻿using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using OMV.OfficeListing.Infrastructure.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Repositories
{
    public class PhoneNumberTypeRepository 
        : IPhoneNumberTypeRepository
    {
        private readonly OfficeListingContext context;

        public PhoneNumberTypeRepository(
            OfficeListingContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<PhoneNumberTypeDto>> Get()
        {
            return await context
                .PhoneNumberTypes
                .ToListAsync();
        }
    }
}
