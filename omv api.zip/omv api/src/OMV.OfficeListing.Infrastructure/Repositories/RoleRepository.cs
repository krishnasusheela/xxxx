﻿using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using OMV.OfficeListing.Infrastructure.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Repositories
{
    public class RoleRepository
        : IRoleRepository
    {
        private readonly OfficeListingContext context;

        public RoleRepository(
            OfficeListingContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<RoleDto>> Get()
        {
            return await context.Roles
                .Include(x => x.ProgramFunction)
                .Include(x => x.OfficeType)
                .Include(x => x.RoleCapabilities)
                .ThenInclude(x => x.Capability)
                .ThenInclude(x => x.CapabilityOfficeTypes)
                .ThenInclude(x => x.OfficeType)
                .ToListAsync();
        }

        public async Task<RoleDto> GetById(int id)
        {
            return await context.Roles
                .IgnoreQueryFilters()
                .Include(x => x.ProgramFunction)
                .Include(x => x.OfficeType)
                .Include(x => x.RoleCapabilities)
                .ThenInclude(x => x.Capability)
                .ThenInclude(x => x.CapabilityOfficeTypes)
                .ThenInclude(x => x.OfficeType)
                .SingleOrDefaultAsync(t => t.Id == id);
        }

        public async Task<RoleDto> Create(RoleDto role)
        {
            context.Roles.Add(role);
            await context.SaveChangesAsync();

            return await GetById(role.Id);
        }
    }
}
