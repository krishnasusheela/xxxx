﻿using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using OMV.OfficeListing.Infrastructure.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Repositories
{
    public class OfficeRepository
        : IOfficeRepository
    {
        private readonly OfficeListingContext context;

        public OfficeRepository(
            OfficeListingContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<OfficeDto>> Get()
        {
            return await context.Offices
                .Include(x => x.Region)
                .Include(x => x.Parish)
                .Include(x => x.OfficeType)
                .Include(x => x.PhoneNumbers)
                .ThenInclude(x => x.PhoneNumberType)
                .ToListAsync();
        }

        public async Task<OfficeDto> GetById(int id)
        {
            return await context.Offices
                .IgnoreQueryFilters()
                .Include(x => x.Region)
                .Include(x => x.Parish)
                .Include(x => x.OfficeType)
                .Include(x => x.PhoneNumbers)
                .ThenInclude(x => x.PhoneNumberType)
                .SingleOrDefaultAsync(t => t.Id == id);
        }
    }
}
