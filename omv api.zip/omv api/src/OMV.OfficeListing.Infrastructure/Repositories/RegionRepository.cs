﻿using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using OMV.OfficeListing.Infrastructure.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Repositories
{
    public class RegionRepository
        : IRegionRepository
    {
        private readonly OfficeListingContext context;

        public RegionRepository(
            OfficeListingContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<RegionDto>> Get()
        {
            return await context.Regions                
                .ToListAsync();
        }

        public async Task<RegionDto> GetById(int id)
        {

            return await context.Regions
                .IgnoreQueryFilters()       
                .SingleOrDefaultAsync(t => t.Id == id);
        }
    }
}
