﻿using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using OMV.OfficeListing.Infrastructure.Models;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace OMV.OfficeListing.Infrastructure.Repositories
{
   public class OfficeTypeRepository
        :IOfficeTypeRepository
    {
        private readonly OfficeListingContext context;

        public OfficeTypeRepository(
            OfficeListingContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<OfficeTypeDto>> Get()
        {
            return await context
                .OfficeTypes
                .ToListAsync();
        }
    }
}
