﻿using System.Collections.Generic;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Core.Entities;
using AutoMapper;
using System.Threading.Tasks;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;

namespace OMV.OfficeListing.Infrastructure.Services
{
    public class OfficeDataService
        : IOfficeDataService
    {

        private readonly IOfficeRepository repository;
        private readonly IMapper mapper;

        public OfficeDataService(IOfficeRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<Office> GetOfficeById(int id)
        {
            var office = await repository.GetById(id);
            return mapper.Map<Office>(office);
        }

        public async Task<IEnumerable<Office>> GetAllOffices()
        {
            var offices = await repository.Get();

            return mapper.Map<IEnumerable<Office>>(
                offices);
        }
    }
}