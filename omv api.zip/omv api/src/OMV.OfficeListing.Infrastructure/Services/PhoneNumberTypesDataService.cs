﻿using System.Collections.Generic;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Core.Entities;
using AutoMapper;
using System.Threading.Tasks;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;

namespace OMV.OfficeListing.Infrastructure.Services
{
    public class PhoneNumberTypesDataService
        : IPhoneNumberTypesDataService
    {
        private readonly IPhoneNumberTypeRepository repository;
        private readonly IMapper mapper;

        public PhoneNumberTypesDataService(
            IPhoneNumberTypeRepository repository, 
            IMapper mapper)
        {
            this.mapper = mapper;
            this.repository = repository;
        }
        
        
        public async Task<IEnumerable<PhoneNumberType>> GetAllPhoneNumberTypes()
        {
            var types = await repository
                .Get();

            return mapper.Map<IEnumerable<PhoneNumberType>>(types);
        }
    }
}
