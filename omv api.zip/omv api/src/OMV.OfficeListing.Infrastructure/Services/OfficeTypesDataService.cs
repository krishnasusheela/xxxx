﻿using System.Collections.Generic;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Core.Entities;
using AutoMapper;
using System.Threading.Tasks;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;

namespace OMV.OfficeListing.Infrastructure.Services
{
    public class OfficeTypesDataService
        : IOfficeTypesDataService
    {
        private readonly IOfficeTypeRepository repository;
        private readonly IMapper mapper;

        public OfficeTypesDataService(
           IOfficeTypeRepository repository,
           IMapper mapper)
        {
            this.mapper = mapper;
            this.repository = repository;
        }


        public async Task<IEnumerable<OfficeType>> GetAllOfficeTypes()
        {
            var types = await repository
                .Get();

            return mapper.Map<IEnumerable<OfficeType>>(types);
        }
    }
}
