﻿using System.Collections.Generic;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Infrastructure.Models;
using AutoMapper;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;

namespace OMV.OfficeListing.Infrastructure.Services
{
    public class CapabilityDataService : ICapabilityDataService
    {
        private readonly ICapabilityRepository repository;
        private readonly IMapper mapper;

        public CapabilityDataService(
            ICapabilityRepository repository,
            IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<Capability>> GetAllCapabilities()
        {
            var capabilities = await repository.Get();

            return mapper.Map<IEnumerable<Capability>>(
                capabilities);
        }

        public async Task<Capability> GetCapabilityById(int id)
        {
            var capability = await repository.GetById(id);

            return mapper.Map<Capability>(capability);
        }      
    }
}
