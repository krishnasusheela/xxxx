﻿using System.Collections.Generic;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Infrastructure.Models;
using AutoMapper;
using System.Threading.Tasks;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using OMV.OfficeListing.Infrastructure.Interfaces.Rules;

namespace OMV.OfficeListing.Infrastructure.Services
{
    public class RoleDataService 
        : IRoleDataService
    {
        private readonly IRoleRepository repository;
        private readonly IMapper mapper;
        private readonly IRoleCreateRules createRules;

        public RoleDataService(
            IRoleRepository repository,
            IMapper mapper,
            IRoleCreateRules createRules)
        {
            this.repository = repository;
            this.mapper = mapper;
            this.createRules = createRules;
        }

        public async Task<IEnumerable<Role>> GetAllRoles()
        {
            var roles = await repository.Get();

            return mapper.Map<IEnumerable<Role>>(
                roles);
        }

        public async Task<Role> GetRoleById(int id)
        {
            var role = await repository.GetById(id);

            return mapper.Map<Role>(role);
        }

        public async Task<Role> CreateRole(RoleCreate role)
        {
            var dto = mapper.Map<RoleDto>(role);

            createRules
                .Test(dto);

            var createdRole = await repository
                .Create(dto);

            return mapper.Map<Role>(createdRole);
        }
    }
}
