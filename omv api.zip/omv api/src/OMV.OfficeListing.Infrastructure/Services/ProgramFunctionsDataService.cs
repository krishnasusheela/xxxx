﻿using AutoMapper;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Services
{
    public class ProgramFunctionsDataService
        : IProgramFunctionsDataService
    {
        private readonly IProgramFunctionRepository repository;
        private readonly IMapper mapper;

        public ProgramFunctionsDataService(
            IProgramFunctionRepository repository,
            IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<ProgramFunction>> GetAllProgramFunctions()
        {
            var programFunctions = await repository.Get();

            return mapper.Map<IEnumerable<ProgramFunction>>(programFunctions);
        }
    }
}
