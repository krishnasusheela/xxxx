﻿using System.Collections.Generic;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Core.Entities;
using System.Linq;
using OMV.OfficeListing.Infrastructure.Models;
using AutoMapper;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;

namespace OMV.OfficeListing.Infrastructure.Services
{
    public class RegionDataService
        : IRegionDataService
    {
        private readonly IRegionRepository repository;
        private readonly IMapper mapper;

        public RegionDataService(
            IRegionRepository repository,
            IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<Region>> GetAllRegions()
        {
            var regions = await repository.Get();

            return mapper.Map<IEnumerable<Region>>(
                regions);
        }

        public async Task<Region> GetRegionById(int id)
        {
            var region = await repository.GetById(id);

            return mapper.Map<Region>(region);
        }
    }
}
