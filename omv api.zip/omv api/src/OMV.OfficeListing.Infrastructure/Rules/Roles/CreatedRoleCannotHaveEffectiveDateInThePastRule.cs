﻿using OMV.OfficeListing.Infrastructure.Interfaces.Rules;
using OMV.OfficeListing.Infrastructure.Models;
using System;

namespace OMV.OfficeListing.Infrastructure.Rules.Roles
{
    public class CreatedRoleCannotHaveEffectiveDateInThePastRule
        : ICreateRoleRule
    {
        private const string ExceptionMessage =
            "Newly created roles cannot have effective dates in the past.";

        public void Test(
            RoleDto roleToCreate)
        {
            if (roleToCreate.EffectiveDate <= DateTimeOffset.Now)
            {
                throw new InvalidOperationException(
                    ExceptionMessage);
            }
        }
    }
}
