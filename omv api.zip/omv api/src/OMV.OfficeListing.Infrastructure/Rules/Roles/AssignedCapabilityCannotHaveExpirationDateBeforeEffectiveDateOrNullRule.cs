﻿using OMV.OfficeListing.Infrastructure.Interfaces.Rules;
using OMV.OfficeListing.Infrastructure.Models;
using System;

namespace OMV.OfficeListing.Infrastructure.Rules.Roles
{
    public class AssignedCapabilityCannotHaveExpirationDateBeforeEffectiveDateOrNullRule
        : ICreateRoleRule
    {
        private const string ExceptionMessage =
            "The expiration date cannot be prior to the effective date.";

        public void Test(
            RoleDto roleToCreate)
        {
            if (roleToCreate.RoleCapabilities != null)
            {
                foreach (var roleCapability in roleToCreate.RoleCapabilities)
                {
                    if (roleCapability.ExpireDate <= roleCapability.EffectiveDate)
                    {
                        throw new InvalidOperationException(
                            ExceptionMessage);
                    }
                }
            }
        }
    }
}
