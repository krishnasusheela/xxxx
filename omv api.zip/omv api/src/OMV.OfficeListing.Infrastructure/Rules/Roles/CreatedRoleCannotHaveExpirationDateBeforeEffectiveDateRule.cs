﻿using OMV.OfficeListing.Infrastructure.Interfaces.Rules;
using OMV.OfficeListing.Infrastructure.Models;
using System;

namespace OMV.OfficeListing.Infrastructure.Rules.Roles
{
    public class CreatedRoleCannotHaveExpirationDateBeforeEffectiveDateRule
        : ICreateRoleRule
    {
        private const string ExceptionMessage =
            "The expiration date cannot be prior to the effective date.";

        public void Test(
            RoleDto roleToCreate)
        {
            if (roleToCreate.ExpireDate <= roleToCreate.EffectiveDate)
            {
                throw new InvalidOperationException(
                    ExceptionMessage);
            }
        }
    }
}
