﻿using OMV.OfficeListing.Infrastructure.Interfaces.Rules;
using OMV.OfficeListing.Infrastructure.Models;
using System.Collections.Generic;

namespace OMV.OfficeListing.Infrastructure.Rules.Roles
{
    public class RoleCreateRules
        : IRoleCreateRules
    {
        private readonly IEnumerable<ICreateRoleRule> rules;

        public RoleCreateRules(
            IEnumerable<ICreateRoleRule> rules)
        {
            this.rules = rules;
        }

        public void Test(RoleDto roleToCreate)
        {
            foreach (var rule in rules)
            {
                rule.Test(roleToCreate);
            }
        }
    }
}
