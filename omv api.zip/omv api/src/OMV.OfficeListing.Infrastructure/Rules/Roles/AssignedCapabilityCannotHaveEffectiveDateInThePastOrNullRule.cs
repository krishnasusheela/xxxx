﻿using OMV.OfficeListing.Infrastructure.Interfaces.Rules;
using OMV.OfficeListing.Infrastructure.Models;
using System;

namespace OMV.OfficeListing.Infrastructure.Rules.Roles
{
    public class AssignedCapabilityCannotHaveEffectiveDateInThePastOrNullRule 
        : ICreateRoleRule
    {
        private const string ExceptionMessage =
            "Newly added capabilities cannot take immediate effect.";

        public void Test(
            RoleDto roleToCreate)
        {
            if (roleToCreate.RoleCapabilities != null)
            {
                foreach (var roleCapability in roleToCreate.RoleCapabilities)
                {
                    if (roleCapability.EffectiveDate <= DateTimeOffset.Now)
                    {
                        throw new InvalidOperationException(
                            ExceptionMessage);
                    }
                }
            }
        }
    }
}
