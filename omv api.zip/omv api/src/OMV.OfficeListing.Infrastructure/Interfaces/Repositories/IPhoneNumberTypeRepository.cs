﻿using OMV.OfficeListing.Infrastructure.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Interfaces.Repositories
{
   public interface IPhoneNumberTypeRepository
   {
        Task<IEnumerable<PhoneNumberTypeDto>> Get();
   }
}
