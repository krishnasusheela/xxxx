﻿using System.Collections.Generic;
using OMV.OfficeListing.Infrastructure.Models;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Interfaces.Repositories
{
    public interface ICapabilityRepository
    {
        Task<IEnumerable<CapabilityDto>> Get();
        Task<CapabilityDto> GetById(int id);
    }
}
