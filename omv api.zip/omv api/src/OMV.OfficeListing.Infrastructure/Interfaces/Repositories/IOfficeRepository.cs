﻿using OMV.OfficeListing.Infrastructure.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Interfaces.Repositories
{
   public interface IOfficeRepository
    {
        Task<IEnumerable<OfficeDto>> Get();
        Task<OfficeDto> GetById(int id);
    }
}
