﻿using System.Collections.Generic;
using OMV.OfficeListing.Infrastructure.Models;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Interfaces.Repositories
{
    public interface IRegionRepository
    {
        Task<IEnumerable<RegionDto>> Get();
        Task<RegionDto> GetById(int id);
    }
}
