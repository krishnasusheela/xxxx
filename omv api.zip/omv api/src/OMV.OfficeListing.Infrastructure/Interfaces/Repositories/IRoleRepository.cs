﻿using System.Collections.Generic;
using System.Threading.Tasks;
using OMV.OfficeListing.Infrastructure.Models;

namespace OMV.OfficeListing.Infrastructure.Interfaces.Repositories
{
    public interface IRoleRepository
    {
        Task<IEnumerable<RoleDto>> Get();
        Task<RoleDto> GetById(int id);
        Task<RoleDto> Create(RoleDto role);
    }
}
