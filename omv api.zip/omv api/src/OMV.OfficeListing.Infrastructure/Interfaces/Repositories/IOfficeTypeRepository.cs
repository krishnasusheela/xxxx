﻿using System.Collections.Generic;
using OMV.OfficeListing.Infrastructure.Models;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Infrastructure.Interfaces.Repositories
{
   public interface IOfficeTypeRepository
    {
        Task<IEnumerable<OfficeTypeDto>> Get();
    }
}
