﻿using OMV.OfficeListing.Infrastructure.Models;

namespace OMV.OfficeListing.Infrastructure.Interfaces.Rules
{
    public interface IRoleCreateRules
    {
        void Test(RoleDto roleToCreate);
    }
}
