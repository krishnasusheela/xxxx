﻿using OMV.OfficeListing.Infrastructure.Models;

namespace OMV.OfficeListing.Infrastructure.Interfaces.Rules
{
    public interface ICreateRoleRule
    {
        void Test(RoleDto roleToCreate);
    }
}
