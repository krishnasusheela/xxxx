﻿using System;

namespace OMV.OfficeListing.Core.Entities
{
    public class RoleCapability
    {
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? ExpireDate { get; set; }
        public Capability Capability { get; set; }
    }
}
