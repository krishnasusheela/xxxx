﻿using System;
using System.Collections.Generic;

namespace OMV.OfficeListing.Core.Entities
{
    public class RoleCreate
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string PublicDescription { get; set; }
        public Boolean IsPublic { get; set; }
        public int ProgramFunctionId { get; set; }
        public int OfficeTypeId { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? ExpireDate { get; set; }
        public IEnumerable<RoleCapabilityCreate> RoleCapabilities { get; set; }
    }
}
