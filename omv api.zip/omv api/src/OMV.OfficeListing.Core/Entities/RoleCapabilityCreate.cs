﻿using System;

namespace OMV.OfficeListing.Core.Entities
{
    public class RoleCapabilityCreate
    {
        public DateTimeOffset EffectiveDate { get; set; }
        public DateTimeOffset? ExpireDate { get; set; }
        public int CapabilityId { get; set; }
    }
}
