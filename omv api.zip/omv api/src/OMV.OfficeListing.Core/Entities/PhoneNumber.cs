﻿namespace OMV.OfficeListing.Core.Entities
{
    public class PhoneNumber
    {
        public int Id { get; set; }
        public string Number { get; set; }
        public string PhoneNumberExtension { get; set; }
        public PhoneNumberType PhoneNumberType { get; set; }
    }
}
