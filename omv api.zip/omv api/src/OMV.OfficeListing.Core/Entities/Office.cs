﻿using System.Collections.Generic;

namespace OMV.OfficeListing.Core.Entities
{
    public class Office
    {
        public int Id { get; set; }
        public Region Region { get; set; }
        public Parish Parish { get; set; }
        public OfficeType OfficeType { get; set; }
        public IEnumerable<PhoneNumber> PhoneNumbers { get; set; }
        public string OfficeName { get; set; }
        public string OfficeNumber { get; set; }
        public string PhysicalAddress1 { get; set; }
        public string PhysicalAddress2 { get; set; }
        public string PhysicalCity { get; set; }
        public string PhysicalState { get; set; }
        public string PhysicalZip { get; set; }
        public string PhysicalZip4 { get; set; }
        public string MailingRecipient { get; set; }
        public string MailingAddress1 { get; set; }
        public string MailingAddress2 { get; set; }
        public string MailingCity { get; set; }
        public string MailingState { get; set; }
        public string MailingZip { get; set; }
        public string MailingZip4 { get; set; }
        public string OfficeManager { get; set; }
        public string RegionalManager { get; set; }
        public string HoursOperation { get; set; }
        public string DaysOperation { get; set; }
        public string CapabilityRoles { get; set; }
        public string MapDirections { get; set; }
        public string RoadSkillsSchedule { get; set; }
        public int? OfficeTotalOperators { get; set; }
        public string Status { get; set; }
        public string EftCode { get; set; }
    }
}
