﻿namespace OMV.OfficeListing.Core.Entities
{
    public class Region
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
