namespace OMV.OfficeListing.Core.Entities
{
    public class ProgramFunction
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
