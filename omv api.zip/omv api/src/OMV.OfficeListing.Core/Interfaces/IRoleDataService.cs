﻿using System.Collections.Generic;
using System.Threading.Tasks;
using OMV.OfficeListing.Core.Entities;

namespace OMV.OfficeListing.Core.Interfaces
{
    public interface IRoleDataService
    {
        Task<Role> GetRoleById(int id);
        Task<IEnumerable<Role>> GetAllRoles();
        Task<Role> CreateRole(RoleCreate role);
    }
}
