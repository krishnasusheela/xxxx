﻿using System.Collections.Generic;
using System.Threading.Tasks;
using OMV.OfficeListing.Core.Entities;

namespace OMV.OfficeListing.Core.Interfaces
{
    public interface IOfficeDataService
    {
        Task<Office> GetOfficeById(int id);
        Task<IEnumerable<Office>> GetAllOffices();
    }
}
