﻿using System.Collections.Generic;
using System.Threading.Tasks;
using OMV.OfficeListing.Core.Entities;

namespace OMV.OfficeListing.Core.Interfaces
{
    public interface ICapabilityDataService
    {
        Task<Capability> GetCapabilityById(int id);
        Task<IEnumerable<Capability>> GetAllCapabilities();
    }
}
