﻿using OMV.OfficeListing.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Core.Interfaces
{
    public interface IProgramFunctionsDataService
    {
        Task<IEnumerable<ProgramFunction>> GetAllProgramFunctions();
    }
}
