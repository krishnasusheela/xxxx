﻿using OMV.OfficeListing.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OMV.OfficeListing.Core.Interfaces
{
    public interface IRegionDataService
    {
        Task<Region> GetRegionById(int id);
        Task<IEnumerable<Region>> GetAllRegions();
    }
}
