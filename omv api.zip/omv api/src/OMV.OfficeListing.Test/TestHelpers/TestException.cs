﻿using System;

namespace OMV.OfficeListing.Test.TestHelpers
{
    public class TestException
        : Exception
    {
    }
}
