﻿using System;
using System.Collections.Generic;
using AutoFixture;
using OMV.OfficeListing.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace OMV.OfficeListing.Test.TestHelpers
{
    public abstract class OfficeListingContextTestBase
        : IDisposable
    {
        protected readonly Fixture TestFixture;
        protected readonly OfficeListingContext TableContext;
        protected abstract void Dispose(bool disposing);

        protected OfficeListingContextTestBase()
        {
            TestFixture = new Fixture();

            TableContext = new OfficeListingContext(
                new DbContextOptionsBuilder<OfficeListingContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging()
                .Options);

            TableContext.Database.EnsureCreated();
        }
        ~OfficeListingContextTestBase()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            TableContext.Database.EnsureDeleted();
            TableContext.Dispose();

            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected void Seed(OfficeListingContext tableContext)
        {
            var officeTypes = new List<OfficeTypeDto>();
            var regions = new List<RegionDto>();
            var parishes = new List<ParishDto>();
            var offices = new List<OfficeDto>();

            var phoneNumbers = new List<PhoneNumberDto>();
            var phoneNumberTypes = new List<PhoneNumberTypeDto>();
            var programFunction = new List<ProgramFunctionDto>();

            var roles = new List<RoleDto>();
            var capabilities = new List<CapabilityDto>();

            var roleCapabilities = new List<RoleCapabilityDto>();

            for (var i = 0; i < 5; i++)
            {
                var id = i + 1;

                officeTypes.Add(CreateOfficeTypeWithRelatedData(id));
                regions.Add(CreateRegionWithRelatedData(id));
                parishes.Add(CreateParishWithRelatedData(id));
                offices.Add(CreateOfficeWithRelatedData(id));
                offices[i].ParishId = parishes[i].Id;
                offices[i].RegionId = regions[i].Id;
                offices[i].OfficeTypeId = officeTypes[i].Id;

                phoneNumbers.Add(CreatePhoneNumberWithRelatedData(id));
                phoneNumberTypes.Add(CreatePhoneNumberType(id));
                phoneNumbers[i].OfficeId = offices[i].Id;
                phoneNumbers[i].PhoneNumberTypeId = phoneNumberTypes[i].Id;

                roles.Add(CreateRoleWithRelatedData(id));
                capabilities.Add(CreateCapabilityWithRelatedData(id));
                
                roleCapabilities.Add(
                    CreateRoleCapabilityWithRelatedData(
                        roles[i].Id,
                        capabilities[i].Id));
            }

            tableContext.OfficeTypes.AddRange(officeTypes);
            tableContext.Regions.AddRange(regions);
            tableContext.Parishes.AddRange(parishes);
            tableContext.Offices.AddRange(offices);
            tableContext.ProgramFunctions.AddRange(programFunction);
            tableContext.PhoneNumbers.AddRange(phoneNumbers);
            tableContext.PhoneNumberTypes.AddRange(phoneNumberTypes);

            tableContext.Roles.AddRange(roles);
            tableContext.Capabilities.AddRange(capabilities);

            tableContext.RoleCapabilities.AddRange(roleCapabilities);

            tableContext.SaveChanges();
        }

        protected CapabilityDto CreateCapabilityWithRelatedData(int id)
        {
            var capability = TestFixture
                .Build<CapabilityDto>()
                .With(p => p.Id, id)
                .Without(p => p.RoleCapabilities)
                .Without(p => p.CapabilityOfficeTypes)
                .Create();

            return capability;
        }

        protected OfficeDto CreateOfficeWithRelatedData(int id)
        {
            var office = TestFixture
                .Build<OfficeDto>()
                .With(p => p.Id, id)
                .Without(p => p.Region)
                .Without(p => p.Parish)
                .Without(p => p.OfficeType)
                .Without(p => p.PhoneNumbers)
                .Create();

            return office;
        }

        protected OfficeTypeDto CreateOfficeTypeWithRelatedData(int id)
        {
            var officeType = TestFixture
                .Build<OfficeTypeDto>()
                .With(p => p.Id, id)
                .Create();

            return officeType;
        }

        protected ParishDto CreateParishWithRelatedData(int id)
        {
            var parish = TestFixture
                .Build<ParishDto>()
                .With(p => p.Id, id)
                .Create();

            return parish;
        }

        protected PhoneNumberDto CreatePhoneNumberWithRelatedData(int id)
        {
            var phoneNumber = TestFixture
                .Build<PhoneNumberDto>()
                .With(p => p.Id, id)
                .Without(p => p.Office)
                .Without(p => p.PhoneNumberType)
                .Create();

            return phoneNumber;
        }

        protected PhoneNumberTypeDto CreatePhoneNumberType(int id)
        {
            var phoneNumberType = TestFixture
                .Build<PhoneNumberTypeDto>()
                .With(p => p.Id, id)
                .Without(p => p.PhoneNumbers)
                .Create();

            return phoneNumberType;
        }

        protected ProgramFunctionDto CreateProgramFunction(int id)
        {
            var programFunction = TestFixture
                .Build<ProgramFunctionDto>()
                .With(p => p.Id, id)
                .Create();

            return programFunction;
        }

        protected RegionDto CreateRegionWithRelatedData(int id)
        {
            var region = TestFixture
                .Build<RegionDto>()
                .With(p => p.Id, id)
                .Create();

            return region;
        }

        protected RoleCapabilityDto CreateRoleCapabilityWithRelatedData(int roleId, int capabilityId)
        {
            var roleCapability = TestFixture
                .Build<RoleCapabilityDto>()
                .With(p => p.RoleId, roleId)
                .With(p => p.CapabilityId, capabilityId)
                .Without(p => p.Role)
                .Without(p => p.Capability)
                .Create();

            return roleCapability;
        }

        protected RoleDto CreateRoleWithRelatedData(int id)
        {
            var role = TestFixture
                .Build<RoleDto>()
                .With(p => p.Id, id)
                .Without(p => p.RoleCapabilities)
                .Create();

            return role;
        }
    }
}
