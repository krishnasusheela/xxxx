﻿using AutoFixture;
using System;
using System.Collections.Generic;
using OMV.OfficeListing.Api.Controllers;
using Moq;
using MediatR;
using Xunit;
using System.Threading.Tasks;
using OMV.OfficeListing.Core.Entities;
using Microsoft.AspNetCore.Mvc;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Test.TestHelpers;

namespace OMV.OfficeListing.Test.Controllers
{
    public class ProgramFunctionsControllerTests : IDisposable
    {
        private Fixture fixture;
        private ProgramFunctionsController controller;
        private Mock<IMediator> mediatorMock;

        public ProgramFunctionsControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller = new ProgramFunctionsController(mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorException()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ProgramFunctionsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get();
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNull()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ProgramFunctionsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((IEnumerable<ProgramFunction>)null);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsEmpty()
        {
            var expected = new List<ProgramFunction>();
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ProgramFunctionsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResult()
        {
            var expected =
                fixture.Create<IEnumerable<ProgramFunction>>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<ProgramFunctionsInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<ProgramFunction>>(viewResult.Value);
        }
    }
}
