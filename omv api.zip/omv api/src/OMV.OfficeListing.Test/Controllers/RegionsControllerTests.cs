﻿using AutoFixture;
using System;
using System.Collections.Generic;
using OMV.OfficeListing.Api.Controllers;
using Moq;
using MediatR;
using Xunit;
using System.Threading.Tasks;
using OMV.OfficeListing.Core.Entities;
using Microsoft.AspNetCore.Mvc;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Test.TestHelpers;

namespace OMV.OfficeListing.Test.Controllers
{
    public class RegionsControllerTests : IDisposable
    {
        private Fixture fixture;
        private RegionsController controller;
        private Mock<IMediator> mediatorMock;

    public RegionsControllerTests()
    {
        fixture = new Fixture();
        mediatorMock = new Mock<IMediator>();

        controller = new RegionsController(mediatorMock.Object);
    }

    public void Dispose()
    {
        controller = null;
        fixture = null;
        mediatorMock = null;
    }

    [Fact]
    public void ControllerCanCreate()
    {
        Assert.NotNull(controller);
    }

    [Fact]
    public async Task GetReturnsBadRequestOnMediatorExceptionForSpecificRegion()
    {
        var expected = fixture.Create<Region>();

        mediatorMock
            .Setup(m => m.Send(
                 It.Is<RegionInquiryRequest>(g => g.Id == expected.Id),
                default(System.Threading.CancellationToken)))
            .Throws<TestException>();

        var result = await controller.Get(expected.Id);
        var viewResult = Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public async Task GetReturnsNoContentWhenMediatorReturnsNullForSpecificRegion()
    {
        var expected = fixture.Create<Region>();
        mediatorMock
            .Setup(m => m.Send(
                 It.Is<RegionInquiryRequest>(g => g.Id == expected.Id),
                default(System.Threading.CancellationToken)))
            .ReturnsAsync((Region)null);
        var result =
           await controller.Get(expected.Id);
        var viewResult = Assert.IsType<NoContentResult>(result);
    }
    [Fact]
    public async Task GetReturnsExpectedResultForSpecificRegion()
    {
        var expected = fixture.Create<Region>();

        mediatorMock
            .Setup(m => m.Send(
                It.Is<RegionInquiryRequest>(g => g.Id == expected.Id),
                default(System.Threading.CancellationToken)))
            .ReturnsAsync(expected);

        var result =
            await controller.Get(expected.Id);

        var viewResult = Assert.IsType<OkObjectResult>(result);
        var model = Assert.IsAssignableFrom<Region>(viewResult.Value);
    }
    [Fact]
    public async Task GetReturnsBadRequestOnMediatorException()
    {
        mediatorMock
            .Setup(m => m.Send(
                It.IsAny<RegionsInquiryRequest>(),
                default(System.Threading.CancellationToken)))
            .Throws<TestException>();

        var result = await controller.Get();
        var viewResult = Assert.IsType<BadRequestResult>(result);
    }
    [Fact]
    public async Task GetReturnsNoContentWhenMediatorReturnsNull()
    {
        mediatorMock
            .Setup(m => m.Send(
                It.IsAny<RegionsInquiryRequest>(),
                default(System.Threading.CancellationToken)))
            .ReturnsAsync((IList<Region>)null);

        var result =
            await controller.Get();

        var viewResult = Assert.IsType<NoContentResult>(result);
    }
    [Fact]
    public async Task GetReturnsNoContentWhenMediatorReturnsEmpty()
    {
        var expected = new List<Region>();
        mediatorMock
            .Setup(m => m.Send(
                It.IsAny<RegionsInquiryRequest>(),
                default(System.Threading.CancellationToken)))
            .ReturnsAsync(expected);

        var result =
            await controller.Get();

        var viewResult = Assert.IsType<NoContentResult>(result);
    }
    [Fact]
    public async Task GetReturnsExpectedResult()
    {
        var expected =
            fixture.Create<IList<Region>>();

        mediatorMock
            .Setup(m => m.Send(
                It.IsAny<RegionsInquiryRequest>(),
                default(System.Threading.CancellationToken)))
            .ReturnsAsync(expected);

        var result =
            await controller.Get();

        var viewResult = Assert.IsType<OkObjectResult>(result);
        var model = Assert.IsAssignableFrom<IList<Region>>(viewResult.Value);
    }
}
}
