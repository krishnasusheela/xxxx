﻿using AutoFixture;
using System;
using System.Collections.Generic;
using OMV.OfficeListing.Api.Controllers;
using Moq;
using MediatR;
using Xunit;
using System.Threading.Tasks;
using OMV.OfficeListing.Core.Entities;
using Microsoft.AspNetCore.Mvc;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Test.TestHelpers;

namespace OMV.OfficeListing.Test.Controllers
{
    public class RolesControllerTests : IDisposable
    {
        private Fixture fixture;
        private RolesController controller;
        private Mock<IMediator> mediatorMock;

        public RolesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller = new RolesController(mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorExceptionForSpecificRole()
        {
            var expected = fixture.Create<Role>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<RoleInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get(expected.Id);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNullForSpecificRole()
        {
            var expected = fixture.Create<Role>();
            mediatorMock
                .Setup(m => m.Send(
                     It.Is<RoleInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Role)null);
            var result =
               await controller.Get(expected.Id);
            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResultForSpecificRole()
        {
            var expected = fixture.Create<Role>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<RoleInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Role>(viewResult.Value);
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorException()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<RolesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get();
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNull()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<RolesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((IList<Role>)null);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsEmpty()
        {
            var expected = new List<Role>();
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<RolesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResult()
        {
            var expected =
                fixture.Create<IList<Role>>(); 

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<RolesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IList<Role>>(viewResult.Value);
        }

        [Fact]
        public async Task CreateReturnsBadRequestOnMediatorException()
        {

            var expected = fixture
                .Build<RoleCreate>()
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<RoleCreateRequest>(g => g.Role == expected),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Create(expected);

            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task CreateReturnsBadRequestWithCustomMessageOnInvalidOperationException()
        {
            var expected = fixture
                .Build<RoleCreate>()
                .Create();

            var expectedErrorMessage = "Custom Error";

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<RoleCreateRequest>(g => g.Role == expected),
                    default(System.Threading.CancellationToken)))
                .Throws(new InvalidOperationException(expectedErrorMessage));

            var result = await controller.Create(expected);

            Assert.IsType<BadRequestObjectResult>(result);

            var badRequestObjectResult = result as BadRequestObjectResult;

            Assert.Equal(expectedErrorMessage, badRequestObjectResult?.Value);
        }

        [Fact]
        public async Task CreateReturnsNoContentWhenMediatorReturnsNull()
        {
            var expected = fixture
                .Build<RoleCreate>()
                .Create();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<RoleCreateRequest>(g => g.Role == expected),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Role)null);

            var result =
                await controller.Create(expected);

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task CreateReturnsExpectedResult()
        {
            var role = fixture
                .Create<Role>();

            var roleCapabilities = fixture
                .Create<IEnumerable<RoleCapabilityCreate>>();

            var expected = fixture
                .Build<RoleCreate>()
                .With(x => x.Description, role.Description)
                .With(x => x.EffectiveDate, role.EffectiveDate)
                .With(x => x.ExpireDate, role.ExpireDate)
                .With(x => x.IsPublic, role.IsPublic)
                .With(x => x.Name, role.Name)
                .With(x => x.ProgramFunctionId, role.ProgramFunction.Id)
                .With(x => x.PublicDescription, role.PublicDescription)
                .With(x => x.RoleCapabilities, roleCapabilities)
                .Create();

            
            mediatorMock
                .Setup(m => m.Send(
                    It.Is<RoleCreateRequest>(g => g.Role == expected),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(role);

            var result =
                await controller.Create(expected);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            Assert.IsAssignableFrom<Role>(viewResult.Value);
        }
    }
}
