﻿using AutoFixture;
using System;
using System.Collections.Generic;
using OMV.OfficeListing.Api.Controllers;
using Moq;
using MediatR;
using Xunit;
using System.Threading.Tasks;
using OMV.OfficeListing.Core.Entities;
using Microsoft.AspNetCore.Mvc;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Test.TestHelpers;

namespace OMV.OfficeListing.Test.Controllers
{
    public class OfficesControllerTests : IDisposable
    {
        private Fixture fixture;
        private OfficesController controller;
        private Mock<IMediator> mediatorMock;

        public OfficesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller = new OfficesController(mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public void ControllerCanCreate()
        {
            Assert.NotNull(controller);
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorExceptionForSpecificOffice()
        {
            var expected = fixture.Create<Office>();

            mediatorMock
                .Setup(m => m.Send(
                     It.Is<OfficeInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get(expected.Id);
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNullForSpecificOffice()
        {
            var expected = fixture.Create<Office>();
            mediatorMock
                .Setup(m => m.Send(
                     It.Is<OfficeInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((Office)null);
            var result =
               await controller.Get(expected.Id);
            var viewResult = Assert.IsType<NoContentResult>(result);
        }
        [Fact]
        public async Task GetReturnsExpectedResultForSpecificOffice()
        {
            var expected = fixture.Create<Office>();

            mediatorMock
                .Setup(m => m.Send(
                    It.Is<OfficeInquiryRequest>(g => g.Id == expected.Id),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get(expected.Id);

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Office>(viewResult.Value);
        }
        [Fact]
        public async Task GetReturnsBadRequestOnMediatorException()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<OfficesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get();
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }
        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNull()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<OfficesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((IList<Office>)null);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }
        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsEmpty()
        {
            var expected = new List<Office>();
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<OfficesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }
        [Fact]
        public async Task GetReturnsExpectedResult()
        {
            var expected =
                fixture.Create<IList<Office>>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<OfficesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IList<Office>>(viewResult.Value);
        }
    }
}
