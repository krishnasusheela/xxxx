﻿using AutoFixture;
using System;
using System.Collections.Generic;
using OMV.OfficeListing.Api.Controllers;
using Moq;
using MediatR;
using Xunit;
using System.Threading.Tasks;
using OMV.OfficeListing.Core.Entities;
using Microsoft.AspNetCore.Mvc;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Test.TestHelpers;

namespace OMV.OfficeListing.Test.Controllers
{
    public class PhoneNumberTypesControllerTests : IDisposable
    {
        private Fixture fixture;
        private PhoneNumberTypesController controller;
        private Mock<IMediator> mediatorMock;

        public PhoneNumberTypesControllerTests()
        {
            fixture = new Fixture();
            mediatorMock = new Mock<IMediator>();

            controller = new PhoneNumberTypesController(mediatorMock.Object);
        }

        public void Dispose()
        {
            controller = null;
            fixture = null;
            mediatorMock = null;
        }

        [Fact]
        public async Task GetReturnsBadRequestOnMediatorException()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<PhoneNumberTypesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .Throws<TestException>();

            var result = await controller.Get();
            var viewResult = Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsNull()
        {
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<PhoneNumberTypesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync((IEnumerable<PhoneNumberType>)null);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsNoContentWhenMediatorReturnsEmpty()
        {
            var expected = new List<PhoneNumberType>();
            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<PhoneNumberTypesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetReturnsExpectedResult()
        {
            var expected =
                fixture.Create<IEnumerable<PhoneNumberType>>();

            mediatorMock
                .Setup(m => m.Send(
                    It.IsAny<PhoneNumberTypesInquiryRequest>(),
                    default(System.Threading.CancellationToken)))
                .ReturnsAsync(expected);

            var result =
                await controller.Get();

            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<PhoneNumberType>>(viewResult.Value);
        }
    }
}
