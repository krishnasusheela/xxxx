﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using OMV.OfficeListing.Api.Handlers;
using OMV.OfficeListing.Api.Requests;
using Xunit;

namespace OMV.OfficeListing.Test.Handlers
{
    public class RolesInquiryRequestHandlerTests : IDisposable
    {
        private RolesInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IRoleDataService> mockRoleDataService;

        public RolesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockRoleDataService = new Mock<IRoleDataService>();

            handler = new RolesInquiryRequestHandler(
                mockRoleDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockRoleDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            mockRoleDataService
                .Setup(m => m.GetAllRoles())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new RolesInquiryRequest(),
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<IList<Role>>();

            mockRoleDataService
                .Setup(m => m.GetAllRoles())
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new RolesInquiryRequest(),
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
