﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Threading.Tasks;
using OMV.OfficeListing.Api.Handlers;
using OMV.OfficeListing.Api.Requests;
using Xunit;

namespace OMV.OfficeListing.Test.Handlers
{
    public class RegionInquiryRequestHandlerTests : IDisposable
    {
        private RegionInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IRegionDataService> mockRegionDataService;

        public RegionInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockRegionDataService = new Mock<IRegionDataService>();

            handler = new RegionInquiryRequestHandler(
                mockRegionDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockRegionDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var expected = fixture.Create<Region>();

            mockRegionDataService
                .Setup(m => m.GetRegionById(expected.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new RegionInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken)));
        }
        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Region>();

            mockRegionDataService
                .Setup(m => m.GetRegionById(expected.Id))
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new RegionInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
