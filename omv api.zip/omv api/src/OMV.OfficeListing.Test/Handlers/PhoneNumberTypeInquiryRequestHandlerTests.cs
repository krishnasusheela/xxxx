﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using OMV.OfficeListing.Api.Handlers;
using OMV.OfficeListing.Api.Requests;
using Xunit;

namespace OMV.OfficeListing.Test.Handlers
{
    public class PhoneNumberTypeInquiryRequestHandlerTests : IDisposable
    {
        private PhoneNumberTypesInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IPhoneNumberTypesDataService> mockPhoneNumberTypesDataService;

        public PhoneNumberTypeInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockPhoneNumberTypesDataService = new Mock<IPhoneNumberTypesDataService>();

            handler = new PhoneNumberTypesInquiryRequestHandler(
                 mockPhoneNumberTypesDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockPhoneNumberTypesDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            mockPhoneNumberTypesDataService
               .Setup(m => m.GetAllPhoneNumberTypes())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new PhoneNumberTypesInquiryRequest(),
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<IEnumerable<PhoneNumberType>>();

            mockPhoneNumberTypesDataService
               .Setup(m => m.GetAllPhoneNumberTypes())
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new PhoneNumberTypesInquiryRequest(),
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
