﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Threading.Tasks;
using OMV.OfficeListing.Api.Handlers;
using OMV.OfficeListing.Api.Requests;
using Xunit;

namespace OMV.OfficeListing.Test.Handlers
{
    public class OfficeInquiryRequestHandlerTests : IDisposable
    {
        private OfficeInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IOfficeDataService> mockOfficeDataService;

        public OfficeInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockOfficeDataService = new Mock<IOfficeDataService>();

            handler = new OfficeInquiryRequestHandler(
                mockOfficeDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockOfficeDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var expected = fixture.Create<Office>();

            mockOfficeDataService
                .Setup(m => m.GetOfficeById(expected.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new OfficeInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken)));
        }
        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Office>();

            mockOfficeDataService
                .Setup(m => m.GetOfficeById(expected.Id))
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new OfficeInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
