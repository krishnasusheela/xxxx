﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using OMV.OfficeListing.Api.Handlers;
using OMV.OfficeListing.Api.Requests;
using Xunit;

namespace OMV.OfficeListing.Test.Handlers
{
    public class OfficesInquiryRequestHandlerTests : IDisposable
    {
        private OfficesInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IOfficeDataService> mockOfficeDataService;

        public OfficesInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockOfficeDataService = new Mock<IOfficeDataService>();

            handler = new OfficesInquiryRequestHandler(
                mockOfficeDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockOfficeDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            mockOfficeDataService
                .Setup(m => m.GetAllOffices())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new OfficesInquiryRequest(),
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<IList<Office>>();

            mockOfficeDataService
                .Setup(m => m.GetAllOffices())
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new OfficesInquiryRequest(),
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
