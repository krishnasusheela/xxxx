﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Api.Handlers;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace OMV.OfficeListing.Test.Handlers
{
    public class ProgramFunctionsInquiryRequestHandlerTests
        : IDisposable
    {
        private Fixture fixture;
        private ProgramFunctionsInquiryRequestHandler handler;
        private Mock<IProgramFunctionsDataService> dataServiceMock;

        public ProgramFunctionsInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            dataServiceMock = new Mock<IProgramFunctionsDataService>();
            handler = new ProgramFunctionsInquiryRequestHandler(dataServiceMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            dataServiceMock = null;
            handler = null;
        }

        [Fact]
        public void HandlerCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            dataServiceMock
               .Setup(m => m.GetAllProgramFunctions())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new ProgramFunctionsInquiryRequest(),
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<IEnumerable<ProgramFunction>>();

            dataServiceMock
               .Setup(m => m.GetAllProgramFunctions())
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new ProgramFunctionsInquiryRequest(),
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
