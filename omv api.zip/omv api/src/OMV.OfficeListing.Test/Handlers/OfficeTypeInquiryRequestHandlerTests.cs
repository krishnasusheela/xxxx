﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using OMV.OfficeListing.Api.Handlers;
using OMV.OfficeListing.Api.Requests;
using Xunit;

namespace OMV.OfficeListing.Test.Handlers
{
    public class OfficeTypeInquiryRequestHandlerTests : IDisposable
    {
        private OfficeTypesInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IOfficeTypesDataService> mockOfficeTypesDataService;

        public OfficeTypeInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockOfficeTypesDataService = new Mock<IOfficeTypesDataService>();

            handler = new OfficeTypesInquiryRequestHandler(
                 mockOfficeTypesDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockOfficeTypesDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            mockOfficeTypesDataService
               .Setup(m => m.GetAllOfficeTypes())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new OfficeTypesInquiryRequest(),
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<IEnumerable<OfficeType>>();

            mockOfficeTypesDataService
               .Setup(m => m.GetAllOfficeTypes())
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new OfficeTypesInquiryRequest(),
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
