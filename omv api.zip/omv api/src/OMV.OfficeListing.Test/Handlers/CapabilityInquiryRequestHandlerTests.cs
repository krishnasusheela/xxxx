﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Threading.Tasks;
using OMV.OfficeListing.Api.Handlers;
using OMV.OfficeListing.Api.Requests;
using Xunit;

namespace OMV.OfficeListing.Test.Handlers
{
    public class CapabilityInquiryRequestHandlerTests : IDisposable
    {
        private CapabilityInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<ICapabilityDataService> mockCapabilityDataService;

        public CapabilityInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockCapabilityDataService = new Mock<ICapabilityDataService>();

            handler = new CapabilityInquiryRequestHandler(
                mockCapabilityDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockCapabilityDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var expected = fixture.Create<Capability>();

            mockCapabilityDataService
                .Setup(m => m.GetCapabilityById(expected.Id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new CapabilityInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken)));
        }
        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<Capability>();

            mockCapabilityDataService
                .Setup(m => m.GetCapabilityById(expected.Id))
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new CapabilityInquiryRequest() { Id = expected.Id },
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
