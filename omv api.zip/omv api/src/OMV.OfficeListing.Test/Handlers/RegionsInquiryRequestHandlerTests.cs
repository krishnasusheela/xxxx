﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using OMV.OfficeListing.Api.Handlers;
using OMV.OfficeListing.Api.Requests;
using Xunit;

namespace OMV.OfficeListing.Test.Handlers
{
    public class RegionsInquiryRequestHandlerTests : IDisposable
    {
        private RegionsInquiryRequestHandler handler;
        private Fixture fixture;
        private Mock<IRegionDataService> mockRegionDataService;

        public RegionsInquiryRequestHandlerTests()
        {
            fixture = new Fixture();
            mockRegionDataService = new Mock<IRegionDataService>();

            handler = new RegionsInquiryRequestHandler(
                mockRegionDataService.Object);
        }

        public void Dispose()
        {
            fixture = null;
            handler = null;
            mockRegionDataService = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            mockRegionDataService
                .Setup(m => m.GetAllRegions())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    new RegionsInquiryRequest(),
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var expected = fixture.Create<IList<Region>>();

            mockRegionDataService
                .Setup(m => m.GetAllRegions())
                .ReturnsAsync(expected);

            var result = await handler
                .Handle(
                    new RegionsInquiryRequest(),
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                result);
        }
    }
}
