﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Api.Handlers;
using OMV.OfficeListing.Api.Requests;
using OMV.OfficeListing.Core.Entities;
using OMV.OfficeListing.Core.Interfaces;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Threading.Tasks;
using Xunit;

namespace OMV.OfficeListing.Test.Handlers
{
    public class RoleCreateRequestHandlerTests
        : IDisposable
    {
        private RoleCreateRequestHandler handler;
        private Mock<IRoleDataService> dataServiceMock;
        private Fixture fixture;

        public RoleCreateRequestHandlerTests()
        {
            fixture = new Fixture();

            dataServiceMock =
                new Mock<IRoleDataService>();

            handler = new RoleCreateRequestHandler(
                dataServiceMock.Object);
        }

        public void Dispose()
        {
            dataServiceMock = null;
            handler = null;
            fixture = null;
        }

        [Fact]
        public void ConstructorCreatesSuccessfully()
        {
            Assert.NotNull(handler);
        }

        [Fact]
        public async Task HandlerThrowsExceptionWhenDataServiceThrowsException()
        {
            var request = fixture.Create<RoleCreateRequest>();

            dataServiceMock
                .Setup(m => m.CreateRole(request.Role))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                handler.Handle(
                    request,
                    default(System.Threading.CancellationToken)));
        }

        [Fact]
        public async Task HandlerReturnsExpected()
        {
            var request = fixture.Create<RoleCreateRequest>();

            var expected = fixture.Create<Role>();

            dataServiceMock
                .Setup(m => m.CreateRole(request.Role))
                .ReturnsAsync(expected);

            var actual =
                await handler.Handle(
                    request,
                    default(System.Threading.CancellationToken));

            Assert.Equal(
                expected,
                actual);
        }
    }
}
