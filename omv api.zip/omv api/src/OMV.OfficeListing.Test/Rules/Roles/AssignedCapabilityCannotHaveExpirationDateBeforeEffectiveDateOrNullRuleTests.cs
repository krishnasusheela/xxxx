﻿using AutoFixture;
using OMV.OfficeListing.Infrastructure.Models;
using OMV.OfficeListing.Infrastructure.Rules.Roles;
using System;
using System.Collections.Generic;
using Xunit;

namespace OMV.OfficeListing.Test.Rules.Roles
{
    public class AssignedCapabilityCannotHaveExpirationDateBeforeEffectiveDateOrNullRuleTests
        : IDisposable
    {
        private Fixture fixture;
        private AssignedCapabilityCannotHaveExpirationDateBeforeEffectiveDateOrNullRule rule;

        private const string ExpectedExceptionMessage =
            "The expiration date cannot be prior to the effective date.";

        public AssignedCapabilityCannotHaveExpirationDateBeforeEffectiveDateOrNullRuleTests()
        {
            fixture = new Fixture();
            rule = new AssignedCapabilityCannotHaveExpirationDateBeforeEffectiveDateOrNullRule();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenExpirationDateIsAfterEffectiveDate()
        {
            var roleCapabilityToCreate = fixture
                .Build<RoleCapabilityDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(1))
                .With(p => p.ExpireDate, DateTimeOffset.Now.AddDays(2))
                .Without(p => p.Capability)
                .Without(p => p.Role)
                .Create();

            var roleCapabilityList = new List<RoleCapabilityDto> { roleCapabilityToCreate };

            var roleToCreate = fixture
                .Build<RoleDto>()
                .With(p => p.RoleCapabilities, roleCapabilityList)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    roleToCreate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenExpirationDateIsBeforeEffectiveDate()
        {
            var roleCapabilityToCreate = fixture
                .Build<RoleCapabilityDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(2))
                .With(p => p.ExpireDate, DateTimeOffset.Now.AddDays(1))
                .Without(p => p.Capability)
                .Without(p => p.Role)
                .Create();

            var roleCapabilityList = new List<RoleCapabilityDto> { roleCapabilityToCreate };

            var roleToCreate = fixture
                .Build<RoleDto>()
                .With(p => p.RoleCapabilities, roleCapabilityList)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    roleToCreate));

            Assert.NotNull(
                exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenExpirationDateIsSameAsEffectiveDate()
        {
            var currentDate = DateTimeOffset.Now.AddDays(1);

            var roleCapabilityToCreate = fixture
                .Build<RoleCapabilityDto>()
                .With(p => p.EffectiveDate, currentDate)
                .With(p => p.ExpireDate, currentDate)
                .Without(p => p.Capability)
                .Without(p => p.Role)
                .Create();

            var roleCapabilityList = new List<RoleCapabilityDto> { roleCapabilityToCreate };

            var roleToCreate = fixture
                .Build<RoleDto>()
                .With(p => p.RoleCapabilities, roleCapabilityList)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    roleToCreate));

            Assert.NotNull(
                exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
