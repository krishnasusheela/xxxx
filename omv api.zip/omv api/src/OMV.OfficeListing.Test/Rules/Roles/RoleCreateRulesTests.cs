﻿using AutoFixture;
using Moq;
using OMV.OfficeListing.Infrastructure.Interfaces.Rules;
using OMV.OfficeListing.Infrastructure.Models;
using OMV.OfficeListing.Infrastructure.Rules.Roles;
using OMV.OfficeListing.Test.TestHelpers;
using System;
using System.Collections.Generic;
using Xunit;

namespace OMV.OfficeListing.Test.Rules.Roles
{
    public class RoleCreateRulesTests
        : IDisposable
    {
        private Fixture fixture;
        private Mock<ICreateRoleRule> rule1;
        private Mock<ICreateRoleRule> rule2;
        private RoleCreateRules rules;

        public RoleCreateRulesTests()
        {
            fixture = new Fixture();

            rule1 = new Mock<ICreateRoleRule>();
            rule2 = new Mock<ICreateRoleRule>();

            rules = new RoleCreateRules(
                new List<ICreateRoleRule>
                {
                    rule1.Object,
                    rule2.Object
                });
        }

        public void Dispose()
        {
            fixture = null;
            rule1 = null;
            rule2 = null;
            rules = null;
        }

        [Fact]
        public void RulesCreateSuccessfully()
        {
            Assert.NotNull(
                rules);
        }

        [Fact]
        public void RulesThrowsExceptionWhenARuleThrowsAnException()
        {
            var role = fixture
                .Build<RoleDto>()
                .Without(x => x.RoleCapabilities)
                .Create();

            rule2
                .Setup(m => m.Test(
                    role))
                .Throws<TestException>();

            Assert.Throws<TestException>(() =>
                rules.Test(
                    role));
        }

        [Fact]
        public void RulesCallsAllSubRules()
        {
            var role = fixture
               .Build<RoleDto>()
               .Without(x => x.RoleCapabilities)
               .Create();

            rule1
                .Setup(m => m.Test(
                    role))
                .Verifiable();

            rule2
                .Setup(m => m.Test(
                    role))
                .Verifiable();

            rules.Test(
                role);

            rule1
                .Verify(m => m.Test(
                    role));

            rule2
                .Verify(m => m.Test(
                    role));
        }
    }
}
