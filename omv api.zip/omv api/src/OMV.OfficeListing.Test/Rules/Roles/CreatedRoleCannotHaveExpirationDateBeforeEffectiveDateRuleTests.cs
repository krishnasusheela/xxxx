﻿using AutoFixture;
using OMV.OfficeListing.Infrastructure.Models;
using OMV.OfficeListing.Infrastructure.Rules.Roles;
using System;
using Xunit;

namespace OMV.OfficeListing.Test.Rules.Roles
{
    public class CreatedRoleCannotHaveExpirationDateBeforeEffectiveDateRuleTests
        : IDisposable
    {
        private Fixture fixture;
        private CreatedRoleCannotHaveExpirationDateBeforeEffectiveDateRule rule;

        private const string ExpectedExceptionMessage =
            "The expiration date cannot be prior to the effective date.";

        public CreatedRoleCannotHaveExpirationDateBeforeEffectiveDateRuleTests()
        {
            fixture = new Fixture();
            rule = new CreatedRoleCannotHaveExpirationDateBeforeEffectiveDateRule();
        }

        public void Dispose()
        {
            fixture = null;
            rule = null;
        }

        [Fact]
        public void RuleCreatesSuccessfully()
        {
            Assert.NotNull(
                rule);
        }

        [Fact]
        public void RuleDoesNotThrowExceptionWhenExpirationDateIsAfterEffectiveDate()
        {
            var roleToCreate = fixture
                .Build<RoleDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(1))
                .With(p => p.ExpireDate, DateTimeOffset.Now.AddDays(2))
                .Without(p => p.RoleCapabilities)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    roleToCreate));

            Assert.Null(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenExpirationDateIsBeforeEffectiveDate()
        {
            var roleToCreate = fixture
                .Build<RoleDto>()
                .With(p => p.EffectiveDate, DateTimeOffset.Now.AddDays(2))
                .With(p => p.ExpireDate, DateTimeOffset.Now.AddDays(1))
                .Without(p => p.RoleCapabilities)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    roleToCreate));

            Assert.NotNull(
                exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }

        [Fact]
        public void RuleThrowsExceptionWhenExpirationDateIsSameAsEffectiveDate()
        {
            var currentDate = DateTimeOffset.Now.AddDays(1);

            var roleToCreate = fixture
                .Build<RoleDto>()
                .With(p => p.EffectiveDate, currentDate)
                .With(p => p.ExpireDate, currentDate)
                .Without(p => p.RoleCapabilities)
                .Create();

            var exception = Record.Exception(() =>
                rule.Test(
                    roleToCreate));

            Assert.NotNull(
                exception);
            Assert.Equal(
                ExpectedExceptionMessage,
                exception.Message);
            Assert.IsType<InvalidOperationException>(
                exception);
        }
    }
}
