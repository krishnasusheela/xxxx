﻿using System;
using AutoMapper;
using AutoFixture;
using Xunit;
using OMV.OfficeListing.Infrastructure.Services;
using OMV.OfficeListing.Infrastructure.Models;
using Moq;
using OMV.OfficeListing.Test.TestHelpers;
using System.Threading.Tasks;
using System.Collections.Generic;
using OMV.OfficeListing.Core.Entities;
using System.Linq;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;

namespace OMV.OfficeListing.Test.Services
{
    public class PhoneNumberTypesDataServiceTests : IDisposable
    {
        private Fixture fixture;
        private Mock<IPhoneNumberTypeRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private PhoneNumberTypesDataService service;

        public PhoneNumberTypesDataServiceTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IPhoneNumberTypeRepository>();
            mapperMock = new Mock<IMapper>();

            service = new PhoneNumberTypesDataService(
                repositoryMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;
            service = null;

        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllPhoneNumberTypesThrowsExceptionWhenContextThrowsException()
        {
            var type = new List<PhoneNumberType>();
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllPhoneNumberTypes());
        }

        [Fact]
        public async Task GetAllPhoneNumberTypesThrowsExceptionWhenMapperThrowsException()
        {
            var types = fixture
                .Build<PhoneNumberTypeDto>()
                .Without(p => p.PhoneNumbers)
                .CreateMany();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(types);

            mapperMock
                .Setup(m => m.Map<IEnumerable<PhoneNumberType>>(types))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllPhoneNumberTypes());
        }

        [Fact]
        public async Task GetAllPhoneNumberTypesReturnsExpected()
        {
            var expected = fixture
                .CreateMany<PhoneNumberType>()
                .ToList();

            var types = fixture
                .Build<PhoneNumberTypeDto>()
                .Without(p => p.PhoneNumbers)
                .CreateMany();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(types);

            mapperMock
                .Setup(m => m.Map<IEnumerable<PhoneNumberType>>(types))
                .Returns(expected);

            var actual = await service
                .GetAllPhoneNumberTypes();

            Assert.Equal(
                expected,
                actual);
        }
    }
}
