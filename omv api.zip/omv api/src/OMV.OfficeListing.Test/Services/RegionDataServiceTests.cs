﻿using System;
using AutoFixture;
using Xunit;
using OMV.OfficeListing.Infrastructure.Services;
using OMV.OfficeListing.Infrastructure.Models;
using AutoMapper;
using System.Linq;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using Moq;
using System.Threading.Tasks;
using OMV.OfficeListing.Test.TestHelpers;
using OMV.OfficeListing.Core.Entities;
using System.Collections.Generic;

namespace OMV.OfficeListing.Test.Services
{
    public class RegionDataServiceTests : IDisposable
    {
        private Fixture fixture;
        private Mock<IRegionRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private RegionDataService service;

        public RegionDataServiceTests()
        {
            fixture = new Fixture();

            repositoryMock = new Mock<IRegionRepository>();
            mapperMock = new Mock<IMapper>();

            service = new RegionDataService(
                repositoryMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;

            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllRegionsThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllRegions());
        }

        [Fact]
        public async Task GetAllRegionsThrowsExceptionWhenMapperThrowsException()
        {
            var regionDtos = fixture
                .Build<RegionDto>()            
                .CreateMany()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(regionDtos);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Region>>(regionDtos))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllRegions());
        }

        [Fact]
        public async Task GetAllRegionsReturnsExpected()
        {
            var regionDtos = fixture
                .Build<RegionDto>()
                .CreateMany()
                .ToList();

            var expected = fixture
                .CreateMany<Region>()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(regionDtos);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Region>>(regionDtos))
                .Returns(expected);

            var actual = await service.GetAllRegions();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetRegionByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var id = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetRegionById(id));
        }

        [Fact]
        public async Task GetRegionByIdThrowsExceptionWhenMapperThrowsException()
        {
            var id = fixture.Create<int>();

            var regionDto = fixture
                .Build<RegionDto>()
                .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(regionDto);

            mapperMock
                .Setup(m => m.Map<Region>(regionDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetRegionById(id));
        }

        [Fact]
        public async Task GetRegionByIdReturnsExpected()
        {
            var id = fixture.Create<int>();

            var regionDto = fixture
                .Build<RegionDto>()
                .Create();

            var expected = fixture.Create<Region>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(regionDto);

            mapperMock
                .Setup(m => m.Map<Region>(regionDto))
                .Returns(expected);

            var actual = await service.GetRegionById(id);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
