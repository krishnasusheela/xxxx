﻿using System;
using AutoMapper;
using AutoFixture;
using Xunit;
using OMV.OfficeListing.Infrastructure.Services;
using OMV.OfficeListing.Infrastructure.Models;
using Moq;
using OMV.OfficeListing.Test.TestHelpers;
using System.Threading.Tasks;
using System.Collections.Generic;
using OMV.OfficeListing.Core.Entities;
using System.Linq;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;

namespace OMV.OfficeListing.Test.Services
{
    public class ProgramFunctionsDataServiceTests : IDisposable
    {
        private Fixture fixture;
        private Mock<IProgramFunctionRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private ProgramFunctionsDataService service;

        public ProgramFunctionsDataServiceTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IProgramFunctionRepository>();
            mapperMock = new Mock<IMapper>();

            service = new ProgramFunctionsDataService(
                repositoryMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;
            service = null;

        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllProgramFunctionsThrowsExceptionWhenContextThrowsException()
        {
            var type = new List<ProgramFunction>();
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllProgramFunctions());
        }

        [Fact]
        public async Task GetAllProgramFunctionsThrowsExceptionWhenMapperThrowsException()
        {
            var types = fixture
                .Build<ProgramFunctionDto>()
                .CreateMany();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(types);

            mapperMock
                .Setup(m => m.Map<IEnumerable<ProgramFunction>>(types))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllProgramFunctions());
        }

        [Fact]
        public async Task GetAllProgramFunctionsReturnsExpected()
        {
            var expected = fixture
                .CreateMany<ProgramFunction>()
                .ToList();

            var types = fixture
                .Build<ProgramFunctionDto>()
                .CreateMany();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(types);

            mapperMock
                .Setup(m => m.Map<IEnumerable<ProgramFunction>>(types))
                .Returns(expected);

            var actual = await service
                .GetAllProgramFunctions();

            Assert.Equal(
                expected,
                actual);
        }
    }
}
