﻿using System;
using OMV.OfficeListing.Core.Interfaces;
using AutoFixture;
using Xunit;
using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Services;
using OMV.OfficeListing.Infrastructure.Models;
using AutoMapper;
using System.Linq;
using OMV.OfficeListing.Core.Entities;
using Moq;
using OMV.OfficeListing.Infrastructure.Interfaces.Rules;
using OMV.OfficeListing.Infrastructure.Mappings;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using System.Threading.Tasks;
using OMV.OfficeListing.Test.TestHelpers;
using System.Collections.Generic;

namespace OMV.OfficeListing.Test.Services
{
    public class RoleDataServiceTests : IDisposable
    {
        private Fixture fixture;
        private Mock<IRoleRepository> repositoryMock;
        private Mock<IRoleCreateRules> createRulesMock;
        private Mock<IMapper> mapperMock;
        private RoleDataService service;

        public RoleDataServiceTests()
        {
            fixture = new Fixture();

            repositoryMock = new Mock<IRoleRepository>();
            createRulesMock = new Mock<IRoleCreateRules>();
            mapperMock = new Mock<IMapper>();

            service = new RoleDataService(
                 repositoryMock.Object,
                 mapperMock.Object,
                 createRulesMock.Object
                 );
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            createRulesMock = null;
            mapperMock = null;

            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllRolesThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllRoles());
        }

        [Fact]
        public async Task GetAllRolesThrowsExceptionWhenMapperThrowsException()
        {
            var roleDtos = fixture
                .Build<RoleDto>()
                .Without(p => p.RoleCapabilities)
                .CreateMany()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(roleDtos);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Role>>(roleDtos))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllRoles());
        }

        [Fact]
        public async Task GetAllRolesReturnsExpected()
        {
            var roleDtos = fixture
                .Build<RoleDto>()
                .Without(p => p.RoleCapabilities)
                .CreateMany()
                .ToList();

            var expected = fixture
                .CreateMany<Role>()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(roleDtos);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Role>>(roleDtos))
                .Returns(expected);

            var actual = await service.GetAllRoles();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetRoleByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var id = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetRoleById(id));
        }

        [Fact]
        public async Task GetRoleByIdThrowsExceptionWhenMapperThrowsException()
        {
            var id = fixture.Create<int>();

            var roleDto = fixture
                .Build<RoleDto>()
                .Without(p => p.RoleCapabilities)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(roleDto);

            mapperMock
                .Setup(m => m.Map<Role>(roleDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetRoleById(id));
        }

        [Fact]
        public async Task GetRoleByIdReturnsExpected()
        {
            var id = fixture.Create<int>();

            var roleDto = fixture
                .Build<RoleDto>()
                .Without(p => p.RoleCapabilities)
                .Create();

            var expected = fixture.Create<Role>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(roleDto);

            mapperMock
                .Setup(m => m.Map<Role>(roleDto))
                .Returns(expected);

            var actual = await service.GetRoleById(id);

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task CreateRoleThrowsExceptionWhenDtoMapperThrowsException()
        {
            var role = fixture.Create<RoleCreate>();

            mapperMock
                .Setup(m => m.Map<RoleDto>(role))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateRole(role));
        }

        [Fact]
        public async Task CreateRoleThrowsExceptionWhenCreateRulesThrowsException()
        {
            var role = fixture.Create<RoleCreate>();

            var roleDto = fixture
                .Build<RoleDto>()
                .Without(p => p.RoleCapabilities)
                .Create();

            mapperMock
                .Setup(m => m.Map<RoleDto>(role))
                .Returns(roleDto);

            createRulesMock
                .Setup(m => m.Test(roleDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateRole(role));
        }

        [Fact]
        public async Task CreateRoleThrowsExceptionWhenRepositoryThrowsException()
        {
            var role = fixture.Create<RoleCreate>();

            var roleDto = fixture
                .Build<RoleDto>()
                .Without(p => p.RoleCapabilities)
                .Create();

            mapperMock
                .Setup(m => m.Map<RoleDto>(role))
                .Returns(roleDto);

            createRulesMock
                .Setup(m => m.Test(roleDto));

            repositoryMock
                .Setup(m => m.Create(roleDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateRole(role));
        }

        [Fact]
        public async Task CreateRoleThrowsExceptionWhenDomicileMapperThrowsException()
        {
            var role = fixture.Create<RoleCreate>();

            var roleDto = fixture
                .Build<RoleDto>()
                .Without(p => p.RoleCapabilities)
                .Create();

            var createdRoleDto = fixture
                .Build<RoleDto>()
                .Without(p => p.RoleCapabilities)
                .Create();

            mapperMock
                .Setup(m => m.Map<RoleDto>(role))
                .Returns(roleDto);

            createRulesMock
                .Setup(m => m.Test(roleDto));

            repositoryMock
                .Setup(m => m.Create(roleDto))
                .ReturnsAsync(createdRoleDto);

            mapperMock
                .Setup(m => m.Map<Role>(createdRoleDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.CreateRole(role));
        }

        [Fact]
        public async Task CreateRoleReturnsExpected()
        {
            var role = fixture.Create<RoleCreate>();

            var roleDto = fixture
                .Build<RoleDto>()
                .Without(p => p.RoleCapabilities)
                .Create();

            var createdRoleDto = fixture
               .Build<RoleDto>()
               .Without(p => p.RoleCapabilities)
               .Create();

            var expected = fixture.Create<Role>();

            mapperMock
                .Setup(m => m.Map<RoleDto>(role))
                .Returns(roleDto);

            createRulesMock
                .Setup(m => m.Test(roleDto));

            repositoryMock
                .Setup(m => m.Create(roleDto))
                .ReturnsAsync(createdRoleDto);

            mapperMock
                .Setup(m => m.Map<Role>(createdRoleDto))
                .Returns(expected);

            var actual = await service
                .CreateRole(
                    role);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
