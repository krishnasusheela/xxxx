﻿using System;
using OMV.OfficeListing.Core.Interfaces;
using AutoFixture;
using Xunit;
using OMV.OfficeListing.Infrastructure.Services;
using OMV.OfficeListing.Infrastructure.Models;
using AutoMapper;
using System.Linq;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using Moq;
using System.Threading.Tasks;
using OMV.OfficeListing.Test.TestHelpers;
using OMV.OfficeListing.Core.Entities;
using System.Collections.Generic;

namespace OMV.OfficeListing.Test.Services
{
    public class CapabilityDataServiceTests : IDisposable
    {
        private Fixture fixture;
        private Mock<ICapabilityRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private CapabilityDataService service;

        public CapabilityDataServiceTests()
        {
            fixture = new Fixture();

            repositoryMock = new Mock<ICapabilityRepository>();
            mapperMock = new Mock<IMapper>();

            service = new CapabilityDataService(
                repositoryMock.Object,                
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;

            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllCapabilitiesThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllCapabilities());
        }

        [Fact]
        public async Task GetAllCapabilitiesThrowsExceptionWhenMapperThrowsException()
        {
            var capabilityDtos = fixture
                .Build<CapabilityDto>()
                .Without(p => p.RoleCapabilities)
                .Without(p => p.CapabilityOfficeTypes)
                .CreateMany()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(capabilityDtos);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Capability>>(capabilityDtos))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllCapabilities());
        }

        [Fact]
        public async Task GetAllCapabilitiesReturnsExpected()
        {
            var capabilityDtos = fixture
                .Build<CapabilityDto>()
                .Without(p => p.RoleCapabilities)
                .Without(p => p.CapabilityOfficeTypes)
                .CreateMany()
                .ToList();

            var expected = fixture
                .CreateMany<Capability>()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(capabilityDtos);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Capability>>(capabilityDtos))
                .Returns(expected);

            var actual = await service.GetAllCapabilities();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetCapabilityByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var id = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetCapabilityById(id));
        }

        [Fact]
        public async Task GetCapabilityByIdThrowsExceptionWhenMapperThrowsException()
        {
            var id = fixture.Create<int>();

            var capabilityDto = fixture
                .Build<CapabilityDto>()
                .Without(p => p.RoleCapabilities)
                .Without(p => p.CapabilityOfficeTypes)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(capabilityDto);

            mapperMock
                .Setup(m => m.Map<Capability>(capabilityDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetCapabilityById(id));
        }

        [Fact]
        public async Task GetCapabilityByIdReturnsExpected()
        {
            var id = fixture.Create<int>();

            var capabilityDto = fixture
                .Build<CapabilityDto>()
                .Without(x => x.RoleCapabilities)
                .Without(x => x.CapabilityOfficeTypes)
                .Create();

            var expected = fixture.Create<Capability>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(capabilityDto);

            mapperMock
                .Setup(m => m.Map<Capability>(capabilityDto))
                .Returns(expected);

            var actual = await service.GetCapabilityById(id);

            Assert.Equal(
                expected,
                actual);
        }
    }
}
