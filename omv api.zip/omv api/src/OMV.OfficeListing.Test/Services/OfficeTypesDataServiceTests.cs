﻿using System;
using AutoMapper;
using AutoFixture;
using Xunit;
using OMV.OfficeListing.Infrastructure.Services;
using OMV.OfficeListing.Infrastructure.Models;
using Moq;
using OMV.OfficeListing.Test.TestHelpers;
using System.Threading.Tasks;
using System.Collections.Generic;
using OMV.OfficeListing.Core.Entities;
using System.Linq;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;

namespace OMV.OfficeListing.Test.Services
{
    public class OfficeTypesDataServiceTests : IDisposable
    {
        private Fixture fixture;
        private Mock<IOfficeTypeRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private OfficeTypesDataService service;

        public OfficeTypesDataServiceTests()
        {
            fixture = new Fixture();
            repositoryMock = new Mock<IOfficeTypeRepository>();
            mapperMock = new Mock<IMapper>();

            service = new OfficeTypesDataService(
                repositoryMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;
            service = null;

        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllOfficeTypesThrowsExceptionWhenContextThrowsException()
        {
            var type = new List<OfficeType>();
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllOfficeTypes());
        }

        [Fact]
        public async Task GetAllOfficeTypesThrowsExceptionWhenMapperThrowsException()
        {
            var types = fixture
                .Build<OfficeTypeDto>()
                .CreateMany();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(types);

            mapperMock
                .Setup(m => m.Map<IEnumerable<OfficeType>>(types))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllOfficeTypes());
        }

        [Fact]
        public async Task GetAllOfficeTypesReturnsExpected()
        {
            var expected = fixture
                .CreateMany<OfficeType>()
                .ToList();

            var types = fixture
                .Build<OfficeTypeDto>()
                .CreateMany();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(types);

            mapperMock
                .Setup(m => m.Map<IEnumerable<OfficeType>>(types))
                .Returns(expected);

            var actual = await service
                .GetAllOfficeTypes();

            Assert.Equal(
                expected,
                actual);
        }
    }
}
