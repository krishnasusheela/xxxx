﻿using System;
using AutoMapper;
using OMV.OfficeListing.Core.Interfaces;
using AutoFixture;
using Xunit;
using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Services;
using OMV.OfficeListing.Infrastructure.Models;
using OMV.OfficeListing.Infrastructure.Mappings;
using Moq;
using OMV.OfficeListing.Infrastructure.Interfaces.Repositories;
using OMV.OfficeListing.Test.TestHelpers;
using System.Threading.Tasks;
using System.Linq;
using OMV.OfficeListing.Core.Entities;
using System.Collections.Generic;

namespace OMV.OfficeListing.Test.Services
{
    public class OfficeDataServiceTests: IDisposable
    {
        private Fixture fixture;
        private Mock<IOfficeRepository> repositoryMock;
        private Mock<IMapper> mapperMock;
        private IOfficeDataService service;

        public OfficeDataServiceTests()
        {
            fixture = new Fixture();

            repositoryMock = new Mock<IOfficeRepository>();
            mapperMock = new Mock<IMapper>();

            service = new OfficeDataService(
                repositoryMock.Object,
                mapperMock.Object);
        }

        public void Dispose()
        {
            fixture = null;
            repositoryMock = null;
            mapperMock = null;

            service = null;
        }

        [Fact]
        public void ServiceCreatesSuccessfully()
        {
            Assert.NotNull(
                service);
        }

        [Fact]
        public async Task GetAllOfficesThrowsExceptionWhenRepositoryThrowsException()
        {
            repositoryMock
                .Setup(m => m.Get())
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllOffices());
        }

        [Fact]
        public async Task GetAllOfficesThrowsExceptionWhenMapperThrowsException()
        {
            var officeDtos = fixture
                .Build<OfficeDto>()
                .Without(p => p.Region)
                .Without(p => p.Parish)
                .Without(p => p.OfficeType)
                .Without(p => p.PhoneNumbers)
                .CreateMany()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(officeDtos);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Office>>(officeDtos))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetAllOffices());
        }

        [Fact]
        public async Task GetAllOfficesReturnsExpected()
        {
            var officeDtos = fixture
                .Build<OfficeDto>()
                .Without(p => p.Region)
                .Without(p => p.Parish)
                .Without(p => p.OfficeType)
                .Without(p => p.PhoneNumbers)
                .CreateMany()
                .ToList();

            var expected = fixture
                .CreateMany<Office>()
                .ToList();

            repositoryMock
                .Setup(m => m.Get())
                .ReturnsAsync(officeDtos);

            mapperMock
                .Setup(m => m.Map<IEnumerable<Office>>(officeDtos))
                .Returns(expected);

            var actual = await service.GetAllOffices();

            Assert.Equal(
                expected,
                actual);
        }

        [Fact]
        public async Task GetOfficeByIdThrowsExceptionWhenRepositoryThrowsException()
        {
            var id = fixture.Create<int>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetOfficeById(id));
        }

        [Fact]
        public async Task GetOfficeByIdThrowsExceptionWhenMapperThrowsException()
        {
            var id = fixture.Create<int>();

            var officeDto = fixture
                .Build<OfficeDto>()
                .Without(p => p.Region)
                .Without(p => p.Parish)
                .Without(p => p.OfficeType)
                .Without(p => p.PhoneNumbers)
                .Create();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(officeDto);

            mapperMock
                .Setup(m => m.Map<Office>(officeDto))
                .Throws<TestException>();

            await Assert.ThrowsAsync<TestException>(() =>
                service.GetOfficeById(id));
        }

        [Fact]
        public async Task GetOfficeByIdReturnsExpected()
        {
            var id = fixture.Create<int>();

            var officeDto = fixture
                .Build<OfficeDto>()
                .Without(p => p.Region)
                .Without(p => p.Parish)
                .Without(p => p.OfficeType)
                .Without(p => p.PhoneNumbers)
                .Create();

            var expected = fixture.Create<Office>();

            repositoryMock
                .Setup(m => m.GetById(id))
                .ReturnsAsync(officeDto);

            mapperMock
                .Setup(m => m.Map<Office>(officeDto))
                .Returns(expected);

            var actual = await service.GetOfficeById(id);

            Assert.Equal(
                expected,
                actual);
        }       
    }
}
