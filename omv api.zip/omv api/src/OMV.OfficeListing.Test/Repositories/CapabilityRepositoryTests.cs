﻿using OMV.OfficeListing.Infrastructure.Repositories;
using OMV.OfficeListing.Test.TestHelpers;
using System.Threading.Tasks;
using Xunit;

namespace OMV.OfficeListing.Test.Repositories
{
    public class CapabilityRepositoryTests : OfficeListingContextTestBase
    {
        private CapabilityRepository repository;

        public CapabilityRepositoryTests()
        {
            repository = new CapabilityRepository(
                TableContext);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository = null;
            }
        }

        [Fact]
        public void RepositoryCreatesSuccessfully()
        {
            Assert.NotNull(
                repository);
        }

        [Fact]
        public async Task GetReturnsExpected()
        {
            Seed(TableContext);

            var actual = await repository.Get();

            Assert.NotEmpty(
                actual);
        }

        [Fact]
        public async Task GetByIdReturnsExpected()
        {
            var expected = 10;

            Seed(TableContext);

            var capability = CreateCapabilityWithRelatedData(
                expected);

            TableContext.Capabilities.Add(capability);
            TableContext.SaveChanges();

            var actual = await repository
                .GetById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }
    }
}
