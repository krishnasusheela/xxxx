﻿using AutoFixture;
using OMV.OfficeListing.Infrastructure.Models;
using OMV.OfficeListing.Infrastructure.Repositories;
using OMV.OfficeListing.Test.TestHelpers;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace OMV.OfficeListing.Test.Repositories
{
    public class OfficeRepositoryTests : OfficeListingContextTestBase
    {
        private OfficeRepository repository;

        public OfficeRepositoryTests()
        {
            repository = new OfficeRepository(
                TableContext);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository = null;
            }
        }

        [Fact]
        public void RepositoryCreatesSuccessfully()
        {
            Assert.NotNull(
                repository);
        }

        [Fact]
        public async Task GetReturnsExpected()
        {
            Seed(TableContext);

            var actual = await repository.Get();

            Assert.NotEmpty(
                actual);
        }

        [Fact]
        public async Task GetByIdReturnsExpected()
        {
            var expected = 10;

            Seed(TableContext);

            var office = TestFixture.Build<OfficeDto>()
                .With(p => p.Id, expected)
                .With(p => p.RegionId, TableContext.Regions.First().Id)
                .With(p => p.OfficeTypeId, TableContext.OfficeTypes.First().Id)
                .With(p => p.ParishId, TableContext.Parishes.First().Id)
                .Without(p => p.PhoneNumbers)
                .Create();

            TableContext.Offices.Add(office);
            TableContext.SaveChanges();

            var actual = await repository
                .GetById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }
    }
}
