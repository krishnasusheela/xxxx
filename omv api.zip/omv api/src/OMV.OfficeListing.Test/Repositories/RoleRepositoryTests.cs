﻿using AutoFixture;
using Microsoft.EntityFrameworkCore;
using OMV.OfficeListing.Infrastructure.Repositories;
using OMV.OfficeListing.Test.TestHelpers;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace OMV.OfficeListing.Test.Repositories
{
    public class RoleRepositoryTests : OfficeListingContextTestBase
    {
        private RoleRepository repository;
        private Fixture fixture;

        public RoleRepositoryTests()
        {
            repository = new RoleRepository(
                TableContext);
            fixture = new Fixture();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository = null;
                fixture = null;
            }
        }

        [Fact]
        public void RepositoryCreatesSuccessfully()
        {
            Assert.NotNull(
                repository);
        }

        [Fact]
        public async Task GetReturnsExpected()
        {
            Seed(TableContext);

            var actual = await repository.Get();

            Assert.NotEmpty(
                actual);
        }

        [Fact]
        public async Task GetByIdReturnsExpected()
        {
            var expected = 10;

            Seed(TableContext);

            var role = CreateRoleWithRelatedData(
                expected);

            TableContext.Roles.Add(role);
            TableContext.SaveChanges();

            var actual = await repository
                .GetById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }

        [Fact]
        public async Task CreateAddsNewRoleToDatabase()
        {
            var roleId = 10;
            var role = CreateRoleWithRelatedData(roleId);

            Seed(TableContext);

            var expectedCount = TableContext
                .Roles
                .IgnoreQueryFilters()
                .Count() + 1;

            await repository
                .Create(role);

            Assert.Equal(
                expectedCount,
                TableContext
                    .Roles
                    .IgnoreQueryFilters()
                    .Count());
        }
    }
}
