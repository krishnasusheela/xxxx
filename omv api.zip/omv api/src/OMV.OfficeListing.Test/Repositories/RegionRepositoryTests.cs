﻿using OMV.OfficeListing.Infrastructure.Repositories;
using OMV.OfficeListing.Test.TestHelpers;
using System.Threading.Tasks;
using Xunit;

namespace OMV.OfficeListing.Test.Repositories
{
    public class RegionRepositoryTests : OfficeListingContextTestBase
    {
        private RegionRepository repository;

        public RegionRepositoryTests()
        {
            repository = new RegionRepository(
                TableContext);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository = null;
            }
        }

        [Fact]
        public void RepositoryCreatesSuccessfully()
        {
            Assert.NotNull(
                repository);
        }

        [Fact]
        public async Task GetReturnsExpected()
        {
            Seed(TableContext);

            var actual = await repository.Get();

            Assert.NotEmpty(
                actual);
        }

        [Fact]
        public async Task GetByIdReturnsExpected()
        {
            var expected = 10;

            Seed(TableContext);

            var region = CreateRegionWithRelatedData(
                expected);

            TableContext.Regions.Add(region);
            TableContext.SaveChanges();

            var actual = await repository
                .GetById(expected);

            Assert.Equal(
                expected,
                actual.Id);
        }
    }
}
