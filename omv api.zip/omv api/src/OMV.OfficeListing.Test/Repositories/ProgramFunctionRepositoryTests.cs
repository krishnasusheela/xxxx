﻿using OMV.OfficeListing.Infrastructure.Repositories;
using OMV.OfficeListing.Test.TestHelpers;
using System.Threading.Tasks;
using Xunit;

namespace OMV.OfficeListing.Test.Repositories
{
    public class ProgramFunctionRepositoryTests : OfficeListingContextTestBase
    {
        private ProgramFunctionRepository repository;

        public ProgramFunctionRepositoryTests()
        {
            repository = new ProgramFunctionRepository(
                TableContext);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repository = null;
            }
        }

        [Fact]
        public void RepositoryCreatesSuccessfully()
        {
            Assert.NotNull(
                repository);
        }

        [Fact]
        public async Task GetReturnsExpected()
        {
            Seed(TableContext);

            var actual = await repository.Get();

            Assert.NotEmpty(
                actual);
        }
    }
}
